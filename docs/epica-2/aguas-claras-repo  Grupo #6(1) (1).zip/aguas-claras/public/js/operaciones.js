/* Épica 2 – Gestión de Operaciones (pantallas del panel). Usa las funciones de app.js: api, g, can, act, esc, fmt, toast, R, tab. */
var X = { ops: null, ind: null, act: null, f: {}, tipos: [], ventana: 12, resp: [], sel: null, det: null, nuevo: false, err: '', msg: '',
  inc: null, incSel: null, incDet: null, incF: {}, apr: null, rep: null, fi: {}, bit: null, fb: {}, alertas: null, notif: { items: [], n: 0 } };

const dt = (t) => (t ? new Date(t).toLocaleString('es-DO', { dateStyle: 'short', timeStyle: 'short' }) : '—');
const loc = (t) => new Date(t - new Date(t).getTimezoneOffset() * 6e4).toISOString().slice(0, 16);
const qs = (o) => Object.entries(o).filter(([, v]) => v).map(([k, v]) => k + '=' + encodeURIComponent(v)).join('&');
const ESTADOS = ['Creada', 'En proceso', 'En aprobación', 'Completada', 'Rechazada', 'Cerrada', 'Cancelada'];
const stTag = (e) => `<span class="tag ${['Rechazada', 'Cancelada'].includes(e) ? 'er' : ''}">${esc(e)}</span>`;
const venTag = (o) => (o.vencida ? ' <span class="tag er">Vencida</span>' : o.porVencer ? ' <span class="tag warn">Por vencer</span>' : '');
const errBox = () => (X.err ? `<div class="banner er" role="alert">${esc(X.err)}</div>` : '');
const opts = (arr, sel, vacio) => (vacio ? `<option value="">${vacio}</option>` : '') + arr.map(([v, n]) => `<option value="${esc(v)}" ${String(sel) === String(v) ? 'selected' : ''}>${esc(n)}</option>`).join('');
const v$ = (id) => ($('#' + id) ? $('#' + id).value.trim() : '');
function dif(a, b) { // resume "antes → después" de la bitácora
  try { const A = a ? JSON.parse(a) : {}, B = b ? JSON.parse(b) : {}, ks = Object.keys(B).length ? Object.keys(B) : Object.keys(A);
    return ks.filter((k) => !a || A[k] !== B[k]).map((k) => (a && A[k] !== undefined ? `${k}: ${A[k]} → ${B[k]}` : `${k}: ${B[k]}`)).join(' · '); } catch (e) { return ''; }
}
const bitTabla = (L) => `<div class="tw"><table><tr><th>Fecha y hora</th><th>Usuario</th><th>Acción</th><th>Resultado</th><th>Cambio</th><th>Detalle</th></tr>${L.map((b) => `<tr><td>${dt(b.t)}</td><td>${esc(b.actor)}</td><td>${esc(b.accion)}</td><td><span class="tag ${b.resultado === 'Rechazado' ? 'er' : ''}">${esc(b.resultado)}</span></td><td>${esc(dif(b.antes, b.despues))}</td><td>${esc(b.det)}</td></tr>`).join('') || '<tr><td colspan="6" class="mu">Sin registros.</td></tr>'}</table></div>`;

async function loadNotif() { const r = await g('/notificaciones'); X.notif = r ? { items: r.items, n: r.sinLeer } : { items: [], n: 0 }; }
async function loadTab() {
  const t = tab;
  if (t === 'operaciones') {
    const [o, ti, rs] = await Promise.all([g('/operaciones?' + qs(X.f)), g('/tipos'), g('/responsables')]);
    X.ops = o ? o.items : []; X.ind = o ? o.indicadores : null; X.act = o ? o.actualizado : null; X.tipos = ti ? ti.items : []; X.resp = rs ? rs.items : [];
    if (X.sel) { X.det = await g('/operaciones/' + X.sel); if (!X.det) X.sel = null; }
  } else if (t === 'aprobaciones') { X.apr = (await g('/aprobaciones')) || { pendientes: [], historial: [] }; }
  else if (t === 'incidencias') {
    const [i, o, rs] = await Promise.all([g('/incidencias?' + qs(X.incF)), g('/operaciones'), g('/responsables')]);
    X.inc = i ? i.items : []; X.ops = o ? o.items : []; X.resp = rs ? rs.items : [];
    if (X.incSel) { X.incDet = await g('/incidencias/' + X.incSel); if (!X.incDet) X.incSel = null; }
  } else if (t === 'informes') { const [ti, rs] = await Promise.all([g('/tipos'), g('/responsables')]); X.tipos = ti ? ti.items : []; X.resp = rs ? rs.items : []; }
  else if (t === 'bitacora') { const b = await g('/bitacora?' + qs(X.fb)); X.bit = b ? b.items : []; }
  else if (t === 'tipos') { const [ti, al] = await Promise.all([g('/tipos'), g('/alertas')]); X.tipos = ti ? ti.items : []; X.ventana = ti ? ti.ventanaH : 12; X.alertas = al ? al.items : []; }
  else if (t === 'alertas') { await loadNotif(); }
  if (tab === t) R();
}
async function accion(p, ok) { const r = await p; X.err = r.ok ? '' : (r.error || 'No se pudo completar la acción.'); if (r.ok && ok) toast(ok); await loadNotif(); await loadTab(); return r; }

const TABGROUPS = () => [
  ['Gestión operativa', [['operaciones', 'Operaciones'], ['aprobaciones', 'Aprobaciones'], ['incidencias', 'Incidencias'], ['informes', 'Informes'], ['bitacora', 'Bitácora'], ['tipos', 'Tipos y plazos'], ['alertas', 'Alertas']]],
  ['Reportes y accesos', [['reportes', 'Reportes'], ['usuarios', 'Usuarios'], ['roles', 'Roles'], ['permisos', 'Permisos'], ['auditoria', 'Auditoría']]],
  ['Mi cuenta', [['perfil', 'Mi perfil'], ['pruebas', 'Pruebas']]]];

/* ---------- HU-2.1 / 2.2 / 2.3 / 2.4: operaciones ---------- */
function tOperaciones() {
  if (X.ops === null) return '<div class="card">Cargando…</div>';
  if (X.sel && X.det) return vOpDet();
  const i = X.ind || { creadas: 0, en_proceso: 0, completadas: 0, rechazadas: 0, vencidas: 0, por_vencer: 0 }, f = X.f;
  const ind = (n, l, q, on) => `<button class="ind ${on ? 'on' : ''}" onclick="filtroRapido('${q}')"><b>${n}</b><span>${l}</span></button>`;
  return `<span class="hu">HU-2.1 · Panel de operaciones</span><div class="inds" style="margin:8px 0 12px">
${ind(i.creadas, 'Creadas (total)', '', !f.estado && !f.vencidas && !f.grupo)}${ind(i.en_proceso, 'En proceso', 'estado=En proceso', f.estado === 'En proceso')}${ind(i.completadas, 'Completadas', 'grupo=completadas', f.grupo)}${ind(i.rechazadas, 'Rechazadas', 'estado=Rechazada', f.estado === 'Rechazada')}${ind(i.vencidas, 'Vencidas', 'vencidas=1', f.vencidas)}</div>
<p class="hint">Última actualización de los registros: <b>${dt(X.act)}</b> · Por vencer pronto: ${i.por_vencer}</p>
<div class="card" style="margin:10px 0"><h3>Filtros</h3><div class="g3"><div><label for="f_desde">Desde</label><input id="f_desde" type="date" value="${esc(f.desde || '')}"></div><div><label for="f_hasta">Hasta</label><input id="f_hasta" type="date" value="${esc(f.hasta || '')}"></div>
<div><label for="f_q">Buscar (código o título)</label><input id="f_q" value="${esc(f.q || '')}"></div>
<div><label for="f_estado">Estado</label><select id="f_estado">${opts(ESTADOS.map((e) => [e, e]), f.estado, 'Todos')}</select></div>
<div><label for="f_tipo">Tipo</label><select id="f_tipo">${opts(X.tipos.map((t) => [t.id, t.nombre]), f.tipo, 'Todos')}</select></div>
<div><label for="f_resp">Responsable</label><select id="f_resp">${opts([['sin', 'Sin asignar'], ...X.resp.map((r) => [r.id, r.nombre])], f.responsable, 'Todos')}</select></div></div>
<div class="row"><button class="btn" onclick="aplicarF()">Filtrar</button><button class="btn s" onclick="X.f={};loadTab()">Limpiar</button>${act('operaciones', 'c', 'X.nuevo=!X.nuevo;X.err=\'\';R()', X.nuevo ? 'Cancelar' : '+ Nueva operación', '')}</div></div>
${X.nuevo ? formOp() : ''}
<div class="card"><div class="tw"><table><tr><th>Código</th><th>Título</th><th>Tipo</th><th>Estado</th><th>Responsable</th><th>Vence</th><th>Prioridad</th><th></th></tr>
${X.ops.map((o) => `<tr><td><b>${o.codigo}</b></td><td>${esc(o.titulo)}</td><td>${esc(o.tipo)}</td><td>${stTag(o.estado)}${venTag(o)}</td><td>${o.responsable ? esc(o.responsable.nombre) : '<span class="mu">Sin asignar</span>'}</td><td>${dt(o.limite)}</td><td>${esc(o.prioridad)}</td><td><button class="btn s sm" onclick="verOp('${o.codigo}')">Ver</button></td></tr>`).join('') || '<tr><td colspan="8" class="mu">No hay operaciones con estos filtros.</td></tr>'}</table></div></div>`;
}
function aplicarF() { X.f = { desde: v$('f_desde'), hasta: v$('f_hasta'), q: v$('f_q'), estado: v$('f_estado'), tipo: v$('f_tipo'), responsable: v$('f_resp') }; loadTab(); }
function filtroRapido(q) { X.f = {}; if (q) { const [k, v] = q.split('='); X.f[k] = v; } loadTab(); }
function verOp(c) { X.sel = c; X.err = ''; loadTab(); scrollTo(0, 0); }
function formOp() {
  return `<div class="card" style="margin-bottom:10px"><span class="hu">HU-2.2 · Registro</span><h3>Nueva operación</h3><div class="g2">
<div><label for="o_tipo">Tipo *</label><select id="o_tipo">${opts(X.tipos.filter((t) => t.activo).map((t) => [t.id, `${t.nombre} (${t.sla} h)`]))}</select></div>
<div><label for="o_pri">Prioridad</label><select id="o_pri">${opts(['Baja', 'Media', 'Alta', 'Crítica'].map((p) => [p, p]), 'Media')}</select></div>
<div><label for="o_tit">Título * (mínimo 5 caracteres)</label><input id="o_tit"></div>
<div><label for="o_resp">Responsable</label><select id="o_resp">${opts(X.resp.map((r) => [r.id, `${r.nombre} · ${r.rol}`]), '', 'Sin asignar (asignar después)')}</select></div>
<div><label for="o_lim">Fecha límite</label><input id="o_lim" type="datetime-local"><div class="hint">Si la dejas vacía se usa el plazo (SLA) del tipo.</div></div>
<div><label for="o_rep">Reporte ciudadano vinculado</label><input id="o_rep" placeholder="DEMO-001"><div class="hint">Opcional.</div></div></div>
<label for="o_desc">Descripción * (mínimo 10 caracteres)</label><textarea id="o_desc"></textarea>${errBox()}<div class="row"><button class="btn" onclick="crearOp()">Crear operación</button></div></div>`;
}
async function crearOp() {
  const b = { tipo_id: +v$('o_tipo'), titulo: v$('o_tit'), descripcion: v$('o_desc'), prioridad: v$('o_pri'), fecha_limite: v$('o_lim') ? new Date(v$('o_lim')).toISOString() : undefined, responsable_id: +v$('o_resp') || undefined, reporte_codigo: v$('o_rep') || undefined };
  const r = await api('POST', '/operaciones', b);
  if (!r.ok) { X.err = r.error; return R(); }
  X.err = ''; X.nuevo = false; X.sel = r.codigo; toast('Operación ' + r.codigo + ' creada'); await loadNotif(); await loadTab();
}
function vOpDet() {
  const d = X.det, o = d.item, tp = (k, v) => `<div><span>${k}</span><b>${v}</b></div>`;
  const btns = d.transiciones.map((e) => `<button class="btn ${e === 'Cancelada' ? 'r' : 's'} sm" onclick="cambiarEstado('${e}')">${e === 'En proceso' && o.estado === 'Rechazada' ? 'Reabrir' : e === 'Cerrada' ? 'Cerrar operación' : '→ ' + e}</button>`).join(' ');
  return `<button class="btn s sm" onclick="X.sel=null;X.err='';loadTab()">← Volver al listado</button>
<div class="card" style="margin-top:10px"><span class="hu">HU-2.2 · Seguimiento</span><h3>${o.codigo} · ${esc(o.titulo)}</h3><p>${stTag(o.estado)}${venTag(o)} <span class="tag">${esc(o.prioridad)}</span> <span class="tag">${esc(o.tipo)}</span>${o.requiereAprob ? ' <span class="tag">Requiere aprobación</span>' : ''}</p>
<div class="kv" style="margin:10px 0">${tp('Responsable', o.responsable ? esc(o.responsable.nombre) : 'Sin asignar')}${tp('Creada por', esc(o.creador))}${tp('Fecha límite', dt(o.limite))}${tp('Creada', dt(o.creado))}${tp('Última actualización', dt(o.actualizado))}${tp('Reporte vinculado', esc(o.reporte || '—'))}</div>
<p>${esc(o.descripcion)}</p>${o.resultado ? `<p><b>Resultado:</b> ${esc(o.resultado)}</p>` : ''}${errBox()}
${btns ? `<h3 style="margin-top:14px">Cambiar estado</h3><label for="o_txt">Motivo o resultado (obligatorio al cancelar, reabrir o cerrar)</label><input id="o_txt"><div class="row">${btns}</div>` : ''}
${d.puedeAprobar ? `<h3 style="margin-top:14px">Decisión de aprobación</h3><label for="o_apr">Comentario (obligatorio para devolver o rechazar)</label><input id="o_apr"><div class="row"><button class="btn sm" onclick="decidir('${o.codigo}','Aprobada','o_apr')">Aprobar</button><button class="btn s sm" onclick="decidir('${o.codigo}','Devuelta','o_apr')">Devolver para corrección</button><button class="btn r sm" onclick="decidir('${o.codigo}','Rechazada','o_apr')">Rechazar</button></div>` : ''}
${d.puedeAsignar ? `<h3 style="margin-top:14px">${o.responsable ? 'Reasignar' : 'Asignar'} responsable</h3><div class="g2"><div><label for="o_as">Responsable</label><select id="o_as">${opts(X.resp.map((r) => [r.id, `${r.nombre} · ${r.rol}`]))}</select></div><div><label for="o_mot">Motivo ${o.responsable ? '(obligatorio al reasignar)' : '(opcional)'}</label><input id="o_mot"></div></div><div class="row"><button class="btn sm" onclick="asignar()">${o.responsable ? 'Reasignar' : 'Asignar'}</button></div>` : ''}
${d.puedeEditar ? `<details style="margin-top:14px"><summary><b>Editar datos de la operación</b></summary><div class="g2"><div><label for="e_tit">Título</label><input id="e_tit" value="${esc(o.titulo)}"></div><div><label for="e_pri">Prioridad</label><select id="e_pri">${opts(['Baja', 'Media', 'Alta', 'Crítica'].map((p) => [p, p]), o.prioridad)}</select></div><div><label for="e_lim">Fecha límite</label><input id="e_lim" type="datetime-local" value="${loc(o.limite)}"></div></div><label for="e_desc">Descripción</label><textarea id="e_desc">${esc(o.descripcion)}</textarea><div class="row"><button class="btn sm" onclick="editarOp()">Guardar cambios</button></div></details>` : ''}</div>
<div class="card" style="margin-top:12px"><span class="hu">HU-2.6 · Incidencias</span><h3>Incidencias de esta operación</h3>${d.incidencias.length ? `<div class="tw"><table><tr><th>Código</th><th>Categoría</th><th>Prioridad</th><th>Estado</th></tr>${d.incidencias.map((i) => `<tr><td><button class="btn s sm" onclick="X.incSel='${i.codigo}';openTab('incidencias')">${i.codigo}</button></td><td>${esc(i.categoria)}</td><td>${esc(i.prioridad)}</td><td>${stTag(i.estado)}</td></tr>`).join('')}</table></div>` : '<p class="mu">Sin incidencias.</p>'}
${can('incidencias', 'c') && !['Cerrada', 'Cancelada'].includes(o.estado) ? `<details><summary><b>Registrar incidencia</b></summary><div class="g2"><div><label for="n_cat">Categoría</label><input id="n_cat"></div><div><label for="n_pri">Prioridad</label><select id="n_pri">${opts(['Baja', 'Media', 'Alta', 'Crítica'].map((p) => [p, p]), 'Media')}</select></div></div><label for="n_desc">Descripción</label><textarea id="n_desc"></textarea><div class="row"><button class="btn sm" onclick="crearInc('${o.codigo}')">Registrar</button></div></details>` : ''}</div>
<div class="g2" style="margin-top:12px;align-items:start"><div class="card"><h3>Asignaciones</h3><div class="tw"><table><tr><th>Fecha</th><th>Responsable</th><th>Asignó</th><th>Motivo</th></tr>${d.asignaciones.map((a) => `<tr><td>${dt(a.fecha)}</td><td>${esc(a.responsable || '—')}</td><td>${esc(a.asignado_por || '—')}</td><td>${esc(a.motivo)}</td></tr>`).join('') || '<tr><td colspan="4" class="mu">Sin asignaciones.</td></tr>'}</table></div></div>
<div class="card"><h3>Aprobaciones</h3><div class="tw"><table><tr><th>Fecha</th><th>Decisión</th><th>Aprobador</th><th>Comentario</th></tr>${d.aprobaciones.map((a) => `<tr><td>${dt(a.fecha)}</td><td>${esc(a.decision)}</td><td>${esc(a.aprobador || '—')}</td><td>${esc(a.comentario)}</td></tr>`).join('') || '<tr><td colspan="4" class="mu">Sin decisiones.</td></tr>'}</table></div></div></div>
<div class="card" style="margin-top:12px"><span class="hu">HU-2.2 · HU-2.8 · Historial de cambios</span><h3>Historial</h3>${bitTabla(d.historial)}</div>`;
}
async function cambiarEstado(e) { await accion(api('POST', `/operaciones/${X.sel}/estado`, { estado: e, motivo: v$('o_txt'), resultado: v$('o_txt') }), 'Estado actualizado'); }
async function asignar() { await accion(api('POST', `/operaciones/${X.sel}/asignar`, { responsable_id: +v$('o_as'), motivo: v$('o_mot') }), 'Responsable asignado'); }
async function editarOp() { await accion(api('PUT', `/operaciones/${X.sel}`, { titulo: v$('e_tit'), descripcion: v$('e_desc'), prioridad: v$('e_pri'), fecha_limite: v$('e_lim') ? new Date(v$('e_lim')).toISOString() : undefined }), 'Operación actualizada'); }
async function decidir(c, dec, id) { await accion(api('POST', `/operaciones/${c}/aprobacion`, { decision: dec, comentario: v$(id) }), 'Decisión registrada: ' + dec); }
async function crearInc(c) { await accion(api('POST', '/incidencias', { operacion: c, categoria: v$('n_cat'), descripcion: v$('n_desc'), prioridad: v$('n_pri') }), 'Incidencia registrada'); }

/* ---------- HU-2.4: aprobaciones pendientes ---------- */
function tAprobaciones() {
  if (!X.apr) return '<div class="card">Cargando…</div>';
  return `<div class="card"><span class="hu">HU-2.4 · Flujos de aprobación</span><h3>Operaciones esperando aprobación</h3>${errBox()}<div class="tw"><table><tr><th>Código</th><th>Título</th><th>Tipo</th><th>Responsable</th><th>Comentario</th><th>Decisión</th></tr>
${X.apr.pendientes.map((o) => `<tr><td><button class="btn s sm" onclick="X.sel='${o.codigo}';openTab('operaciones')">${o.codigo}</button></td><td>${esc(o.titulo)}</td><td>${esc(o.tipo)}</td><td>${o.responsable ? esc(o.responsable.nombre) : '—'}</td><td><input id="ap_${o.codigo}" aria-label="Comentario" ${o.puedeAprobar ? '' : 'disabled'}></td><td>${o.puedeAprobar ? `<button class="btn sm" onclick="decidir('${o.codigo}','Aprobada','ap_${o.codigo}')">Aprobar</button> <button class="btn s sm" onclick="decidir('${o.codigo}','Devuelta','ap_${o.codigo}')">Devolver</button> <button class="btn r sm" onclick="decidir('${o.codigo}','Rechazada','ap_${o.codigo}')">Rechazar</button>` : '<span class="mu sm">No puedes decidir esta</span>'}</td></tr>`).join('') || '<tr><td colspan="6" class="mu">No hay operaciones pendientes de aprobación.</td></tr>'}</table></div></div>
<div class="card" style="margin-top:12px"><h3>Últimas decisiones</h3><div class="tw"><table><tr><th>Fecha</th><th>Operación</th><th>Decisión</th><th>Aprobador</th><th>Comentario</th></tr>${X.apr.historial.map((a) => `<tr><td>${dt(a.fecha)}</td><td>${a.codigo}</td><td>${esc(a.decision)}</td><td>${esc(a.aprobador || '—')}</td><td>${esc(a.comentario)}</td></tr>`).join('') || '<tr><td colspan="5" class="mu">Sin decisiones.</td></tr>'}</table></div></div>`;
}

/* ---------- HU-2.6: incidencias ---------- */
function tIncidencias() {
  if (X.inc === null) return '<div class="card">Cargando…</div>';
  if (X.incSel && X.incDet) return vIncDet();
  return `<div class="card"><span class="hu">HU-2.6 · Incidencias operativas</span><h3>Incidencias</h3><div class="row" style="align-items:end"><div><label for="if_e">Estado</label><select id="if_e">${opts(['Abierta', 'En atención', 'Resuelta'].map((e) => [e, e]), X.incF.estado, 'Todos')}</select></div><div><label for="if_o">Operación</label><input id="if_o" placeholder="OP-0001" value="${esc(X.incF.operacion || '')}"></div><button class="btn" onclick="X.incF={estado:v$('if_e'),operacion:v$('if_o')};loadTab()">Filtrar</button></div>
<div class="tw"><table><tr><th>Código</th><th>Operación</th><th>Categoría</th><th>Prioridad</th><th>Responsable</th><th>Estado</th><th></th></tr>${X.inc.map((i) => `<tr><td><b>${i.codigo}</b></td><td>${i.operacion}</td><td>${esc(i.categoria)}</td><td>${esc(i.prioridad)}</td><td>${esc(i.responsable)}</td><td>${stTag(i.estado)}</td><td><button class="btn s sm" onclick="X.incSel='${i.codigo}';X.err='';loadTab()">Ver</button></td></tr>`).join('') || '<tr><td colspan="7" class="mu">Sin incidencias.</td></tr>'}</table></div></div>
${can('incidencias', 'c') ? `<div class="card" style="margin-top:12px"><h3>Registrar incidencia</h3><div class="g2"><div><label for="ni_op">Operación *</label><select id="ni_op">${opts(X.ops.filter((o) => !['Cerrada', 'Cancelada'].includes(o.estado)).map((o) => [o.codigo, `${o.codigo} · ${o.titulo}`]))}</select></div><div><label for="ni_cat">Categoría *</label><input id="ni_cat" placeholder="Falta de materiales"></div><div><label for="ni_pri">Prioridad</label><select id="ni_pri">${opts(['Baja', 'Media', 'Alta', 'Crítica'].map((p) => [p, p]), 'Media')}</select></div><div><label for="ni_resp">Responsable</label><select id="ni_resp">${opts(X.resp.map((r) => [r.id, r.nombre]), '', 'Sin asignar')}</select></div></div><label for="ni_desc">Descripción *</label><textarea id="ni_desc"></textarea>${errBox()}<div class="row"><button class="btn" onclick="nuevaInc()">Registrar incidencia</button></div></div>` : ''}`;
}
async function nuevaInc() { await accion(api('POST', '/incidencias', { operacion: v$('ni_op'), categoria: v$('ni_cat'), descripcion: v$('ni_desc'), prioridad: v$('ni_pri'), responsable_id: +v$('ni_resp') || undefined }), 'Incidencia registrada'); }
function vIncDet() {
  const d = X.incDet, i = d.item;
  return `<button class="btn s sm" onclick="X.incSel=null;X.err='';loadTab()">← Volver a incidencias</button><div class="card" style="margin-top:10px"><h3>${i.codigo} · ${esc(i.categoria)}</h3><p>${stTag(i.estado)} <span class="tag">${esc(i.prioridad)}</span> Operación <b>${i.operacion}</b> · Responsable: ${esc(i.responsable)}</p><p>${esc(i.descripcion)}</p>${i.resolucion ? `<p><b>Resolución:</b> ${esc(i.resolucion)}</p>` : ''}${errBox()}
${d.transiciones.length ? `<label for="ic_res">Resolución (obligatoria para marcar como Resuelta)</label><input id="ic_res"><div class="row">${d.transiciones.map((e) => `<button class="btn s sm" onclick="estadoInc('${i.codigo}','${e}')">→ ${e}</button>`).join(' ')}</div>` : ''}</div>
<div class="card" style="margin-top:12px"><h3>Comentarios</h3>${d.comentarios.map((c) => `<p><b>${esc(c.usuario)}</b> <span class="mu sm">${dt(c.fecha)}</span><br>${esc(c.texto)}</p>`).join('') || '<p class="mu">Sin comentarios.</p>'}${can('incidencias', 'u') ? `<label for="ic_com">Nuevo comentario</label><input id="ic_com"><div class="row"><button class="btn sm" onclick="comentarInc('${i.codigo}')">Agregar comentario</button></div>` : ''}</div>
<div class="card" style="margin-top:12px"><h3>Historial de cambios</h3>${bitTabla(d.historial.map((h) => ({ ...h, det: h.det })))}</div>`;
}
async function estadoInc(c, e) { await accion(api('POST', `/incidencias/${c}/estado`, { estado: e, resolucion: v$('ic_res') }), 'Incidencia actualizada'); }
async function comentarInc(c) { await accion(api('POST', `/incidencias/${c}/comentarios`, { texto: v$('ic_com') }), 'Comentario agregado'); }

/* ---------- HU-2.7: informes ---------- */
function tInformes() {
  const f = X.fi, r = X.rep, m = r && r.metricas, card = (n, l) => `<div class="ind"><b>${n}</b><span>${l}</span></div>`;
  const tabla = (T) => `<div class="tw"><table><tr><th>Nombre</th><th>Total</th><th>Completadas</th><th>Vencidas</th></tr>${T.map((x) => `<tr><td>${esc(x.nombre)}</td><td>${x.total}</td><td>${x.completadas ?? '—'}</td><td>${x.vencidas ?? '—'}</td></tr>`).join('')}</table></div>`;
  return `<div class="card"><span class="hu">HU-2.7 · Reportes operativos</span><h3>Reporte de operaciones</h3><div class="g3"><div><label for="r_desde">Desde</label><input id="r_desde" type="date" value="${esc(f.desde || '')}"></div><div><label for="r_hasta">Hasta</label><input id="r_hasta" type="date" value="${esc(f.hasta || '')}"></div>
<div><label for="r_estado">Estado</label><select id="r_estado">${opts(ESTADOS.map((e) => [e, e]), f.estado, 'Todos')}</select></div><div><label for="r_tipo">Tipo</label><select id="r_tipo">${opts(X.tipos.map((t) => [t.id, t.nombre]), f.tipo, 'Todos')}</select></div><div><label for="r_resp">Responsable</label><select id="r_resp">${opts([['sin', 'Sin asignar'], ...X.resp.map((x) => [x.id, x.nombre])], f.responsable, 'Todos')}</select></div></div>${errBox()}
<div class="row"><button class="btn" onclick="generarInf()">Generar reporte</button>${act('informes', 'c', 'exportarCsv()', 'Exportar CSV', 's')}</div></div>
${r ? `<div class="card" style="margin-top:12px"><p><b>Generado:</b> ${dt(r.generado)} por ${esc(r.generado_por)}<br><b>Filtros:</b> periodo ${esc(r.filtros.periodo)} · estado ${esc(r.filtros.estado)} · tipo ${esc(r.filtros.tipo)} · responsable ${esc(r.filtros.responsable)}</p>
<div class="inds">${card(m.total, 'Operaciones')}${card(m.completadas, 'Completadas')}${card(m.vencidas, 'Vencidas')}${card(m.cumplimiento == null ? '—' : m.cumplimiento + ' %', 'Cumplimiento')}${card(m.tasa_completadas == null ? '—' : m.tasa_completadas + ' %', 'Tasa de completadas')}${card(m.tiempo_promedio_horas == null ? '—' : m.tiempo_promedio_horas + ' h', 'Tiempo promedio')}${card(m.incidencias_abiertas, 'Incidencias abiertas')}</div></div>
<div class="g2" style="margin-top:12px;align-items:start"><div class="card"><h3>Por estado</h3>${tabla(r.por_estado)}</div><div class="card"><h3>Por tipo</h3>${tabla(r.por_tipo)}</div></div>
<div class="card" style="margin-top:12px"><h3>Por responsable</h3>${tabla(r.por_responsable)}</div>
<div class="card" style="margin-top:12px"><h3>Detalle (${r.filas.length})</h3><div class="tw"><table><tr><th>Código</th><th>Título</th><th>Tipo</th><th>Estado</th><th>Responsable</th><th>Vence</th></tr>${r.filas.slice(0, 100).map((o) => `<tr><td>${o.codigo}</td><td>${esc(o.titulo)}</td><td>${esc(o.tipo)}</td><td>${stTag(o.estado)}${venTag(o)}</td><td>${o.responsable ? esc(o.responsable.nombre) : '—'}</td><td>${dt(o.limite)}</td></tr>`).join('')}</table></div></div>
<div class="card" style="margin-top:12px"><h3>Definición de las métricas</h3><ul>${Object.entries(r.definiciones).map(([k, v]) => `<li><b>${esc(k.replace(/_/g, ' '))}:</b> ${esc(v)}</li>`).join('')}</ul></div>` : ''}`;
}
const filtrosInf = () => ({ desde: v$('r_desde'), hasta: v$('r_hasta'), estado: v$('r_estado'), tipo: v$('r_tipo'), responsable: v$('r_resp') });
async function generarInf() { X.fi = filtrosInf(); const r = await api('GET', '/informes?' + qs(X.fi)); X.err = r.ok ? '' : r.error; X.rep = r.ok ? r : null; R(); }
async function exportarCsv() {
  X.fi = filtrosInf();
  const r = await fetch('/api/informes/exportar?' + qs(X.fi), { credentials: 'same-origin' });
  if (!r.ok) { X.err = (await r.json().catch(() => ({}))).error || 'No se pudo exportar.'; return R(); }
  const a = document.createElement('a'); a.href = URL.createObjectURL(await r.blob()); a.download = 'operaciones-' + new Date().toISOString().slice(0, 10) + '.csv';
  document.body.appendChild(a); a.click(); a.remove(); X.err = ''; toast('Reporte exportado'); R();
}

/* ---------- HU-2.8: bitácora ---------- */
function tBitacora() {
  if (X.bit === null) return '<div class="card">Cargando…</div>';
  const f = X.fb;
  return `<div class="card"><span class="hu">HU-2.8 · Bitácora de cambios</span><h3>Quién modificó qué</h3><p class="mu">Solo lectura: nadie puede modificar ni eliminar estos registros, ni siquiera desde la base de datos.</p>
<div class="g3"><div><label for="b_op">Operación</label><input id="b_op" placeholder="OP-0001" value="${esc(f.operacion || '')}"></div><div><label for="b_us">Usuario</label><input id="b_us" value="${esc(f.usuario || '')}"></div><div><label for="b_q">Texto</label><input id="b_q" value="${esc(f.q || '')}"></div><div><label for="b_d">Desde</label><input id="b_d" type="date" value="${esc(f.desde || '')}"></div><div><label for="b_h">Hasta</label><input id="b_h" type="date" value="${esc(f.hasta || '')}"></div></div>
<div class="row"><button class="btn" onclick="X.fb={operacion:v$('b_op'),usuario:v$('b_us'),q:v$('b_q'),desde:v$('b_d'),hasta:v$('b_h')};loadTab()">Buscar</button><button class="btn s" onclick="X.fb={};loadTab()">Limpiar</button></div>
<div class="tw"><table><tr><th>Fecha y hora</th><th>Usuario</th><th>Entidad</th><th>Referencia</th><th>Acción</th><th>Resultado</th><th>Cambio (antes → después)</th><th>Detalle</th></tr>${X.bit.map((b) => `<tr><td>${dt(b.t)}</td><td>${esc(b.actor)}</td><td>${esc(b.entidad)}</td><td>${esc(b.ref)}</td><td>${esc(b.accion)}</td><td><span class="tag ${b.resultado === 'Rechazado' ? 'er' : ''}">${esc(b.resultado)}</span></td><td>${esc(dif(b.antes, b.despues))}</td><td>${esc(b.det)}</td></tr>`).join('') || '<tr><td colspan="8" class="mu">Sin registros con estos filtros.</td></tr>'}</table></div><p class="hint">Se muestran los 500 registros más recientes.</p></div>`;
}

/* ---------- HU-2.4 / 2.5: tipos, plazos y alertas ---------- */
function tTipos() {
  const roles = db.roles.filter((r) => r.a).map((r) => [r.id, r.n]), edit = can('tipos', 'u');
  return `<div class="card"><span class="hu">HU-2.4 · HU-2.5 · Plazos y aprobaciones por tipo</span><h3>Tipos de operación</h3>${errBox()}<div class="tw"><table><tr><th>Tipo</th><th>Plazo (h)</th><th>Aviso (h)</th><th>Requiere aprobación</th><th>Aprueba el rol</th><th>Activo</th><th></th></tr>
${X.tipos.map((t) => `<tr><td><b>${esc(t.nombre)}</b></td><td><input id="t_sla${t.id}" type="number" min="1" value="${t.sla}" style="width:80px" ${edit ? '' : 'disabled'} aria-label="Plazo"></td><td><input id="t_av${t.id}" type="number" min="0" value="${t.aviso}" style="width:80px" ${edit ? '' : 'disabled'} aria-label="Aviso"></td><td><input id="t_ap${t.id}" type="checkbox" style="width:auto" ${t.aprob ? 'checked' : ''} ${edit ? '' : 'disabled'} aria-label="Requiere aprobación"></td><td><select id="t_rol${t.id}" ${edit ? '' : 'disabled'} aria-label="Rol aprobador">${opts(roles, t.aprobador, '—')}</select></td><td><input id="t_ac${t.id}" type="checkbox" style="width:auto" ${t.activo ? 'checked' : ''} ${edit ? '' : 'disabled'} aria-label="Activo"></td><td>${act('tipos', 'u', `guardarTipo(${t.id})`, 'Guardar', '')}</td></tr>`).join('')}</table></div>
<details style="margin-top:10px"><summary><b>Crear tipo de operación</b></summary><div class="g3"><div><label for="nt_n">Nombre</label><input id="nt_n"></div><div><label for="nt_s">Plazo (h)</label><input id="nt_s" type="number" min="1" value="48"></div><div><label for="nt_a">Aviso (h)</label><input id="nt_a" type="number" min="0" value="12"></div></div><div class="row">${act('tipos', 'c', 'crearTipo()', 'Crear tipo', '')}</div></details></div>
<div class="card" style="margin-top:12px"><span class="hu">HU-2.5 · Alertas y vencimientos</span><h3>Alertas</h3><div class="row" style="align-items:end"><div><label for="al_v">Ventana anti-duplicados (horas)</label><input id="al_v" type="number" min="1" max="168" value="${X.ventana}" style="width:120px" ${edit ? '' : 'disabled'}></div>${act('tipos', 'u', 'guardarVentana()', 'Guardar ventana', '')}${act('operaciones', 'u', 'revisarAlertas()', 'Revisar vencimientos ahora', 's')}</div>${X.msg ? `<div class="banner">${esc(X.msg)}</div>` : ''}
<p class="hint">El sistema revisa los vencimientos automáticamente cada 5 minutos. No repite una misma alerta dentro de la ventana configurada.</p>
<div class="tw"><table><tr><th>Fecha</th><th>Alerta</th><th>Operación</th><th>Destinatario</th><th>Canal</th><th>Resultado del envío</th></tr>${(X.alertas || []).map((a) => `<tr><td>${dt(a.fecha)}</td><td>${esc(a.tipo)}</td><td>${a.codigo || '—'}</td><td>${esc(a.usuario)}</td><td>${esc(a.canal)}</td><td>${esc(a.resultado)}</td></tr>`).join('') || '<tr><td colspan="6" class="mu">Aún no se han enviado alertas.</td></tr>'}</table></div></div>`;
}
async function guardarTipo(id) { await accion(api('PUT', '/tipos/' + id, { sla: +v$('t_sla' + id), aviso: +v$('t_av' + id), aprob: $('#t_ap' + id).checked, aprobador: +v$('t_rol' + id) || null, activo: $('#t_ac' + id).checked }), 'Tipo guardado'); }
async function crearTipo() { await accion(api('POST', '/tipos', { nombre: v$('nt_n'), sla: +v$('nt_s'), aviso: +v$('nt_a') }), 'Tipo creado'); }
async function guardarVentana() { await accion(api('PUT', '/alertas/config', { ventanaH: +v$('al_v') }), 'Ventana guardada'); }
async function revisarAlertas() { const r = await api('POST', '/alertas/generar'); X.msg = r.ok ? `Revisión terminada: ${r.creadas} alerta(s) enviada(s) y ${r.omitidas} omitida(s) por estar duplicadas.` : r.error; X.err = ''; await loadNotif(); await loadTab(); }

/* ---------- Notificaciones propias ---------- */
function tAlertas() {
  return `<div class="card"><span class="hu">HU-2.5 · Notificaciones</span><h3>Mis notificaciones</h3><div class="row"><button class="btn s sm" onclick="leerTodas()">Marcar todas como leídas</button></div>${X.notif.items.map((n) => `<p style="${n.leida ? 'opacity:.65' : ''}"><span class="tag ${['Vencida'].includes(n.tipo) ? 'er' : n.tipo === 'Por vencer' ? 'warn' : ''}">${esc(n.tipo)}</span> ${esc(n.mensaje)} <span class="mu sm">${dt(n.fecha)}</span>${n.codigo && can('operaciones', 'r') ? ` <button class="btn s sm" onclick="X.sel='${n.codigo}';openTab('operaciones')">Ver ${n.codigo}</button>` : ''}</p>`).join('') || '<p class="mu">No tienes notificaciones.</p>'}</div>`;
}
async function leerTodas() { await api('PUT', '/notificaciones/leidas'); await loadNotif(); R(); }

var TABS_EXTRA = { operaciones: tOperaciones, aprobaciones: tAprobaciones, incidencias: tIncidencias, informes: tInformes, bitacora: tBitacora, tipos: tTipos, alertas: tAlertas };
