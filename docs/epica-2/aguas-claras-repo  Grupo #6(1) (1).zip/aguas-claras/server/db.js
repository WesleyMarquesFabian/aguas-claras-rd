// Esquema de la base de datos SQLite y datos iniciales.
const Database = require('better-sqlite3');
const bcrypt = require('bcryptjs');

const MODULOS = ['reportes', 'usuarios', 'roles', 'permisos', 'auditoria',
  'operaciones', 'asignaciones', 'aprobaciones', 'incidencias', 'informes', 'tipos', 'bitacora'];
const MODN = { reportes: 'Reportes', usuarios: 'Usuarios', roles: 'Roles', permisos: 'Permisos', auditoria: 'Auditoría',
  operaciones: 'Operaciones', asignaciones: 'Asignaciones', aprobaciones: 'Aprobaciones', incidencias: 'Incidencias',
  informes: 'Informes', tipos: 'Tipos y plazos', bitacora: 'Bitácora' };
const TIPOS = ['Falta de agua', 'Fuga en vía pública', 'Tubería dañada'];
const ROLES = ['Super Administrador', 'Administrador', 'Agente Inmobiliario', 'Arquitecto', 'Ingeniero', 'Cliente', 'Supervisor'];
const ROLES_E2 = ['Auditor', 'Gerente']; // roles nuevos de la Épica 2
const COSTO = process.env.NODE_ENV === 'test' ? 4 : 10;
const hash = (p) => bcrypt.hashSync(p, COSTO);

const SCHEMA = `
CREATE TABLE IF NOT EXISTS roles(
  id INTEGER PRIMARY KEY, nombre TEXT UNIQUE NOT NULL COLLATE NOCASE, activo INTEGER NOT NULL DEFAULT 1);
CREATE TABLE IF NOT EXISTS usuarios(
  id INTEGER PRIMARY KEY, nombre TEXT NOT NULL, correo TEXT UNIQUE NOT NULL COLLATE NOCASE,
  telefono TEXT DEFAULT '', clave_hash TEXT NOT NULL,
  rol_id INTEGER NOT NULL REFERENCES roles(id),
  estado TEXT NOT NULL DEFAULT 'Activo', motivo TEXT DEFAULT '', foto TEXT, actualizado INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS permisos(
  rol_id INTEGER NOT NULL REFERENCES roles(id) ON DELETE CASCADE, modulo TEXT NOT NULL,
  crear INTEGER NOT NULL DEFAULT 0, consultar INTEGER NOT NULL DEFAULT 0,
  modificar INTEGER NOT NULL DEFAULT 0, eliminar INTEGER NOT NULL DEFAULT 0,
  PRIMARY KEY(rol_id, modulo));
CREATE TABLE IF NOT EXISTS sesiones(
  token TEXT PRIMARY KEY, usuario_id INTEGER NOT NULL REFERENCES usuarios(id) ON DELETE CASCADE, expira INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS tokens_recuperacion(
  token TEXT PRIMARY KEY, usuario_id INTEGER NOT NULL REFERENCES usuarios(id) ON DELETE CASCADE,
  expira INTEGER NOT NULL, usado INTEGER NOT NULL DEFAULT 0);
CREATE TABLE IF NOT EXISTS auditoria(
  id INTEGER PRIMARY KEY, fecha INTEGER NOT NULL, usuario TEXT NOT NULL, evento TEXT NOT NULL,
  ip TEXT, localizacion TEXT, detalle TEXT DEFAULT '');
CREATE INDEX IF NOT EXISTS idx_auditoria_fecha ON auditoria(fecha DESC);
CREATE TABLE IF NOT EXISTS reportes(
  id INTEGER PRIMARY KEY, codigo TEXT UNIQUE NOT NULL, municipio TEXT NOT NULL, sector TEXT NOT NULL,
  tipo TEXT NOT NULL, desde TEXT, descripcion TEXT NOT NULL, estado INTEGER NOT NULL DEFAULT 0,
  contacto_nombre TEXT, contacto_telefono TEXT, creado INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS config(clave TEXT PRIMARY KEY, valor TEXT NOT NULL);
`;

const SCHEMA_E2 = `
CREATE TABLE IF NOT EXISTS tipos_operacion(
  id INTEGER PRIMARY KEY, nombre TEXT UNIQUE NOT NULL COLLATE NOCASE,
  sla_horas INTEGER NOT NULL DEFAULT 48, aviso_horas INTEGER NOT NULL DEFAULT 12,
  requiere_aprobacion INTEGER NOT NULL DEFAULT 0, aprobador_rol_id INTEGER REFERENCES roles(id) ON DELETE SET NULL,
  activo INTEGER NOT NULL DEFAULT 1);
CREATE TABLE IF NOT EXISTS operaciones(
  id INTEGER PRIMARY KEY, codigo TEXT UNIQUE NOT NULL, tipo_id INTEGER NOT NULL REFERENCES tipos_operacion(id),
  titulo TEXT NOT NULL, descripcion TEXT NOT NULL, prioridad TEXT NOT NULL DEFAULT 'Media',
  estado TEXT NOT NULL DEFAULT 'Creada',
  responsable_id INTEGER REFERENCES usuarios(id) ON DELETE SET NULL, creado_por INTEGER REFERENCES usuarios(id) ON DELETE SET NULL,
  reporte_codigo TEXT, fecha_limite INTEGER NOT NULL, resultado TEXT,
  creado INTEGER NOT NULL, actualizado INTEGER NOT NULL, cerrado INTEGER);
CREATE INDEX IF NOT EXISTS idx_op_estado ON operaciones(estado);
CREATE TABLE IF NOT EXISTS asignaciones(
  id INTEGER PRIMARY KEY, operacion_id INTEGER NOT NULL REFERENCES operaciones(id) ON DELETE CASCADE,
  responsable_id INTEGER REFERENCES usuarios(id) ON DELETE SET NULL, asignado_por INTEGER REFERENCES usuarios(id) ON DELETE SET NULL,
  fecha INTEGER NOT NULL, motivo TEXT DEFAULT '');
CREATE TABLE IF NOT EXISTS aprobaciones(
  id INTEGER PRIMARY KEY, operacion_id INTEGER NOT NULL REFERENCES operaciones(id) ON DELETE CASCADE,
  aprobador_id INTEGER REFERENCES usuarios(id) ON DELETE SET NULL, decision TEXT NOT NULL,
  comentario TEXT DEFAULT '', fecha INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS incidencias(
  id INTEGER PRIMARY KEY, codigo TEXT UNIQUE NOT NULL, operacion_id INTEGER NOT NULL REFERENCES operaciones(id) ON DELETE CASCADE,
  categoria TEXT NOT NULL, descripcion TEXT NOT NULL, prioridad TEXT NOT NULL DEFAULT 'Media',
  responsable_id INTEGER REFERENCES usuarios(id) ON DELETE SET NULL, estado TEXT NOT NULL DEFAULT 'Abierta',
  resolucion TEXT, creado_por INTEGER REFERENCES usuarios(id) ON DELETE SET NULL, creado INTEGER NOT NULL, actualizado INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS incidencia_comentarios(
  id INTEGER PRIMARY KEY, incidencia_id INTEGER NOT NULL REFERENCES incidencias(id) ON DELETE CASCADE,
  usuario TEXT NOT NULL, texto TEXT NOT NULL, fecha INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS notificaciones(
  id INTEGER PRIMARY KEY, usuario_id INTEGER NOT NULL REFERENCES usuarios(id) ON DELETE CASCADE, tipo TEXT NOT NULL,
  operacion_id INTEGER REFERENCES operaciones(id) ON DELETE CASCADE, mensaje TEXT NOT NULL,
  canal TEXT NOT NULL DEFAULT 'interno', resultado TEXT NOT NULL DEFAULT 'Entregada', leida INTEGER NOT NULL DEFAULT 0, fecha INTEGER NOT NULL);
CREATE INDEX IF NOT EXISTS idx_notif_usuario ON notificaciones(usuario_id, leida);
CREATE TABLE IF NOT EXISTS bitacora(
  id INTEGER PRIMARY KEY, fecha INTEGER NOT NULL, actor_id INTEGER, actor TEXT NOT NULL, entidad TEXT NOT NULL, entidad_id TEXT,
  operacion TEXT, accion TEXT NOT NULL, resultado TEXT NOT NULL DEFAULT 'Exitoso', antes TEXT, despues TEXT, detalle TEXT DEFAULT '');
CREATE INDEX IF NOT EXISTS idx_bitacora_op ON bitacora(operacion);
CREATE INDEX IF NOT EXISTS idx_bitacora_fecha ON bitacora(fecha DESC);
CREATE TRIGGER IF NOT EXISTS bitacora_sin_modificar BEFORE UPDATE ON bitacora
  BEGIN SELECT RAISE(ABORT, 'La bitácora no se puede modificar'); END;
CREATE TRIGGER IF NOT EXISTS bitacora_sin_eliminar BEFORE DELETE ON bitacora
  BEGIN SELECT RAISE(ABORT, 'La bitácora no se puede eliminar'); END;
`;

// Permisos por defecto de los módulos de la Épica 2: [Crear, Consultar, Modificar, Eliminar]
const A = [1, 1, 1, 1], R_ = [0, 1, 0, 0], N0 = [0, 0, 0, 0];
const OPERADOR = { operaciones: [1, 1, 1, 0], asignaciones: R_, aprobaciones: R_, incidencias: [1, 1, 1, 0] };
const PERMISOS_E2 = {
  'Super Administrador': Object.fromEntries(['operaciones', 'asignaciones', 'aprobaciones', 'incidencias', 'informes', 'tipos', 'bitacora'].map((m) => [m, A])),
  'Administrador': { operaciones: A, asignaciones: A, aprobaciones: [0, 1, 1, 0], incidencias: A, informes: [1, 1, 0, 0], tipos: [1, 1, 1, 0], bitacora: R_ },
  'Agente Inmobiliario': OPERADOR, 'Arquitecto': OPERADOR, 'Ingeniero': OPERADOR,
  'Supervisor': { operaciones: [1, 1, 1, 0], asignaciones: [1, 1, 1, 0], aprobaciones: [0, 1, 1, 0], incidencias: [1, 1, 1, 0], informes: [1, 1, 0, 0], tipos: [0, 1, 1, 0], bitacora: R_ },
  'Auditor': { operaciones: R_, incidencias: R_, informes: R_, bitacora: R_, auditoria: R_ },
  'Gerente': { operaciones: R_, incidencias: R_, aprobaciones: R_, informes: [1, 1, 0, 0] },
};

function permisosIniciales(rol) {
  const z = { c: 0, r: 0, u: 0, d: 0 }, todo = { c: 1, r: 1, u: 1, d: 1 };
  const p = Object.fromEntries(MODULOS.map((m) => [m, { ...z }]));
  if (rol === ROLES[0]) MODULOS.forEach((m) => (p[m] = { ...todo }));
  if (rol === ROLES[1]) MODULOS.forEach((m) => (p[m] = m === 'permisos' ? { c: 0, r: 1, u: 0, d: 0 } : { ...todo }));
  if (rol === ROLES[2]) p.reportes = { c: 1, r: 1, u: 1, d: 0 };
  if (rol === ROLES[3] || rol === ROLES[4]) p.reportes = { c: 0, r: 1, u: 1, d: 0 };
  if (rol === ROLES[5]) p.reportes = { c: 0, r: 1, u: 0, d: 0 };
  if (rol === ROLES[6]) { p.reportes = { c: 0, r: 1, u: 1, d: 0 }; p.auditoria = { c: 0, r: 1, u: 0, d: 0 }; }
  Object.entries(PERMISOS_E2[rol] || {}).forEach(([m, v]) => (p[m] = { c: v[0], r: v[1], u: v[2], d: v[3] }));
  return p;
}

const HORA = 3600e3;

// Datos de demostración de la Épica 2 (se crean una sola vez cuando SEED_DEMO != 0)
function sembrarOperacionesDemo(db) {
  const t = Date.now(), u = (c) => (db.prepare('SELECT id FROM usuarios WHERE correo=?').get(c + '@aguaclara.do') || {}).id || null;
  const tipo = (n) => db.prepare('SELECT id FROM tipos_operacion WHERE nombre=?').get(n).id;
  const bit = (op, accion, antes, despues, detalle, ms) =>
    db.prepare('INSERT INTO bitacora(fecha,actor_id,actor,entidad,entidad_id,operacion,accion,resultado,antes,despues,detalle) VALUES(?,?,?,?,?,?,?,?,?,?,?)')
      .run(ms, null, 'sistema (datos de demostración)', 'operacion', op, op, accion, 'Exitoso', antes && JSON.stringify(antes), despues && JSON.stringify(despues), detalle);
  const ops = [
    ['OP-0001', 'Fuga en la calle principal de Alma Rosa', 'Reparación de fuga', 'Alta', 'En proceso', 'ingeniero', 20 * HORA, 40 * HORA, 'DEMO-001', 'Fuga reportada por vecinos; hay agua acumulada junto a la acera.'],
    ['OP-0002', 'Sin suministro en el sector Los Mina', 'Restablecer suministro', 'Crítica', 'En proceso', 'agente', -5 * HORA, 30 * HORA, null, 'El sector lleva más de un día sin agua. Verificar válvula de entrada.'],
    ['OP-0003', 'Reemplazo de tubería principal en Av. Venezuela', 'Reparación de tubería', 'Alta', 'En aprobación', 'arquitecto', 60 * HORA, 70 * HORA, null, 'Se requiere cambiar 40 metros de tubería dañada por corrosión.'],
    ['OP-0004', 'Inspección de válvulas del barrio Invivienda', 'Inspección de campo', 'Media', 'Creada', null, 80 * HORA, 10 * HORA, null, 'Revisión programada de las válvulas de paso del barrio.'],
    ['OP-0005', 'Cambio de medidor en la calle 5', 'Restablecer suministro', 'Baja', 'Completada', 'ingeniero', -10 * HORA, 50 * HORA, null, 'Medidor con lectura errónea; se reemplazó por uno nuevo.'],
    ['OP-0006', 'Reparación de tubería rota en Villa Mella', 'Reparación de tubería', 'Alta', 'Rechazada', 'arquitecto', 50 * HORA, 90 * HORA, null, 'Tubería rota frente a la escuela del sector.'],
  ];
  const ins = db.prepare('INSERT INTO operaciones(codigo,tipo_id,titulo,descripcion,prioridad,estado,responsable_id,creado_por,reporte_codigo,fecha_limite,resultado,creado,actualizado,cerrado) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)');
  const sup = u('supervisor');
  ops.forEach(([cod, tit, tp, pri, est, resp, lim, edad, rep, desc], i) => {
    const creado = t - edad, cerrado = est === 'Completada' ? t - 12 * HORA : null;
    const id = ins.run(cod, tipo(tp), tit, desc, pri, est, resp ? u(resp) : null, sup, rep, t + lim, est === 'Completada' ? 'Medidor reemplazado y probado.' : null, creado, t - (i + 1) * HORA, cerrado).lastInsertRowid;
    bit(cod, 'Operación creada', null, { estado: 'Creada', tipo: tp, prioridad: pri }, tit, creado);
    if (resp) {
      db.prepare('INSERT INTO asignaciones(operacion_id,responsable_id,asignado_por,fecha,motivo) VALUES(?,?,?,?,?)').run(id, u(resp), sup, creado + HORA, '');
      bit(cod, 'Responsable asignado', null, { responsable: resp + '@aguaclara.do' }, '', creado + HORA);
    }
    if (est !== 'Creada') bit(cod, 'Cambio de estado', { estado: 'Creada' }, { estado: est }, '', creado + 2 * HORA);
    if (est === 'Rechazada') {
      db.prepare('INSERT INTO aprobaciones(operacion_id,aprobador_id,decision,comentario,fecha) VALUES(?,?,?,?,?)').run(id, sup, 'Rechazada', 'Falta el presupuesto de materiales.', t - 3 * HORA);
      bit(cod, 'Aprobación: Rechazada', { estado: 'En aprobación' }, { estado: 'Rechazada' }, 'Falta el presupuesto de materiales.', t - 3 * HORA);
    }
  });
  const op2 = db.prepare("SELECT id FROM operaciones WHERE codigo='OP-0002'").get().id;
  db.prepare('INSERT INTO incidencias(codigo,operacion_id,categoria,descripcion,prioridad,responsable_id,estado,creado_por,creado,actualizado) VALUES(?,?,?,?,?,?,?,?,?,?)')
    .run('INC-0001', op2, 'Falta de materiales', 'No hay repuesto de válvula en el almacén; se debe pedir al proveedor.', 'Alta', u('agente'), 'Abierta', u('agente'), t - 2 * HORA, t - 2 * HORA);
  db.prepare('INSERT INTO bitacora(fecha,actor_id,actor,entidad,entidad_id,operacion,accion,resultado,despues,detalle) VALUES(?,?,?,?,?,?,?,?,?,?)')
    .run(t - 2 * HORA, null, 'sistema (datos de demostración)', 'incidencia', 'INC-0001', 'OP-0002', 'Incidencia registrada', 'Exitoso', JSON.stringify({ estado: 'Abierta', prioridad: 'Alta' }), 'Falta de materiales');
}

// Migración idempotente: agrega lo de la Épica 2 a bases creadas antes (o a una base nueva)
function migrarEpica2(db, seedDemo) {
  db.exec(SCHEMA_E2);
  const cfg = (k, v) => db.prepare('INSERT OR IGNORE INTO config(clave,valor) VALUES(?,?)').run(k, v);
  cfg('ventanaAlertaH', '12');
  ROLES_E2.forEach((n) => db.prepare('INSERT OR IGNORE INTO roles(nombre) VALUES(?)').run(n));
  const insP = db.prepare('INSERT OR IGNORE INTO permisos(rol_id,modulo,crear,consultar,modificar,eliminar) VALUES(?,?,?,?,?,?)');
  db.prepare('SELECT id, nombre FROM roles').all().forEach((r) => {
    const p = permisosIniciales(r.nombre);
    MODULOS.forEach((m) => insP.run(r.id, m, p[m].c, p[m].r, p[m].u, p[m].d));
  });
  if (!db.prepare('SELECT COUNT(*) n FROM tipos_operacion').get().n) {
    const rolSup = db.prepare("SELECT id FROM roles WHERE nombre='Supervisor'").get().id;
    const ins = db.prepare('INSERT INTO tipos_operacion(nombre,sla_horas,aviso_horas,requiere_aprobacion,aprobador_rol_id) VALUES(?,?,?,?,?)');
    ins.run('Reparación de fuga', 48, 12, 0, null);
    ins.run('Restablecer suministro', 24, 6, 0, null);
    ins.run('Reparación de tubería', 72, 24, 1, rolSup);
    ins.run('Inspección de campo', 96, 24, 0, null);
  }
  if (seedDemo && !db.prepare("SELECT 1 FROM config WHERE clave='demo_e2'").get()) {
    const h = hash('Demo123*'), ins = db.prepare('INSERT OR IGNORE INTO usuarios(nombre,correo,telefono,clave_hash,rol_id,actualizado) VALUES(?,?,?,?,?,?)');
    [['Alberto Auditor', 'auditor', 'Auditor'], ['Gloria Gerente', 'gerente', 'Gerente']].forEach(([n, c, rol], i) =>
      ins.run(n, c + '@aguaclara.do', '809-555-020' + i, h, db.prepare('SELECT id FROM roles WHERE nombre=?').get(rol).id, Date.now()));
    if (!db.prepare('SELECT COUNT(*) n FROM operaciones').get().n) db.transaction(() => sembrarOperacionesDemo(db))();
    cfg('demo_e2', '1');
  }
}

function open(file, opt = {}) {
  const db = new Database(file);
  db.pragma('journal_mode = WAL');
  db.pragma('foreign_keys = ON');
  db.exec(SCHEMA);
  const ahora = Date.now(), seedDemo = (opt.seedDemo ?? process.env.SEED_DEMO ?? '1') !== '0';
  if (!db.prepare('SELECT COUNT(*) n FROM roles').get().n) {
    const insR = db.prepare('INSERT INTO roles(nombre) VALUES(?)');
    const insP = db.prepare('INSERT INTO permisos(rol_id,modulo,crear,consultar,modificar,eliminar) VALUES(?,?,?,?,?,?)');
    db.transaction(() => {
      ROLES.concat(ROLES_E2).forEach((nombre) => {
        const id = insR.run(nombre).lastInsertRowid, p = permisosIniciales(nombre);
        MODULOS.forEach((m) => insP.run(id, m, p[m].c, p[m].r, p[m].u, p[m].d));
      });
      db.prepare("INSERT INTO config VALUES('resetMin','15')").run();
    })();
  }
  if (!db.prepare('SELECT COUNT(*) n FROM usuarios').get().n) {
    const rolId = (n) => db.prepare('SELECT id FROM roles WHERE nombre=?').get(n).id;
    const insU = db.prepare('INSERT INTO usuarios(nombre,correo,telefono,clave_hash,rol_id,actualizado) VALUES(?,?,?,?,?,?)');
    if (seedDemo) {
      const h = hash('Demo123*');
      [['Super Admin', 'super'], ['Ana Administradora', 'admin'], ['Agustín Agente', 'agente'], ['Aurora Arquitecta', 'arquitecto'],
       ['Iván Ingeniero', 'ingeniero'], ['Clara Cliente', 'cliente'], ['Sergio Supervisor', 'supervisor']]
        .forEach(([n, c], i) => insU.run(n, c + '@aguaclara.do', '809-555-010' + i, h, rolId(ROLES[i]), ahora));
      db.prepare('INSERT INTO reportes(codigo,municipio,sector,tipo,desde,descripcion,estado,creado) VALUES(?,?,?,?,?,?,?,?)')
        .run('DEMO-001', 'Santo Domingo Este', 'Alma Rosa', TIPOS[1], '2026-10-02',
          'Hay una fuga de agua en la calle principal del sector. El agua se acumula junto a la acera.', 0, ahora);
    } else if (process.env.ADMIN_EMAIL && process.env.ADMIN_PASSWORD) {
      insU.run('Administrador', process.env.ADMIN_EMAIL, '', hash(process.env.ADMIN_PASSWORD), rolId(ROLES[0]), ahora);
    }
  }
  migrarEpica2(db, seedDemo);
  return db;
}

module.exports = { open, hash, MODULOS, MODN, TIPOS, ROLES };
