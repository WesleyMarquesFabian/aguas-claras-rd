// Épica 2 – Gestión de Operaciones. Todas las reglas de negocio se validan aquí, en el servidor.
const ESTADOS = ['Creada', 'En proceso', 'En aprobación', 'Completada', 'Rechazada', 'Cerrada', 'Cancelada'];
const TERMINAL = ['Completada', 'Cerrada', 'Cancelada']; // ya no pueden vencer
const PRIORIDADES = ['Baja', 'Media', 'Alta', 'Crítica'];
// Transiciones que se piden con "cambiar estado". Las de "En aprobación" solo salen por la decisión del aprobador.
const TRANS = {
  'Creada': ['En proceso', 'Cancelada'],
  'En proceso': ['En aprobación', 'Completada', 'Cancelada'],
  'En aprobación': [],
  'Completada': ['Cerrada'],
  'Rechazada': ['En proceso', 'Cancelada'],
  'Cerrada': [], 'Cancelada': [],
};
const INC_ESTADOS = ['Abierta', 'En atención', 'Resuelta'];
const INC_TRANS = { 'Abierta': ['En atención'], 'En atención': ['Resuelta'], 'Resuelta': ['En atención'] };
const HORA = 3600e3;

module.exports = function registrar(app, c) {
  const { db, audit, need, auth, bad, txt, now, permsOf, MODN } = c;

  // ---------- utilidades ----------
  const ms = (s, fin) => {
    if (!/^\d{4}-\d{2}-\d{2}$/.test(String(s || ''))) return 0;
    const t = Date.parse(s + (fin ? 'T23:59:59.999' : 'T00:00:00'));
    return isNaN(t) ? 0 : t;
  };
  const js = (o) => (o ? JSON.stringify(o) : null);
  function bit(req, entidad, id, operacion, accion, resultado, antes, despues, detalle) {
    db.prepare('INSERT INTO bitacora(fecha,actor_id,actor,entidad,entidad_id,operacion,accion,resultado,antes,despues,detalle) VALUES(?,?,?,?,?,?,?,?,?,?,?)')
      .run(now(), req && req.u ? req.u.id : null, req && req.u ? req.u.correo : 'sistema', entidad, String(id), operacion || null, accion, resultado || 'Exitoso', js(antes), js(despues), detalle || '');
  }
  // Una regla de negocio incumplida se informa y también queda en la bitácora como "Rechazado"
  const rechazar = (req, res, entidad, id, operacion, accion, msg, code = 409) => {
    bit(req, entidad, id, operacion, accion, 'Rechazado', null, null, msg);
    return bad(res, msg, code);
  };
  const notif = (usuarioId, tipo, operacionId, mensaje) => {
    if (usuarioId) db.prepare('INSERT INTO notificaciones(usuario_id,tipo,operacion_id,mensaje,fecha) VALUES(?,?,?,?,?)').run(usuarioId, tipo, operacionId || null, mensaje, now());
  };
  const cfg = (k) => (db.prepare('SELECT valor FROM config WHERE clave=?').get(k) || {}).valor;
  const siguiente = (tabla, prefijo) => {
    const n = db.prepare(`SELECT COALESCE(MAX(id),0)+1 n FROM ${tabla}`).get().n;
    return prefijo + String(n).padStart(4, '0');
  };

  // ---------- operaciones: consulta, filtros e indicadores ----------
  const SEL = `SELECT o.*, t.nombre tipo, t.requiere_aprobacion req_aprob, t.aprobador_rol_id, t.aviso_horas,
    ur.nombre resp_nombre, uc.nombre creador FROM operaciones o JOIN tipos_operacion t ON t.id=o.tipo_id
    LEFT JOIN usuarios ur ON ur.id=o.responsable_id LEFT JOIN usuarios uc ON uc.id=o.creado_por`;
  const vencida = (o) => !TERMINAL.includes(o.estado) && o.fecha_limite < now();
  const porVencer = (o) => !TERMINAL.includes(o.estado) && !vencida(o) && o.fecha_limite - now() <= o.aviso_horas * HORA;
  const OP = (o) => ({
    codigo: o.codigo, titulo: o.titulo, descripcion: o.descripcion, tipo: o.tipo, tipo_id: o.tipo_id, prioridad: o.prioridad, estado: o.estado,
    responsable: o.responsable_id ? { id: o.responsable_id, nombre: o.resp_nombre } : null, creador: o.creador || '—',
    reporte: o.reporte_codigo, limite: o.fecha_limite, resultado: o.resultado, creado: o.creado, actualizado: o.actualizado, cerrado: o.cerrado,
    requiereAprob: !!o.req_aprob, vencida: vencida(o), porVencer: porVencer(o),
  });
  function filtrar(q) {
    const w = [], a = [];
    if (ESTADOS.includes(q.estado)) { w.push('o.estado=?'); a.push(q.estado); }
    if (q.grupo === 'completadas') w.push("o.estado IN ('Completada','Cerrada')"); // mismo criterio del indicador "completadas"
    if (+q.tipo) { w.push('o.tipo_id=?'); a.push(+q.tipo); }
    if (q.responsable === 'sin') w.push('o.responsable_id IS NULL');
    else if (+q.responsable) { w.push('o.responsable_id=?'); a.push(+q.responsable); }
    const d = ms(q.desde), h = ms(q.hasta, true);
    if (d) { w.push('o.creado>=?'); a.push(d); }
    if (h) { w.push('o.creado<=?'); a.push(h); }
    if (q.q) { const l = '%' + txt(q.q, 60) + '%'; w.push('(o.codigo LIKE ? OR o.titulo LIKE ?)'); a.push(l, l); }
    const rows = db.prepare(SEL + (w.length ? ' WHERE ' + w.join(' AND ') : '') + ' ORDER BY o.id DESC').all(...a).map(OP);
    return q.vencidas === '1' ? rows.filter((r) => r.vencida) : rows;
  }
  const indicadores = (rows) => ({
    creadas: rows.length,
    en_proceso: rows.filter((r) => r.estado === 'En proceso').length,
    completadas: rows.filter((r) => r.estado === 'Completada' || r.estado === 'Cerrada').length,
    rechazadas: rows.filter((r) => r.estado === 'Rechazada').length,
    vencidas: rows.filter((r) => r.vencida).length,
    por_vencer: rows.filter((r) => r.porVencer).length,
  });
  const getOp = (codigo) => db.prepare(SEL + ' WHERE o.codigo=?').get(txt(codigo, 20).toUpperCase());

  // Alcance: operadores solo modifican lo propio; quien puede asignar (supervisión) modifica todo
  const supervisa = (u) => !!u.perms.asignaciones.c;
  const propia = (u, o) => o.responsable_id === u.id || o.creado_por === u.id;
  const puedeEditar = (u, o) => !!u.perms.operaciones.u && (supervisa(u) || propia(u, o));
  const responsableValido = (id) => {
    const r = db.prepare("SELECT u.id, u.nombre, r.id rol_id FROM usuarios u JOIN roles r ON r.id=u.rol_id WHERE u.id=? AND u.estado='Activo' AND r.activo=1").get(+id);
    return r && permsOf(r.rol_id).operaciones.u ? r : null;
  };
  const puedeAprobar = (u, o) => !!u.perms.aprobaciones.u && (!o.aprobador_rol_id || o.aprobador_rol_id === u.rolId || u.rol === 'Super Administrador');

  // HU-2.1 Panel + listado (los indicadores se calculan sobre exactamente las mismas filas que se listan)
  app.get('/api/operaciones', need('operaciones', 'r'), (req, res) => {
    const items = filtrar(req.query);
    res.json({ items, indicadores: indicadores(items), actualizado: items.reduce((m, o) => Math.max(m, o.actualizado), 0) || null, generado: now() });
  });
  app.get('/api/responsables', need('operaciones', 'r'), (req, res) =>
    res.json({ items: db.prepare("SELECT u.id, u.nombre, r.nombre rol, r.id rol_id FROM usuarios u JOIN roles r ON r.id=u.rol_id WHERE u.estado='Activo' AND r.activo=1 ORDER BY u.nombre").all()
      .filter((r) => permsOf(r.rol_id).operaciones.u).map((r) => ({ id: r.id, nombre: r.nombre, rol: r.rol })) }));

  app.get('/api/operaciones/:codigo', need('operaciones', 'r'), (req, res) => {
    const o = getOp(req.params.codigo);
    if (!o) return bad(res, 'Operación no encontrada.', 404);
    const ed = puedeEditar(req.u, o);
    let trans = ed ? (TRANS[o.estado] || []).filter((e) => !(e === 'En aprobación' && !o.req_aprob) && !(e === 'Completada' && o.req_aprob)) : [];
    res.json({
      item: OP(o), transiciones: trans, puedeEditar: ed && !['Cerrada', 'Cancelada'].includes(o.estado),
      puedeAsignar: !!req.u.perms.asignaciones.c && !TERMINAL.includes(o.estado) && o.estado !== 'Cerrada',
      puedeAprobar: o.estado === 'En aprobación' && puedeAprobar(req.u, o) && o.responsable_id !== req.u.id,
      historial: db.prepare('SELECT * FROM bitacora WHERE operacion=? ORDER BY id DESC LIMIT 200').all(o.codigo)
        .map((b) => ({ t: b.fecha, actor: b.actor, entidad: b.entidad, accion: b.accion, resultado: b.resultado, antes: b.antes, despues: b.despues, det: b.detalle })),
      asignaciones: db.prepare('SELECT a.fecha, a.motivo, r.nombre responsable, p.nombre asignado_por FROM asignaciones a LEFT JOIN usuarios r ON r.id=a.responsable_id LEFT JOIN usuarios p ON p.id=a.asignado_por WHERE a.operacion_id=? ORDER BY a.id DESC').all(o.id),
      aprobaciones: db.prepare('SELECT a.fecha, a.decision, a.comentario, u.nombre aprobador FROM aprobaciones a LEFT JOIN usuarios u ON u.id=a.aprobador_id WHERE a.operacion_id=? ORDER BY a.id DESC').all(o.id),
      incidencias: db.prepare('SELECT codigo, categoria, prioridad, estado FROM incidencias WHERE operacion_id=? ORDER BY id DESC').all(o.id),
    });
  });

  // HU-2.2 Registro
  app.post('/api/operaciones', need('operaciones', 'c'), (req, res) => {
    const b = req.body, titulo = txt(b.titulo, 120), desc = txt(b.descripcion, 1000), pri = PRIORIDADES.includes(b.prioridad) ? b.prioridad : 'Media';
    const tipo = db.prepare('SELECT * FROM tipos_operacion WHERE id=? AND activo=1').get(+b.tipo_id);
    const fail = (m, code = 400) => rechazar(req, res, 'operacion', 'nueva', null, 'Crear operación', m, code);
    if (!tipo) return fail('Elige un tipo de operación activo.');
    if (titulo.length < 5) return fail('El título necesita al menos 5 caracteres.');
    if (desc.length < 10) return fail('La descripción necesita al menos 10 caracteres.');
    let limite = b.fecha_limite ? Date.parse(b.fecha_limite) : now() + tipo.sla_horas * HORA; // por defecto, el plazo (SLA) del tipo
    if (isNaN(limite)) return fail('La fecha límite no es válida.');
    if (limite <= now()) return fail('La fecha límite debe ser posterior a este momento.');
    let resp = null;
    if (b.responsable_id) { resp = responsableValido(b.responsable_id); if (!resp) return fail('Ese usuario no puede ser responsable (inactivo o sin permiso operativo).'); if (!supervisa(req.u) && resp.id !== req.u.id) return fail('Solo supervisión puede asignar la operación a otra persona.', 403); }
    const rep = txt(b.reporte_codigo, 20).toUpperCase() || null;
    if (rep && !db.prepare('SELECT 1 FROM reportes WHERE codigo=?').get(rep)) return fail('El reporte ciudadano vinculado no existe.');
    const codigo = siguiente('operaciones', 'OP-'), t = now();
    const id = db.transaction(() => {
      const id = db.prepare('INSERT INTO operaciones(codigo,tipo_id,titulo,descripcion,prioridad,estado,responsable_id,creado_por,reporte_codigo,fecha_limite,creado,actualizado) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)')
        .run(codigo, tipo.id, titulo, desc, pri, 'Creada', resp ? resp.id : null, req.u.id, rep, limite, t, t).lastInsertRowid;
      bit(req, 'operacion', codigo, codigo, 'Operación creada', 'Exitoso', null, { estado: 'Creada', tipo: tipo.nombre, prioridad: pri, limite: new Date(limite).toISOString() }, titulo);
      if (resp) {
        db.prepare('INSERT INTO asignaciones(operacion_id,responsable_id,asignado_por,fecha,motivo) VALUES(?,?,?,?,?)').run(id, resp.id, req.u.id, t, '');
        bit(req, 'operacion', codigo, codigo, 'Responsable asignado', 'Exitoso', null, { responsable: resp.nombre }, '');
        if (resp.id !== req.u.id) notif(resp.id, 'Asignación', id, `Se te asignó la operación ${codigo}: ${titulo}`);
      }
      return id;
    })();
    res.status(201).json({ ok: true, codigo, id });
  });

  // Actualizar datos (título, descripción, prioridad, fecha límite)
  app.put('/api/operaciones/:codigo', need('operaciones', 'u'), (req, res) => {
    const o = getOp(req.params.codigo);
    if (!o) return bad(res, 'Operación no encontrada.', 404);
    const fail = (m, code = 409) => rechazar(req, res, 'operacion', o.codigo, o.codigo, 'Actualizar operación', m, code);
    if (!puedeEditar(req.u, o)) return fail('Solo el responsable, quien la creó o supervisión puede modificar esta operación.', 403);
    if (['Cerrada', 'Cancelada'].includes(o.estado)) return fail(`Una operación ${o.estado.toLowerCase()} ya no se puede modificar.`);
    const b = req.body, titulo = b.titulo === undefined ? o.titulo : txt(b.titulo, 120), desc = b.descripcion === undefined ? o.descripcion : txt(b.descripcion, 1000);
    const pri = b.prioridad === undefined ? o.prioridad : b.prioridad;
    if (titulo.length < 5) return fail('El título necesita al menos 5 caracteres.', 400);
    if (desc.length < 10) return fail('La descripción necesita al menos 10 caracteres.', 400);
    if (!PRIORIDADES.includes(pri)) return fail('Prioridad inválida.', 400);
    let limite = o.fecha_limite;
    if (b.fecha_limite) { limite = Date.parse(b.fecha_limite); if (isNaN(limite)) return fail('La fecha límite no es válida.', 400); if (limite <= now() && limite !== o.fecha_limite) return fail('La nueva fecha límite debe ser posterior a este momento.', 400); }
    const antes = { titulo: o.titulo, descripcion: o.descripcion, prioridad: o.prioridad, limite: new Date(o.fecha_limite).toISOString() };
    const despues = { titulo, descripcion: desc, prioridad: pri, limite: new Date(limite).toISOString() };
    if (JSON.stringify(antes) === JSON.stringify(despues)) return fail('No hay cambios que guardar.', 400);
    db.prepare('UPDATE operaciones SET titulo=?, descripcion=?, prioridad=?, fecha_limite=?, actualizado=? WHERE id=?').run(titulo, desc, pri, limite, now(), o.id);
    bit(req, 'operacion', o.codigo, o.codigo, 'Operación actualizada', 'Exitoso', antes, despues, '');
    res.json({ ok: true });
  });

  // HU-2.2 Cambio de estado con reglas de negocio
  app.post('/api/operaciones/:codigo/estado', need('operaciones', 'u'), (req, res) => {
    const o = getOp(req.params.codigo);
    if (!o) return bad(res, 'Operación no encontrada.', 404);
    const nuevo = txt(req.body.estado, 30), motivo = txt(req.body.motivo, 300), resultado = txt(req.body.resultado, 500);
    const fail = (m, code = 409) => rechazar(req, res, 'operacion', o.codigo, o.codigo, `Cambio de estado a "${nuevo}"`, m, code);
    if (!puedeEditar(req.u, o)) return fail('Solo el responsable, quien la creó o supervisión puede modificar esta operación.', 403);
    if (!(TRANS[o.estado] || []).includes(nuevo)) return fail(`Transición no permitida: ${o.estado} → ${nuevo}.`);
    if (nuevo === 'En proceso' && !o.responsable_id) return fail('Asigna un responsable antes de iniciar la operación.');
    if (nuevo === 'En aprobación' && !o.req_aprob) return fail('Este tipo de operación no requiere aprobación.');
    if (nuevo === 'Completada' && o.req_aprob) return fail('Este tipo de operación requiere aprobación: envíala primero a "En aprobación".');
    if (nuevo === 'Cancelada' && motivo.length < 5) return fail('Escribe el motivo de la cancelación (mínimo 5 caracteres).', 400);
    if (o.estado === 'Rechazada' && nuevo === 'En proceso' && motivo.length < 5) return fail('Escribe el motivo de la reapertura (mínimo 5 caracteres).', 400);
    if (nuevo === 'Cerrada') {
      if (resultado.length < 5) return fail('Describe el resultado para cerrar la operación (mínimo 5 caracteres).', 400);
      const ab = db.prepare("SELECT COUNT(*) n FROM incidencias WHERE operacion_id=? AND estado!='Resuelta'").get(o.id).n;
      if (ab) return fail(`No se puede cerrar: tiene ${ab} incidencia(s) sin resolver.`);
    }
    const t = now(), fin = ['Completada', 'Cancelada'].includes(nuevo) ? t : o.cerrado;
    db.transaction(() => {
      db.prepare('UPDATE operaciones SET estado=?, actualizado=?, cerrado=?, resultado=COALESCE(?, resultado) WHERE id=?').run(nuevo, t, fin, resultado || null, o.id);
      bit(req, 'operacion', o.codigo, o.codigo, 'Cambio de estado', 'Exitoso', { estado: o.estado }, { estado: nuevo }, motivo || resultado);
      if (nuevo === 'En aprobación') {
        db.prepare("SELECT id, rol_id FROM usuarios WHERE estado='Activo'").all()
          .filter((u) => u.id !== o.responsable_id && (!o.aprobador_rol_id || u.rol_id === o.aprobador_rol_id) && permsOf(u.rol_id).aprobaciones.u)
          .forEach((u) => notif(u.id, 'Aprobación', o.id, `La operación ${o.codigo} espera tu aprobación.`));
      }
    })();
    res.json({ ok: true });
  });

  // HU-2.3 Asignación de responsables
  app.post('/api/operaciones/:codigo/asignar', need('asignaciones', 'c'), (req, res) => {
    const o = getOp(req.params.codigo);
    if (!o) return bad(res, 'Operación no encontrada.', 404);
    const motivo = txt(req.body.motivo, 300);
    const fail = (m, code = 409) => rechazar(req, res, 'operacion', o.codigo, o.codigo, 'Asignar responsable', m, code);
    if (TERMINAL.includes(o.estado)) return fail(`No se puede asignar una operación ${o.estado.toLowerCase()}.`);
    const r = responsableValido(req.body.responsable_id);
    if (!r) return fail('Ese usuario no puede ser responsable (inactivo o sin permiso operativo).', 400);
    if (o.responsable_id === r.id) return fail('Esa persona ya es la responsable de la operación.');
    if (o.responsable_id && motivo.length < 5) return fail('Para reasignar escribe el motivo (mínimo 5 caracteres).', 400);
    db.transaction(() => {
      db.prepare('UPDATE operaciones SET responsable_id=?, actualizado=? WHERE id=?').run(r.id, now(), o.id);
      db.prepare('INSERT INTO asignaciones(operacion_id,responsable_id,asignado_por,fecha,motivo) VALUES(?,?,?,?,?)').run(o.id, r.id, req.u.id, now(), motivo);
      bit(req, 'operacion', o.codigo, o.codigo, o.responsable_id ? 'Responsable reasignado' : 'Responsable asignado', 'Exitoso',
        { responsable: o.resp_nombre || null }, { responsable: r.nombre }, motivo);
      notif(r.id, 'Asignación', o.id, `Se te asignó la operación ${o.codigo}: ${o.titulo}`);
      if (o.responsable_id) notif(o.responsable_id, 'Reasignación', o.id, `La operación ${o.codigo} fue reasignada a otra persona.`);
    })();
    res.json({ ok: true });
  });

  // HU-2.4 Aprobaciones
  app.post('/api/operaciones/:codigo/aprobacion', need('aprobaciones', 'u'), (req, res) => {
    const o = getOp(req.params.codigo);
    if (!o) return bad(res, 'Operación no encontrada.', 404);
    const dec = txt(req.body.decision, 20), com = txt(req.body.comentario, 300);
    const fail = (m, code = 409) => rechazar(req, res, 'operacion', o.codigo, o.codigo, `Decisión de aprobación "${dec}"`, m, code);
    if (!['Aprobada', 'Rechazada', 'Devuelta'].includes(dec)) return fail('Decisión inválida.', 400);
    if (o.estado !== 'En aprobación') return fail(`La operación está en "${o.estado}", no en aprobación.`);
    if (!puedeAprobar(req.u, o)) return fail('Tu rol no es el aprobador configurado para este tipo de operación.', 403);
    if (o.responsable_id === req.u.id) return fail('No puedes decidir sobre una operación que tienes asignada.');
    if (dec !== 'Aprobada' && com.length < 5) return fail('Escribe el motivo (mínimo 5 caracteres) para rechazar o devolver.', 400);
    const nuevo = { Aprobada: 'Completada', Rechazada: 'Rechazada', Devuelta: 'En proceso' }[dec], t = now();
    db.transaction(() => {
      db.prepare('INSERT INTO aprobaciones(operacion_id,aprobador_id,decision,comentario,fecha) VALUES(?,?,?,?,?)').run(o.id, req.u.id, dec, com, t);
      db.prepare('UPDATE operaciones SET estado=?, actualizado=?, cerrado=? WHERE id=?').run(nuevo, t, dec === 'Aprobada' ? t : o.cerrado, o.id);
      bit(req, 'operacion', o.codigo, o.codigo, `Aprobación: ${dec}`, 'Exitoso', { estado: o.estado }, { estado: nuevo }, com);
      notif(o.responsable_id, 'Aprobación', o.id, `Tu operación ${o.codigo} fue ${dec.toLowerCase()}${com ? ': ' + com : '.'}`);
    })();
    res.json({ ok: true, estado: nuevo });
  });
  app.get('/api/aprobaciones', need('aprobaciones', 'r'), (req, res) => {
    const pend = db.prepare(SEL + " WHERE o.estado='En aprobación' ORDER BY o.actualizado").all()
      .filter((o) => !o.aprobador_rol_id || o.aprobador_rol_id === req.u.rolId || req.u.rol === 'Super Administrador' || req.u.rol === 'Administrador').map(OP);
    const hist = db.prepare('SELECT a.fecha, a.decision, a.comentario, u.nombre aprobador, o.codigo FROM aprobaciones a JOIN operaciones o ON o.id=a.operacion_id LEFT JOIN usuarios u ON u.id=a.aprobador_id ORDER BY a.id DESC LIMIT 30').all();
    res.json({ pendientes: pend.map((o) => ({ ...o, puedeAprobar: puedeAprobar(req.u, getOp(o.codigo)) && o.responsable?.id !== req.u.id })), historial: hist });
  });

  // HU-2.4 / HU-2.5 Tipos de operación: plazos (SLA), aviso y flujo de aprobación
  const TIPO = (t) => ({ id: t.id, nombre: t.nombre, sla: t.sla_horas, aviso: t.aviso_horas, aprob: !!t.requiere_aprobacion, aprobador: t.aprobador_rol_id, aprobador_nombre: t.rol, activo: !!t.activo });
  app.get('/api/tipos', auth, (req, res) =>
    res.json({ items: db.prepare('SELECT t.*, r.nombre rol FROM tipos_operacion t LEFT JOIN roles r ON r.id=t.aprobador_rol_id ORDER BY t.id').all().map(TIPO), ventanaH: +cfg('ventanaAlertaH') }));
  function validarTipo(b, fail) {
    const sla = Math.round(+b.sla), aviso = Math.round(+b.aviso), aprob = b.aprob ? 1 : 0;
    if (!(sla >= 1 && sla <= 8760)) return fail('El plazo (SLA) debe estar entre 1 y 8760 horas.');
    if (!(aviso >= 0 && aviso <= sla)) return fail('El aviso previo debe estar entre 0 y el plazo del tipo.');
    let rolId = null;
    if (aprob) {
      const r = db.prepare('SELECT * FROM roles WHERE id=? AND activo=1').get(+b.aprobador);
      if (!r) return fail('Elige el rol que aprueba este tipo de operación.');
      if (!permsOf(r.id).aprobaciones.u) return fail(`El rol ${r.nombre} no tiene permiso para aprobar.`);
      rolId = r.id;
    }
    return { sla, aviso, aprob, rolId };
  }
  app.post('/api/tipos', need('tipos', 'c'), (req, res) => {
    const nombre = txt(req.body.nombre, 60), fail = (m) => rechazar(req, res, 'tipo', 'nuevo', null, 'Crear tipo', m, 400);
    if (nombre.length < 3) return fail('Escribe el nombre del tipo (mínimo 3 caracteres).');
    if (db.prepare('SELECT 1 FROM tipos_operacion WHERE nombre=?').get(nombre)) return rechazar(req, res, 'tipo', nombre, null, 'Crear tipo', 'Ese tipo ya existe.', 409);
    const v = validarTipo(req.body, fail); if (!v.sla) return;
    const id = db.prepare('INSERT INTO tipos_operacion(nombre,sla_horas,aviso_horas,requiere_aprobacion,aprobador_rol_id) VALUES(?,?,?,?,?)').run(nombre, v.sla, v.aviso, v.aprob, v.rolId).lastInsertRowid;
    bit(req, 'tipo', id, null, 'Tipo creado', 'Exitoso', null, { nombre, sla: v.sla, aviso: v.aviso, aprobacion: !!v.aprob }, '');
    res.status(201).json({ ok: true });
  });
  app.put('/api/tipos/:id', need('tipos', 'u'), (req, res) => {
    const t = db.prepare('SELECT * FROM tipos_operacion WHERE id=?').get(+req.params.id);
    if (!t) return bad(res, 'Tipo no encontrado.', 404);
    const v = validarTipo(req.body, (m) => rechazar(req, res, 'tipo', t.id, null, 'Modificar tipo', m, 400)); if (!v.sla) return;
    const activo = req.body.activo === undefined ? t.activo : (req.body.activo ? 1 : 0);
    db.prepare('UPDATE tipos_operacion SET sla_horas=?, aviso_horas=?, requiere_aprobacion=?, aprobador_rol_id=?, activo=? WHERE id=?').run(v.sla, v.aviso, v.aprob, v.rolId, activo, t.id);
    bit(req, 'tipo', t.id, null, 'Tipo modificado', 'Exitoso',
      { nombre: t.nombre, sla: t.sla_horas, aviso: t.aviso_horas, aprobacion: !!t.requiere_aprobacion, activo: !!t.activo },
      { nombre: t.nombre, sla: v.sla, aviso: v.aviso, aprobacion: !!v.aprob, activo: !!activo }, '');
    res.json({ ok: true });
  });

  // HU-2.5 Alertas y vencimientos
  function generarAlertas(req) {
    const ventana = +cfg('ventanaAlertaH') * HORA, t = now();
    let creadas = 0, omitidas = 0;
    db.prepare(SEL + " WHERE o.estado NOT IN ('Completada','Cerrada','Cancelada') AND o.responsable_id IS NOT NULL").all().forEach((o) => {
      const tipo = vencida(o) ? 'Vencida' : porVencer(o) ? 'Por vencer' : null;
      if (!tipo) return;
      const dup = db.prepare('SELECT 1 FROM notificaciones WHERE tipo=? AND operacion_id=? AND usuario_id=? AND fecha>?').get(tipo, o.id, o.responsable_id, t - ventana);
      if (dup) { omitidas++; return; }
      const h = Math.max(0, Math.round((o.fecha_limite - t) / HORA));
      notif(o.responsable_id, tipo, o.id, tipo === 'Vencida' ? `La operación ${o.codigo} está vencida.` : `La operación ${o.codigo} vence en ${h} h.`);
      bit(req, 'alerta', o.codigo, o.codigo, `Alerta ${tipo.toLowerCase()}`, 'Entregada', null, null, `Canal interno → ${o.resp_nombre}`);
      creadas++;
    });
    return { creadas, omitidas };
  }
  app.post('/api/alertas/generar', need('operaciones', 'u'), (req, res) => res.json({ ok: true, ...generarAlertas(req) }));
  app.get('/api/alertas', need('operaciones', 'r'), (req, res) =>
    res.json({ items: db.prepare("SELECT n.fecha, n.tipo, n.canal, n.resultado, n.mensaje, u.nombre usuario, o.codigo FROM notificaciones n JOIN usuarios u ON u.id=n.usuario_id LEFT JOIN operaciones o ON o.id=n.operacion_id WHERE n.tipo IN ('Vencida','Por vencer') ORDER BY n.id DESC LIMIT 50").all() }));
  app.put('/api/alertas/config', need('tipos', 'u'), (req, res) => {
    const h = Math.round(+req.body.ventanaH);
    if (!(h >= 1 && h <= 168)) return rechazar(req, res, 'config', 'ventanaAlertaH', null, 'Configurar alertas', 'La ventana debe estar entre 1 y 168 horas.', 400);
    const antes = +cfg('ventanaAlertaH');
    db.prepare("UPDATE config SET valor=? WHERE clave='ventanaAlertaH'").run(String(h));
    bit(req, 'config', 'ventanaAlertaH', null, 'Ventana anti-duplicados modificada', 'Exitoso', { horas: antes }, { horas: h }, '');
    res.json({ ok: true });
  });
  app.get('/api/notificaciones', auth, (req, res) =>
    res.json({ items: db.prepare('SELECT n.id, n.fecha, n.tipo, n.mensaje, n.leida, o.codigo FROM notificaciones n LEFT JOIN operaciones o ON o.id=n.operacion_id WHERE n.usuario_id=? ORDER BY n.id DESC LIMIT 50').all(req.u.id),
      sinLeer: db.prepare('SELECT COUNT(*) n FROM notificaciones WHERE usuario_id=? AND leida=0').get(req.u.id).n }));
  app.put('/api/notificaciones/leidas', auth, (req, res) => { db.prepare('UPDATE notificaciones SET leida=1 WHERE usuario_id=?').run(req.u.id); res.json({ ok: true }); });

  // HU-2.6 Incidencias
  const INC = `SELECT i.*, o.codigo op, o.estado op_estado, r.nombre resp FROM incidencias i JOIN operaciones o ON o.id=i.operacion_id LEFT JOIN usuarios r ON r.id=i.responsable_id`;
  const incOut = (i) => ({ codigo: i.codigo, operacion: i.op, categoria: i.categoria, descripcion: i.descripcion, prioridad: i.prioridad, responsable: i.resp || '—', estado: i.estado, resolucion: i.resolucion, creado: i.creado, actualizado: i.actualizado });
  app.get('/api/incidencias', need('incidencias', 'r'), (req, res) => {
    const w = [], a = [];
    if (INC_ESTADOS.includes(req.query.estado)) { w.push('i.estado=?'); a.push(req.query.estado); }
    if (req.query.operacion) { w.push('o.codigo=?'); a.push(txt(req.query.operacion, 20).toUpperCase()); }
    res.json({ items: db.prepare(INC + (w.length ? ' WHERE ' + w.join(' AND ') : '') + ' ORDER BY i.id DESC').all(...a).map(incOut) });
  });
  app.get('/api/incidencias/:codigo', need('incidencias', 'r'), (req, res) => {
    const i = db.prepare(INC + ' WHERE i.codigo=?').get(txt(req.params.codigo, 20).toUpperCase());
    if (!i) return bad(res, 'Incidencia no encontrada.', 404);
    res.json({ item: incOut(i), transiciones: req.u.perms.incidencias.u ? INC_TRANS[i.estado] : [],
      comentarios: db.prepare('SELECT usuario, texto, fecha FROM incidencia_comentarios WHERE incidencia_id=? ORDER BY id').all(i.id),
      historial: db.prepare("SELECT fecha t, actor, accion, resultado, antes, despues, detalle det FROM bitacora WHERE entidad='incidencia' AND entidad_id=? ORDER BY id DESC").all(i.codigo) });
  });
  app.post('/api/incidencias', need('incidencias', 'c'), (req, res) => {
    const b = req.body, o = getOp(b.operacion), cat = txt(b.categoria, 60), desc = txt(b.descripcion, 1000), pri = PRIORIDADES.includes(b.prioridad) ? b.prioridad : 'Media';
    const fail = (m, code = 400) => rechazar(req, res, 'incidencia', 'nueva', o && o.codigo, 'Registrar incidencia', m, code);
    if (!o) return fail('Elige la operación a la que se vincula la incidencia.');
    if (['Cerrada', 'Cancelada'].includes(o.estado)) return fail(`La operación ${o.codigo} está ${o.estado.toLowerCase()}: no admite incidencias.`, 409);
    if (cat.length < 3) return fail('Escribe la categoría (mínimo 3 caracteres).');
    if (desc.length < 10) return fail('La descripción necesita al menos 10 caracteres.');
    let resp = null;
    if (b.responsable_id) { resp = responsableValido(b.responsable_id); if (!resp) return fail('Ese usuario no puede ser responsable (inactivo o sin permiso operativo).'); }
    const codigo = siguiente('incidencias', 'INC-'), t = now();
    db.transaction(() => {
      const id = db.prepare('INSERT INTO incidencias(codigo,operacion_id,categoria,descripcion,prioridad,responsable_id,creado_por,creado,actualizado) VALUES(?,?,?,?,?,?,?,?,?)').run(codigo, o.id, cat, desc, pri, resp ? resp.id : null, req.u.id, t, t).lastInsertRowid;
      bit(req, 'incidencia', codigo, o.codigo, 'Incidencia registrada', 'Exitoso', null, { estado: 'Abierta', categoria: cat, prioridad: pri }, desc);
      if (resp && resp.id !== req.u.id) notif(resp.id, 'Incidencia', o.id, `Se te asignó la incidencia ${codigo} de la operación ${o.codigo}.`);
    })();
    res.status(201).json({ ok: true, codigo });
  });
  app.post('/api/incidencias/:codigo/estado', need('incidencias', 'u'), (req, res) => {
    const i = db.prepare(INC + ' WHERE i.codigo=?').get(txt(req.params.codigo, 20).toUpperCase());
    if (!i) return bad(res, 'Incidencia no encontrada.', 404);
    const nuevo = txt(req.body.estado, 20), resol = txt(req.body.resolucion, 500);
    const fail = (m, code = 409) => rechazar(req, res, 'incidencia', i.codigo, i.op, `Cambio de estado a "${nuevo}"`, m, code);
    if (!(INC_TRANS[i.estado] || []).includes(nuevo)) return fail(`Transición no permitida: ${i.estado} → ${nuevo}.`);
    if (nuevo === 'Resuelta' && resol.length < 5) return fail('Documenta la resolución (mínimo 5 caracteres).', 400);
    db.prepare('UPDATE incidencias SET estado=?, resolucion=COALESCE(?, resolucion), actualizado=? WHERE id=?').run(nuevo, resol || null, now(), i.id);
    bit(req, 'incidencia', i.codigo, i.op, 'Cambio de estado', 'Exitoso', { estado: i.estado }, { estado: nuevo }, resol);
    res.json({ ok: true });
  });
  app.post('/api/incidencias/:codigo/comentarios', need('incidencias', 'u'), (req, res) => {
    const i = db.prepare(INC + ' WHERE i.codigo=?').get(txt(req.params.codigo, 20).toUpperCase()), texto = txt(req.body.texto, 500);
    if (!i) return bad(res, 'Incidencia no encontrada.', 404);
    if (texto.length < 3) return bad(res, 'Escribe el comentario (mínimo 3 caracteres).');
    db.prepare('INSERT INTO incidencia_comentarios(incidencia_id,usuario,texto,fecha) VALUES(?,?,?,?)').run(i.id, req.u.nombre, texto, now());
    bit(req, 'incidencia', i.codigo, i.op, 'Comentario agregado', 'Exitoso', null, null, texto);
    res.status(201).json({ ok: true });
  });

  // HU-2.7 Reportes operativos
  const DEFINICIONES = {
    total: 'Operaciones registradas que cumplen los filtros.',
    completadas: 'Operaciones en estado Completada o Cerrada.',
    vencidas: 'Operaciones que no están Completadas, Cerradas ni Canceladas y cuya fecha límite ya pasó.',
    cumplimiento: 'Porcentaje de operaciones completadas que terminaron en o antes de su fecha límite.',
    tasa_completadas: 'Completadas ÷ total de operaciones, en porcentaje.',
    tiempo_promedio_horas: 'Promedio de horas entre la creación y la finalización de las operaciones completadas.',
    incidencias_abiertas: 'Incidencias no resueltas vinculadas a las operaciones filtradas.',
  };
  const pct = (a, b) => (b ? Math.round((a / b) * 1000) / 10 : null);
  function construirInforme(q) {
    const rows = filtrar(q), raw = db.prepare('SELECT codigo, creado, cerrado, fecha_limite FROM operaciones').all();
    const cerr = Object.fromEntries(raw.map((r) => [r.codigo, r]));
    const comp = rows.filter((r) => r.estado === 'Completada' || r.estado === 'Cerrada');
    const aTiempo = comp.filter((r) => cerr[r.codigo].cerrado && cerr[r.codigo].cerrado <= cerr[r.codigo].fecha_limite).length;
    const horas = comp.filter((r) => cerr[r.codigo].cerrado).map((r) => (cerr[r.codigo].cerrado - cerr[r.codigo].creado) / HORA);
    const grupo = (key, vacio) => Object.values(rows.reduce((m, r) => {
      const k = key(r) || vacio; m[k] = m[k] || { nombre: k, total: 0, completadas: 0, vencidas: 0 };
      m[k].total++; if (r.estado === 'Completada' || r.estado === 'Cerrada') m[k].completadas++; if (r.vencida) m[k].vencidas++; return m;
    }, {}));
    const codigos = rows.map((r) => r.codigo);
    const abiertas = codigos.length ? db.prepare(`SELECT COUNT(*) n FROM incidencias i JOIN operaciones o ON o.id=i.operacion_id WHERE i.estado!='Resuelta' AND o.codigo IN (${codigos.map(() => '?').join(',')})`).get(...codigos).n : 0;
    return {
      filas: rows,
      metricas: { total: rows.length, completadas: comp.length, vencidas: rows.filter((r) => r.vencida).length, cumplimiento: pct(aTiempo, comp.length),
        tasa_completadas: pct(comp.length, rows.length), tiempo_promedio_horas: horas.length ? Math.round((horas.reduce((a, b) => a + b, 0) / horas.length) * 10) / 10 : null, incidencias_abiertas: abiertas },
      por_estado: ESTADOS.map((e) => ({ nombre: e, total: rows.filter((r) => r.estado === e).length })),
      por_tipo: grupo((r) => r.tipo, 'Sin tipo'), por_responsable: grupo((r) => r.responsable && r.responsable.nombre, 'Sin asignar'),
    };
  }
  const filtrosTexto = (q) => {
    const tipo = +q.tipo ? (db.prepare('SELECT nombre FROM tipos_operacion WHERE id=?').get(+q.tipo) || {}).nombre : null;
    const resp = +q.responsable ? (db.prepare('SELECT nombre FROM usuarios WHERE id=?').get(+q.responsable) || {}).nombre : q.responsable === 'sin' ? 'Sin asignar' : null;
    return { periodo: `${ms(q.desde) ? q.desde : 'inicio'} a ${ms(q.hasta, true) ? q.hasta : 'hoy'}`, estado: ESTADOS.includes(q.estado) ? q.estado : 'Todos', tipo: tipo || 'Todos', responsable: resp || 'Todos' };
  };
  app.get('/api/informes', need('informes', 'r'), (req, res) => {
    const inf = construirInforme(req.query), f = filtrosTexto(req.query);
    bit(req, 'informe', 'operaciones', null, 'Informe generado', 'Exitoso', null, f, `${inf.metricas.total} operaciones`);
    res.json({ ...inf, filtros: f, definiciones: DEFINICIONES, generado: now(), generado_por: req.u.nombre });
  });
  const csv = (v) => { let s = String(v == null ? '' : v); if (/^[=+\-@]/.test(s)) s = "'" + s; return /[",\n;]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s; };
  app.get('/api/informes/exportar', need('informes', 'c'), (req, res) => {
    const inf = construirInforme(req.query), f = filtrosTexto(req.query), t = new Date();
    const L = ['Reporte de operaciones - Agua Clara RD', `Generado,${csv(t.toISOString())}`, `Generado por,${csv(req.u.correo)}`,
      `Filtros,${csv(`Periodo: ${f.periodo} | Estado: ${f.estado} | Tipo: ${f.tipo} | Responsable: ${f.responsable}`)}`, '',
      'Codigo,Titulo,Tipo,Estado,Prioridad,Responsable,Fecha limite,Vencida,Creada'];
    inf.filas.forEach((o) => L.push([o.codigo, o.titulo, o.tipo, o.estado, o.prioridad, o.responsable ? o.responsable.nombre : 'Sin asignar', new Date(o.limite).toISOString(), o.vencida ? 'Sí' : 'No', new Date(o.creado).toISOString()].map(csv).join(',')));
    bit(req, 'informe', 'operaciones', null, 'Informe exportado (CSV)', 'Exitoso', null, f, `${inf.filas.length} filas`);
    res.set({ 'Content-Type': 'text/csv; charset=utf-8', 'Content-Disposition': `attachment; filename="operaciones-${t.toISOString().slice(0, 10)}.csv"` }).send('\uFEFF' + L.join('\r\n'));
  });

  // HU-2.8 Bitácora (solo lectura: la base de datos impide modificarla o eliminarla)
  app.get('/api/bitacora', need('bitacora', 'r'), (req, res) => {
    const w = [], a = [], q = req.query;
    if (q.operacion) { w.push('operacion=?'); a.push(txt(q.operacion, 20).toUpperCase()); }
    if (q.usuario) { w.push('actor LIKE ?'); a.push('%' + txt(q.usuario, 60) + '%'); }
    if (q.q) { const l = '%' + txt(q.q, 60) + '%'; w.push('(accion LIKE ? OR detalle LIKE ? OR entidad_id LIKE ?)'); a.push(l, l, l); }
    const d = ms(q.desde), h = ms(q.hasta, true);
    if (d) { w.push('fecha>=?'); a.push(d); }
    if (h) { w.push('fecha<=?'); a.push(h); }
    res.json({ items: db.prepare('SELECT * FROM bitacora' + (w.length ? ' WHERE ' + w.join(' AND ') : '') + ' ORDER BY id DESC LIMIT 500').all(...a)
      .map((b) => ({ id: b.id, t: b.fecha, actor: b.actor, entidad: b.entidad, ref: b.entidad_id, operacion: b.operacion, accion: b.accion, resultado: b.resultado, antes: b.antes, despues: b.despues, det: b.detalle })) });
  });

  return { generarAlertas };
};
