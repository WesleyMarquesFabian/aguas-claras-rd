// Pruebas de la API: acceso autorizado y no autorizado. Ejecutar con: npm test
process.env.NODE_ENV = 'test';
const test = require('node:test'), assert = require('node:assert/strict');
const os = require('os'), path = require('path'), fs = require('fs');
const { createApp } = require('../server/index.js');
const { open } = require('../server/db.js');

const file = path.join(os.tmpdir(), `ac-test-${process.pid}-${Date.now()}.db`);
const db = open(file, { seedDemo: true });
let server, base;
test.before(() => new Promise((ok) => { server = createApp(db, { modoDemo: true, alertas: false }).listen(0, () => { base = `http://127.0.0.1:${server.address().port}`; ok(); }); }));
test.after(() => { server.close(); db.close(); ['', '-wal', '-shm'].forEach((s) => fs.rmSync(file + s, { force: true })); });

async function call(method, url, body, cookie) {
  const r = await fetch(base + url, { method, headers: { 'Content-Type': 'application/json', ...(cookie ? { Cookie: cookie } : {}) }, body: body ? JSON.stringify(body) : undefined });
  const sc = r.headers.get('set-cookie');
  return { s: r.status, d: await r.json().catch(() => ({})), cookie: sc ? sc.split(';')[0] : null };
}
const login = async (u, p = 'Demo123*') => (await call('POST', '/api/login', { correo: `${u}@aguaclara.do`, clave: p })).cookie;
const ultimo = () => db.prepare('SELECT * FROM auditoria ORDER BY id DESC LIMIT 1').get();

test('HU-1.1 Login válido abre sesión, rol correcto y queda en auditoría', async () => {
  const c = await login('cliente'); assert.ok(c);
  assert.equal((await call('GET', '/api/me', null, c)).d.me.role, 'Cliente');
  assert.equal(db.prepare("SELECT COUNT(*) n FROM auditoria WHERE evento='Inicio de sesión' AND usuario='cliente@aguaclara.do'").get().n, 1);
});
test('HU-1.1 Credenciales inválidas: error 401 y sin sesión', async () => {
  const r = await call('POST', '/api/login', { correo: 'cliente@aguaclara.do', clave: 'mala' });
  assert.equal(r.s, 401); assert.equal(r.cookie, null);
});
test('HU-1.1 Intento de inyección SQL no abre sesión', async () => {
  const r = await call('POST', '/api/login', { correo: "' OR 1=1 --", clave: 'x' });
  assert.equal(r.s, 401);
});
test('HU-1.1 Tras 5 intentos fallidos el acceso se bloquea temporalmente', async () => {
  for (let i = 0; i < 5; i++) await call('POST', '/api/login', { correo: 'ingeniero@aguaclara.do', clave: 'mala' });
  assert.equal((await call('POST', '/api/login', { correo: 'ingeniero@aguaclara.do', clave: 'Demo123*' })).s, 429);
});
test('Sin sesión, la API privada responde 401', async () => {
  assert.equal((await call('GET', '/api/usuarios')).s, 401);
  assert.equal((await call('GET', '/api/auditoria')).s, 401);
});
test('Seguridad: las contraseñas se guardan cifradas (bcrypt), no en texto plano', () => {
  const h = db.prepare("SELECT clave_hash FROM usuarios WHERE correo='cliente@aguaclara.do'").get().clave_hash;
  assert.ok(h.startsWith('$2') && !h.includes('Demo123'));
});
test('HU-1.2 Correo duplicado es rechazado (409)', async () => {
  const c = await login('admin');
  const r = await call('POST', '/api/usuarios', { nombre: 'X', correo: 'cliente@aguaclara.do', clave: 'Clave12345', rol: 'Cliente' }, c);
  assert.equal(r.s, 409);
});
test('HU-1.2 El administrador crea un usuario en estado Activo', async () => {
  const c = await login('admin');
  assert.equal((await call('POST', '/api/usuarios', { nombre: 'Nuevo', correo: 'nuevo@x.do', clave: 'Clave12345', rol: 'Cliente' }, c)).s, 201);
  assert.equal(db.prepare("SELECT estado FROM usuarios WHERE correo='nuevo@x.do'").get().estado, 'Activo');
});
test('HU-1.2 Autorregistro crea la cuenta con rol Cliente', async () => {
  assert.equal((await call('POST', '/api/registro', { nombre: 'Persona', correo: 'persona@x.do', clave: 'Clave12345' })).s, 201);
  assert.equal(db.prepare("SELECT r.nombre n FROM usuarios u JOIN roles r ON r.id=u.rol_id WHERE correo='persona@x.do'").get().n, 'Cliente');
});
test('Acceso no autorizado: Cliente no puede crear usuarios (403) y queda "Acceso denegado"', async () => {
  const c = await login('cliente');
  const r = await call('POST', '/api/usuarios', { nombre: 'Z', correo: 'z@x.do', clave: 'Clave12345', rol: 'Cliente' }, c);
  assert.equal(r.s, 403); assert.equal(ultimo().evento, 'Acceso denegado');
  assert.equal(db.prepare("SELECT COUNT(*) n FROM usuarios WHERE correo='z@x.do'").get().n, 0);
});
test('Acceso autorizado: Cliente consulta reportes pero no los elimina', async () => {
  const c = await login('cliente');
  assert.equal((await call('GET', '/api/reportes', null, c)).s, 200);
  assert.equal((await call('DELETE', '/api/reportes/DEMO-001', null, c)).s, 403);
});
test('Restricción por perfil: Supervisor consulta auditoría pero no usuarios', async () => {
  const c = await login('supervisor');
  assert.equal((await call('GET', '/api/auditoria', null, c)).s, 200);
  assert.equal((await call('GET', '/api/usuarios', null, c)).s, 403);
});
test('HU-1.4 Solo quien tiene permiso modifica permisos (Administrador no; Super sí)', async () => {
  const body = { rol: 'Cliente', modulo: 'usuarios', accion: 'r', valor: true };
  assert.equal((await call('PUT', '/api/permisos', body, await login('admin'))).s, 403);
  assert.equal((await call('PUT', '/api/permisos', body, await login('super'))).s, 200);
});
test('HU-1.4 Un cambio de permiso se aplica de inmediato, sin reiniciar sesión', async () => {
  const c = await login('cliente');
  assert.equal((await call('GET', '/api/usuarios', null, c)).s, 200); // el permiso del test anterior ya está activo
  await call('PUT', '/api/permisos', { rol: 'Cliente', modulo: 'usuarios', accion: 'r', valor: false }, await login('super'));
  assert.equal((await call('GET', '/api/usuarios', null, c)).s, 403);
});
test('HU-1.4 El Super Administrador no se puede restringir', async () => {
  assert.equal((await call('PUT', '/api/permisos', { rol: 'Super Administrador', modulo: 'usuarios', accion: 'r', valor: false }, await login('super'))).s, 403);
});
test('HU-1.3 Un rol con usuarios activos no se puede desactivar ni eliminar', async () => {
  const c = await login('super'), id = db.prepare("SELECT id FROM roles WHERE nombre='Ingeniero'").get().id;
  assert.equal((await call('PUT', `/api/roles/${id}/estado`, { activo: false }, c)).s, 409);
  assert.equal((await call('DELETE', `/api/roles/${id}`, null, c)).s, 409);
});
test('HU-1.3 Se puede crear un rol nuevo y no se repite el nombre', async () => {
  const c = await login('super');
  assert.equal((await call('POST', '/api/roles', { nombre: 'Auditor externo' }, c)).s, 201);
  assert.equal((await call('POST', '/api/roles', { nombre: 'auditor externo' }, c)).s, 409);
});
test('HU-1.6 Bloquear exige motivo, impide el login y cierra sus sesiones', async () => {
  const c = await login('super'), id = db.prepare("SELECT id FROM usuarios WHERE correo='arquitecto@aguaclara.do'").get().id;
  const sesion = await login('arquitecto');
  assert.equal((await call('PUT', `/api/usuarios/${id}/bloqueo`, { bloquear: true }, c)).s, 400);
  assert.equal((await call('PUT', `/api/usuarios/${id}/bloqueo`, { bloquear: true, motivo: 'Prueba' }, c)).s, 200);
  assert.equal((await call('GET', '/api/me', null, sesion)).d.me, null);
  assert.equal((await call('POST', '/api/login', { correo: 'arquitecto@aguaclara.do', clave: 'Demo123*' })).s, 403);
  assert.equal((await call('PUT', `/api/usuarios/${id}/bloqueo`, { bloquear: false }, c)).s, 200);
  assert.ok(await login('arquitecto'));
});
test('HU-1.5 El enlace de recuperación es de un solo uso', async () => {
  const k = (await call('POST', '/api/recuperar', { correo: 'agente@aguaclara.do' })).d.k;
  assert.equal((await call('POST', '/api/recuperar/usar', { token: k, clave: 'NuevaClave1' })).s, 200);
  assert.equal((await call('POST', '/api/recuperar/usar', { token: k, clave: 'OtraClave12' })).s, 400);
  assert.ok(await login('agente', 'NuevaClave1'));
});
test('HU-1.5 El enlace vencido es rechazado', async () => {
  const k = (await call('POST', '/api/recuperar', { correo: 'agente@aguaclara.do' })).d.k;
  db.prepare('UPDATE tokens_recuperacion SET expira=? WHERE token=?').run(Date.now() - 1, k);
  assert.equal((await call('POST', '/api/recuperar/usar', { token: k, clave: 'NuevaClave2' })).s, 400);
});
test('HU-1.7 Cambiar contraseña exige la actual y mínimo 8 caracteres', async () => {
  const c = await login('supervisor');
  assert.equal((await call('PUT', '/api/perfil/clave', { actual: 'mala', nueva: 'Clave12345' }, c)).s, 400);
  assert.equal((await call('PUT', '/api/perfil/clave', { actual: 'Demo123*', nueva: 'corta' }, c)).s, 400);
  assert.equal((await call('PUT', '/api/perfil/clave', { actual: 'Demo123*', nueva: 'Clave12345' }, c)).s, 200);
});
test('HU-1.8 Cierre de sesión invalida la sesión y queda registrado', async () => {
  const c = await login('arquitecto');
  await call('POST', '/api/logout', null, c);
  assert.equal(ultimo().evento, 'Cierre de sesión');
  assert.equal((await call('GET', '/api/me', null, c)).d.me, null);
});
test('HU-1.8 La auditoría registra IP y localización', async () => {
  const r = (await call('GET', '/api/auditoria', null, await login('super'))).d.items[0];
  assert.ok(r.ip && r.loc && r.t);
});
test('Reportes públicos: se crea con código y la consulta pública no expone contacto', async () => {
  const r = await call('POST', '/api/reportes', { municipio: 'Santiago', sector: 'Centro', tipo: 'Falta de agua', descripcion: 'No llega agua desde ayer.', contactoNombre: 'Ana', contactoTelefono: '809-000-0000' });
  assert.equal(r.s, 201); assert.match(r.d.codigo, /^DEMO-\d{3}$/);
  const p = await call('GET', `/api/reportes/publico/${r.d.codigo}`);
  assert.equal(p.s, 200); assert.equal(JSON.stringify(p.d).includes('809-000-0000'), false);
  assert.equal((await call('GET', '/api/reportes/publico/NOEXISTE')).s, 404);
});
