// Pruebas de la Épica 2 - Gestión de Operaciones. Ejecutar con: npm test
process.env.NODE_ENV = 'test';
const test = require('node:test'), assert = require('node:assert/strict');
const os = require('os'), path = require('path'), fs = require('fs');
const { createApp } = require('../server/index.js');
const { open } = require('../server/db.js');

const file = path.join(os.tmpdir(), `ac-e2-${process.pid}-${Date.now()}.db`);
const db = open(file, { seedDemo: true });
let server, base;
test.before(() => new Promise((ok) => { server = createApp(db, { modoDemo: true, alertas: false }).listen(0, () => { base = `http://127.0.0.1:${server.address().port}`; ok(); }); }));
test.after(() => { server.close(); db.close(); ['', '-wal', '-shm'].forEach((s) => fs.rmSync(file + s, { force: true })); });

async function call(method, url, body, cookie) {
  const r = await fetch(base + url, { method, headers: { 'Content-Type': 'application/json', ...(cookie ? { Cookie: cookie } : {}) }, body: body ? JSON.stringify(body) : undefined });
  const sc = r.headers.get('set-cookie'), ct = r.headers.get('content-type') || '';
  return { s: r.status, d: ct.includes('json') ? await r.json().catch(() => ({})) : {}, text: ct.includes('json') ? '' : await r.text(), cookie: sc ? sc.split(';')[0] : null };
}
const sesion = async (u) => (await call('POST', '/api/login', { correo: `${u}@aguaclara.do`, clave: 'Demo123*' })).cookie;
const uid = (u) => db.prepare('SELECT id FROM usuarios WHERE correo=?').get(`${u}@aguaclara.do`).id;
const tipo = (n) => db.prepare('SELECT id FROM tipos_operacion WHERE nombre=?').get(n).id;
const nueva = (c, extra = {}) => call('POST', '/api/operaciones', { tipo_id: tipo('Restablecer suministro'), titulo: 'Operación de prueba', descripcion: 'Descripción de la operación de prueba.', ...extra }, c);
const ultimaBit = () => db.prepare('SELECT * FROM bitacora ORDER BY id DESC LIMIT 1').get();
const horas = (h) => new Date(Date.now() + h * 3600e3).toISOString();

// ---------- HU-2.1 Panel de operaciones ----------
test('HU-2.1 Los indicadores cuadran exactamente con los registros listados', async () => {
  const c = await sesion('supervisor'), r = (await call('GET', '/api/operaciones', null, c)).d, it = r.items;
  assert.equal(r.indicadores.creadas, it.length);
  assert.equal(r.indicadores.en_proceso, it.filter((o) => o.estado === 'En proceso').length);
  assert.equal(r.indicadores.completadas, it.filter((o) => ['Completada', 'Cerrada'].includes(o.estado)).length);
  assert.equal(r.indicadores.rechazadas, it.filter((o) => o.estado === 'Rechazada').length);
  assert.equal(r.indicadores.vencidas, it.filter((o) => o.vencida).length);
  assert.ok(r.actualizado > 0);
});
test('HU-2.1 Filtra por estado, tipo, responsable y periodo, y los indicadores siguen cuadrando', async () => {
  const c = await sesion('supervisor');
  const a = (await call('GET', '/api/operaciones?estado=En%20proceso', null, c)).d;
  assert.ok(a.items.length > 0 && a.items.every((o) => o.estado === 'En proceso') && a.indicadores.creadas === a.items.length);
  const b = (await call('GET', `/api/operaciones?responsable=${uid('ingeniero')}&tipo=${tipo('Reparación de fuga')}`, null, c)).d;
  assert.ok(b.items.every((o) => o.responsable.id === uid('ingeniero') && o.tipo === 'Reparación de fuga'));
  assert.equal((await call('GET', '/api/operaciones?desde=2099-01-01', null, c)).d.items.length, 0);
  assert.ok((await call('GET', '/api/operaciones?responsable=sin', null, c)).d.items.every((o) => o.responsable === null));
});
test('HU-2.1 Cada indicador abre exactamente los registros que cuenta', async () => {
  const c = await sesion('supervisor'), ind = (await call('GET', '/api/operaciones', null, c)).d.indicadores;
  assert.equal((await call('GET', '/api/operaciones?grupo=completadas', null, c)).d.items.length, ind.completadas);
  assert.equal((await call('GET', '/api/operaciones?estado=En%20proceso', null, c)).d.items.length, ind.en_proceso);
  assert.equal((await call('GET', '/api/operaciones?estado=Rechazada', null, c)).d.items.length, ind.rechazadas);
  assert.equal((await call('GET', '/api/operaciones?vencidas=1', null, c)).d.items.length, ind.vencidas);
});
test('HU-2.1 Identifica operaciones vencidas y próximas a vencer', async () => {
  const c = await sesion('supervisor'), v = (await call('GET', '/api/operaciones?vencidas=1', null, c)).d;
  assert.ok(v.items.length > 0 && v.items.every((o) => o.vencida) && v.indicadores.vencidas === v.items.length);
  assert.ok(v.items.some((o) => o.codigo === 'OP-0002'));
});
test('Acceso por rol: Cliente no ve operaciones; Auditor consulta pero no crea', async () => {
  assert.equal((await call('GET', '/api/operaciones', null, await sesion('cliente'))).s, 403);
  const au = await sesion('auditor');
  assert.equal((await call('GET', '/api/operaciones', null, au)).s, 200);
  assert.equal((await nueva(au)).s, 403);
});

// ---------- HU-2.2 Registro y seguimiento ----------
test('HU-2.2 Crea la operación con identificador único, tipo, descripción, fecha y estado Creada', async () => {
  const c = await sesion('supervisor'), r = await nueva(c, { responsable_id: uid('ingeniero') });
  assert.equal(r.s, 201); assert.match(r.d.codigo, /^OP-\d{4}$/);
  const r2 = await nueva(c); assert.notEqual(r2.d.codigo, r.d.codigo);
  const o = (await call('GET', `/api/operaciones/${r.d.codigo}`, null, c)).d.item;
  assert.equal(o.estado, 'Creada'); assert.ok(o.limite > Date.now()); assert.equal(o.responsable.nombre, 'Iván Ingeniero');
});
test('HU-2.2 Valida los campos antes de guardar y deja constancia del rechazo', async () => {
  const c = await sesion('supervisor');
  for (const extra of [{ titulo: 'ab' }, { descripcion: 'corta' }, { tipo_id: 9999 }, { fecha_limite: '2020-01-01T00:00:00Z' }, { fecha_limite: 'no-es-fecha' }, { responsable_id: uid('cliente') }]) {
    assert.equal((await nueva(c, extra)).s, 400, JSON.stringify(extra));
  }
  const b = ultimaBit(); assert.equal(b.resultado, 'Rechazado'); assert.equal(b.accion, 'Crear operación');
});
test('HU-2.2 Impide transiciones de estado no permitidas', async () => {
  const c = await sesion('supervisor'), { codigo } = (await nueva(c)).d;
  const r = await call('POST', `/api/operaciones/${codigo}/estado`, { estado: 'Completada' }, c);
  assert.equal(r.s, 409); assert.match(r.d.error, /Transición no permitida/);
  assert.equal((await call('POST', `/api/operaciones/${codigo}/estado`, { estado: 'Cerrada', resultado: 'Listo para cerrar' }, c)).s, 409);
});
test('HU-2.2 No se inicia una operación sin responsable', async () => {
  const c = await sesion('supervisor'), { codigo } = (await nueva(c)).d;
  const r = await call('POST', `/api/operaciones/${codigo}/estado`, { estado: 'En proceso' }, c);
  assert.equal(r.s, 409); assert.match(r.d.error, /responsable/);
});
test('HU-2.2 Ciclo completo: Creada → En proceso → Completada → Cerrada, con historial', async () => {
  const c = await sesion('supervisor'), { codigo } = (await nueva(c, { responsable_id: uid('ingeniero') })).d, est = (e, x = {}) => call('POST', `/api/operaciones/${codigo}/estado`, { estado: e, ...x }, c);
  assert.equal((await est('En proceso')).s, 200); assert.equal((await est('Completada')).s, 200);
  assert.equal((await est('Cerrada')).s, 400); // exige describir el resultado
  assert.equal((await est('Cerrada', { resultado: 'Servicio restablecido y verificado.' })).s, 200);
  const d = (await call('GET', `/api/operaciones/${codigo}`, null, c)).d;
  assert.equal(d.item.estado, 'Cerrada'); assert.equal(d.transiciones.length, 0);
  assert.deepEqual(d.historial.filter((h) => h.accion === 'Cambio de estado').map((h) => JSON.parse(h.despues).estado).reverse(), ['En proceso', 'Completada', 'Cerrada']);
  assert.equal((await est('En proceso')).s, 409); // cerrada = terminal
});
test('HU-2.2 Actualizar datos guarda valores anteriores y nuevos; no permite editar una cerrada', async () => {
  const c = await sesion('supervisor'), { codigo } = (await nueva(c, { responsable_id: uid('ingeniero') })).d;
  assert.equal((await call('PUT', `/api/operaciones/${codigo}`, { titulo: 'Título actualizado', prioridad: 'Alta' }, c)).s, 200);
  const b = ultimaBit(); assert.equal(b.accion, 'Operación actualizada');
  assert.equal(JSON.parse(b.antes).prioridad, 'Media'); assert.equal(JSON.parse(b.despues).prioridad, 'Alta');
  assert.equal((await call('PUT', `/api/operaciones/${codigo}`, { titulo: 'Título actualizado', prioridad: 'Alta' }, c)).s, 400); // sin cambios
  assert.equal((await call('PUT', `/api/operaciones/${codigo}`, { prioridad: 'Urgentísima' }, c)).s, 400);
});
test('HU-2.2 Un operador solo modifica operaciones propias, no las de otras personas', async () => {
  const sup = await sesion('supervisor'), ing = await sesion('ingeniero');
  const ajena = (await nueva(sup, { responsable_id: uid('agente') })).d.codigo;
  assert.equal((await call('POST', `/api/operaciones/${ajena}/estado`, { estado: 'En proceso' }, ing)).s, 403);
  const propia = (await nueva(ing, { responsable_id: uid('ingeniero') })).d.codigo;
  assert.equal((await call('POST', `/api/operaciones/${propia}/estado`, { estado: 'En proceso' }, ing)).s, 200);
  assert.equal((await nueva(ing, { responsable_id: uid('agente') })).s, 403); // un operador no asigna a otra persona
});

// ---------- HU-2.3 Asignación de responsables ----------
test('HU-2.3 Supervisión asigna y reasigna; queda quién, cuándo y motivo; se notifica al responsable', async () => {
  const c = await sesion('supervisor'), { codigo } = (await nueva(c)).d, as = (id, motivo) => call('POST', `/api/operaciones/${codigo}/asignar`, { responsable_id: id, motivo }, c);
  assert.equal((await as(uid('ingeniero'))).s, 200);
  assert.equal((await as(uid('ingeniero'))).s, 409); // ya es el responsable
  assert.equal((await as(uid('agente'))).s, 400); // reasignar exige motivo
  assert.equal((await as(uid('agente'), 'El ingeniero está en otra obra')).s, 200);
  const d = (await call('GET', `/api/operaciones/${codigo}`, null, c)).d;
  assert.equal(d.asignaciones.length, 2); assert.equal(d.asignaciones[0].motivo, 'El ingeniero está en otra obra'); assert.equal(d.asignaciones[0].asignado_por, 'Sergio Supervisor');
  assert.ok(db.prepare("SELECT 1 FROM notificaciones WHERE usuario_id=? AND tipo='Asignación' AND mensaje LIKE ?").get(uid('agente'), `%${codigo}%`));
  assert.ok(db.prepare("SELECT 1 FROM notificaciones WHERE usuario_id=? AND tipo='Reasignación'").get(uid('ingeniero')));
});
test('HU-2.3 Solo se asigna a responsables autorizados; un operador no puede asignar', async () => {
  const c = await sesion('supervisor'), { codigo } = (await nueva(c)).d, as = (cookie, id) => call('POST', `/api/operaciones/${codigo}/asignar`, { responsable_id: id }, cookie);
  assert.equal((await as(c, uid('cliente'))).s, 400); // Cliente no tiene permiso operativo
  assert.equal((await as(await sesion('ingeniero'), uid('ingeniero'))).s, 403);
  db.prepare("UPDATE usuarios SET estado='Bloqueado' WHERE correo='arquitecto@aguaclara.do'").run();
  assert.equal((await as(c, uid('arquitecto'))).s, 400); // bloqueado
  db.prepare("UPDATE usuarios SET estado='Activo' WHERE correo='arquitecto@aguaclara.do'").run();
  const lista = (await call('GET', '/api/responsables', null, c)).d.items.map((r) => r.nombre);
  assert.ok(lista.includes('Iván Ingeniero') && !lista.includes('Clara Cliente'));
});
test('HU-2.3 Filtra operaciones por responsable', async () => {
  const c = await sesion('supervisor'), r = (await call('GET', `/api/operaciones?responsable=${uid('agente')}`, null, c)).d.items;
  assert.ok(r.length > 0 && r.every((o) => o.responsable.nombre === 'Agustín Agente'));
});

// ---------- HU-2.4 Flujos de aprobación ----------
async function enAprobacion(sup, resp = 'arquitecto') {
  const { codigo } = (await nueva(sup, { tipo_id: tipo('Reparación de tubería'), responsable_id: uid(resp) })).d, est = (e) => call('POST', `/api/operaciones/${codigo}/estado`, { estado: e }, sup);
  await est('En proceso'); assert.equal((await est('En aprobación')).s, 200); return codigo;
}
test('HU-2.4 Un tipo con aprobación no pasa a Completada sin que se apruebe', async () => {
  const c = await sesion('supervisor'), { codigo } = (await nueva(c, { tipo_id: tipo('Reparación de tubería'), responsable_id: uid('arquitecto') })).d, est = (e) => call('POST', `/api/operaciones/${codigo}/estado`, { estado: e }, c);
  await est('En proceso');
  const r = await est('Completada'); assert.equal(r.s, 409); assert.match(r.d.error, /requiere aprobación/);
  assert.equal((await est('En aprobación')).s, 200);
  assert.equal((await est('Completada')).s, 409);
  const sinAprob = (await nueva(c, { responsable_id: uid('ingeniero') })).d.codigo;
  await call('POST', `/api/operaciones/${sinAprob}/estado`, { estado: 'En proceso' }, c);
  assert.equal((await call('POST', `/api/operaciones/${sinAprob}/estado`, { estado: 'En aprobación' }, c)).s, 409); // este tipo no la requiere
});
test('HU-2.4 El aprobador decide con comentario; queda aprobador, decisión, fecha y comentarios', async () => {
  const sup = await sesion('supervisor'), codigo = await enAprobacion(sup, 'ingeniero');
  assert.ok(db.prepare("SELECT 1 FROM notificaciones WHERE tipo='Aprobación' AND mensaje LIKE ?").get(`%${codigo}%`));
  const r = await call('POST', `/api/operaciones/${codigo}/aprobacion`, { decision: 'Aprobada', comentario: 'Todo conforme.' }, sup);
  assert.equal(r.s, 200); assert.equal(r.d.estado, 'Completada');
  const d = (await call('GET', `/api/operaciones/${codigo}`, null, sup)).d;
  assert.equal(d.aprobaciones[0].decision, 'Aprobada'); assert.equal(d.aprobaciones[0].aprobador, 'Sergio Supervisor'); assert.equal(d.aprobaciones[0].comentario, 'Todo conforme.'); assert.ok(d.aprobaciones[0].fecha);
});
test('HU-2.4 Rechazar o devolver exige motivo; devolver reabre el trabajo; un rechazo bloquea el avance', async () => {
  const sup = await sesion('supervisor'), c1 = await enAprobacion(sup), ap = (cod, decision, comentario) => call('POST', `/api/operaciones/${cod}/aprobacion`, { decision, comentario }, sup);
  assert.equal((await ap(c1, 'Devuelta')).s, 400);
  assert.equal((await ap(c1, 'Devuelta', 'Falta el plano firmado')).s, 200);
  assert.equal((await call('GET', `/api/operaciones/${c1}`, null, sup)).d.item.estado, 'En proceso');
  const c2 = await enAprobacion(sup);
  assert.equal((await ap(c2, 'Rechazada', 'No cumple la norma')).s, 200);
  const est = (cod, e, x = {}) => call('POST', `/api/operaciones/${cod}/estado`, { estado: e, ...x }, sup);
  assert.equal((await est(c2, 'Completada')).s, 409);
  assert.equal((await est(c2, 'En proceso')).s, 400); // reabrir exige motivo
  assert.equal((await est(c2, 'En proceso', { motivo: 'Se corrigió el diseño' })).s, 200);
});
test('HU-2.4 Solo decide el rol aprobador, y nunca quien tiene asignada la operación', async () => {
  const sup = await sesion('supervisor'), codigo = await enAprobacion(sup);
  const ap = (cookie) => call('POST', `/api/operaciones/${codigo}/aprobacion`, { decision: 'Aprobada', comentario: 'Aprobado' }, cookie);
  assert.equal((await ap(await sesion('admin'))).s, 403); // Administrador no es el rol configurado
  assert.equal((await ap(await sesion('ingeniero'))).s, 403); // sin permiso de aprobar
  const propia = await enAprobacion(sup, 'supervisor');
  assert.equal((await call('POST', `/api/operaciones/${propia}/aprobacion`, { decision: 'Aprobada', comentario: 'Aprobado' }, sup)).s, 409);
  assert.equal((await call('POST', `/api/operaciones/${codigo}/aprobacion`, { decision: 'Aprobada', comentario: 'Aprobado' }, await sesion('super'))).s, 200);
});
test('HU-2.4 Configura aprobaciones por tipo: solo quien tiene permiso y solo con un rol que pueda aprobar', async () => {
  const sup = await sesion('supervisor'), t = tipo('Inspección de campo');
  assert.equal((await call('PUT', `/api/tipos/${t}`, { sla: 96, aviso: 24, aprob: true, aprobador: db.prepare("SELECT id FROM roles WHERE nombre='Cliente'").get().id }, sup)).s, 400);
  assert.equal((await call('PUT', `/api/tipos/${t}`, { sla: 96, aviso: 24, aprob: true, aprobador: db.prepare("SELECT id FROM roles WHERE nombre='Supervisor'").get().id }, await sesion('ingeniero'))).s, 403);
  assert.equal((await call('PUT', `/api/tipos/${t}`, { sla: 96, aviso: 24, aprob: true, aprobador: db.prepare("SELECT id FROM roles WHERE nombre='Supervisor'").get().id }, sup)).s, 200);
  assert.equal(db.prepare('SELECT requiere_aprobacion r FROM tipos_operacion WHERE id=?').get(t).r, 1);
  assert.equal(JSON.parse(ultimaBit().antes).aprobacion, false);
});

// ---------- HU-2.5 Alertas y vencimientos ----------
test('HU-2.5 Configura plazos por tipo y valida los valores', async () => {
  const sup = await sesion('supervisor'), t = tipo('Reparación de fuga');
  assert.equal((await call('PUT', `/api/tipos/${t}`, { sla: 0, aviso: 0 }, sup)).s, 400);
  assert.equal((await call('PUT', `/api/tipos/${t}`, { sla: 24, aviso: 48 }, sup)).s, 400); // el aviso no puede superar el plazo
  assert.equal((await call('PUT', `/api/tipos/${t}`, { sla: 36, aviso: 12 }, sup)).s, 200);
  const o = (await nueva(sup, { tipo_id: t })).d.codigo, lim = (await call('GET', `/api/operaciones/${o}`, null, sup)).d.item.limite;
  assert.ok(Math.abs(lim - (Date.now() + 36 * 3600e3)) < 60e3); // la fecha límite por defecto sale del plazo del tipo
  await call('PUT', `/api/tipos/${t}`, { sla: 48, aviso: 12 }, sup);
});
test('HU-2.5 Genera alertas de vencidas y por vencer, sin duplicarlas dentro de la ventana, y registra el resultado', async () => {
  const sup = await sesion('supervisor');
  db.prepare('DELETE FROM notificaciones').run();
  const a = (await call('POST', '/api/alertas/generar', null, sup)).d;
  assert.equal(a.ok, true); assert.ok(a.creadas >= 1);
  assert.ok(db.prepare("SELECT 1 FROM notificaciones WHERE tipo='Vencida' AND canal='interno' AND resultado='Entregada'").get());
  const b = (await call('POST', '/api/alertas/generar', null, sup)).d;
  assert.equal(b.creadas, 0); assert.equal(b.omitidas, a.creadas); // duplicados evitados
  db.prepare('UPDATE notificaciones SET fecha=fecha-?').run(13 * 3600e3); // pasa la ventana de 12 h
  assert.equal((await call('POST', '/api/alertas/generar', null, sup)).d.creadas, a.creadas);
  assert.equal(ultimaBit().entidad, 'alerta'); assert.equal(ultimaBit().resultado, 'Entregada');
  const log = (await call('GET', '/api/alertas', null, sup)).d.items; assert.ok(log.length && log[0].resultado === 'Entregada');
});
test('HU-2.5 La ventana anti-duplicados es configurable y las operaciones terminadas no generan alertas', async () => {
  const sup = await sesion('supervisor');
  assert.equal((await call('PUT', '/api/alertas/config', { ventanaH: 0 }, sup)).s, 400);
  assert.equal((await call('PUT', '/api/alertas/config', { ventanaH: 1 }, sup)).s, 200);
  db.prepare('DELETE FROM notificaciones').run();
  db.prepare("UPDATE operaciones SET estado='Cancelada' WHERE codigo='OP-0002'").run();
  await call('POST', '/api/alertas/generar', null, sup);
  assert.equal(db.prepare("SELECT COUNT(*) n FROM notificaciones n JOIN operaciones o ON o.id=n.operacion_id WHERE o.codigo='OP-0002'").get().n, 0);
  db.prepare("UPDATE operaciones SET estado='En proceso' WHERE codigo='OP-0002'").run();
  await call('PUT', '/api/alertas/config', { ventanaH: 12 }, sup);
});
test('HU-2.5 Cada persona ve sus notificaciones y puede marcarlas como leídas', async () => {
  await call('POST', '/api/alertas/generar', null, await sesion('supervisor'));
  const ag = await sesion('agente'), n = (await call('GET', '/api/notificaciones', null, ag)).d;
  assert.ok(n.items.length > 0 && n.sinLeer > 0);
  await call('PUT', '/api/notificaciones/leidas', null, ag);
  assert.equal((await call('GET', '/api/notificaciones', null, ag)).d.sinLeer, 0);
  assert.equal((await call('GET', '/api/notificaciones', null, await sesion('cliente'))).d.items.length, 0);
});

// ---------- HU-2.6 Incidencias operativas ----------
test('HU-2.6 Registra una incidencia vinculada a una operación con categoría, descripción, prioridad y responsable', async () => {
  const c = await sesion('ingeniero'), r = await call('POST', '/api/incidencias', { operacion: 'OP-0001', categoria: 'Acceso al sitio', descripcion: 'El portón del predio está cerrado con candado.', prioridad: 'Alta', responsable_id: uid('ingeniero') }, c);
  assert.equal(r.s, 201); assert.match(r.d.codigo, /^INC-\d{4}$/);
  const d = (await call('GET', `/api/incidencias/${r.d.codigo}`, null, c)).d;
  assert.equal(d.item.operacion, 'OP-0001'); assert.equal(d.item.estado, 'Abierta'); assert.equal(d.item.prioridad, 'Alta');
  assert.equal((await call('GET', '/api/incidencias?operacion=OP-0001', null, c)).d.items.every((i) => i.operacion === 'OP-0001'), true);
});
test('HU-2.6 Valida los datos y no admite incidencias en operaciones cerradas', async () => {
  const c = await sesion('supervisor'), inc = (x) => call('POST', '/api/incidencias', { operacion: 'OP-0001', categoria: 'Otra', descripcion: 'Descripción suficiente.', ...x }, c);
  assert.equal((await inc({ operacion: 'OP-9999' })).s, 400);
  assert.equal((await inc({ categoria: 'x' })).s, 400);
  assert.equal((await inc({ descripcion: 'corta' })).s, 400);
  db.prepare("UPDATE operaciones SET estado='Cerrada' WHERE codigo='OP-0005'").run();
  assert.equal((await inc({ operacion: 'OP-0005' })).s, 409);
});
test('HU-2.6 Actualiza el estado, documenta la resolución y guarda comentarios e historial', async () => {
  const c = await sesion('agente'), st = (e, x = {}) => call('POST', '/api/incidencias/INC-0001/estado', { estado: e, ...x }, c);
  assert.equal((await st('Resuelta', { resolucion: 'Se resolvió' })).s, 409); // debe pasar por En atención
  assert.equal((await st('En atención')).s, 200);
  assert.equal((await st('Resuelta')).s, 400); // exige resolución
  assert.equal((await call('POST', '/api/incidencias/INC-0001/comentarios', { texto: 'Se pidió el repuesto al proveedor.' }, c)).s, 201);
  assert.equal((await st('Resuelta', { resolucion: 'Repuesto instalado.' })).s, 200);
  const d = (await call('GET', '/api/incidencias/INC-0001', null, c)).d;
  assert.equal(d.item.resolucion, 'Repuesto instalado.'); assert.equal(d.comentarios.length, 1);
  assert.ok(d.historial.length >= 3);
});
test('HU-2.6 No se puede cerrar una operación con incidencias sin resolver', async () => {
  const sup = await sesion('supervisor'), { codigo } = (await nueva(sup, { responsable_id: uid('ingeniero') })).d, est = (e, x = {}) => call('POST', `/api/operaciones/${codigo}/estado`, { estado: e, ...x }, sup);
  await est('En proceso'); await est('Completada');
  const inc = (await call('POST', '/api/incidencias', { operacion: codigo, categoria: 'Seguridad', descripcion: 'Zanja abierta sin señalización.' }, sup)).d.codigo;
  const r = await est('Cerrada', { resultado: 'Trabajo terminado.' }); assert.equal(r.s, 409); assert.match(r.d.error, /incidencia/);
  await call('POST', `/api/incidencias/${inc}/estado`, { estado: 'En atención' }, sup);
  await call('POST', `/api/incidencias/${inc}/estado`, { estado: 'Resuelta', resolucion: 'Zanja señalizada.' }, sup);
  assert.equal((await est('Cerrada', { resultado: 'Trabajo terminado.' })).s, 200);
});

// ---------- HU-2.7 Reportes operativos ----------
test('HU-2.7 El reporte incluye métricas que cuadran con los registros, fecha de generación, filtros y definiciones', async () => {
  const c = await sesion('gerente'), r = (await call('GET', `/api/informes?estado=En%20proceso&tipo=${tipo('Restablecer suministro')}`, null, c)).d;
  assert.ok(r.filas.every((o) => o.estado === 'En proceso' && o.tipo === 'Restablecer suministro'));
  assert.equal(r.metricas.total, r.filas.length);
  assert.equal(r.por_estado.reduce((a, e) => a + e.total, 0), r.metricas.total);
  assert.equal(r.por_tipo.reduce((a, e) => a + e.total, 0), r.metricas.total);
  assert.equal(r.por_responsable.reduce((a, e) => a + e.total, 0), r.metricas.total);
  assert.ok(Math.abs(r.generado - Date.now()) < 60e3); assert.equal(r.filtros.estado, 'En proceso'); assert.equal(r.filtros.tipo, 'Restablecer suministro');
  for (const k of ['total', 'completadas', 'vencidas', 'cumplimiento', 'tiempo_promedio_horas', 'incidencias_abiertas']) assert.ok(r.definiciones[k], k);
});
test('HU-2.7 Las métricas de cumplimiento y tiempo se calculan con las operaciones completadas', async () => {
  const c = await sesion('gerente'), all = (await call('GET', '/api/informes', null, c)).d;
  const comp = db.prepare("SELECT cerrado, fecha_limite, creado FROM operaciones WHERE estado IN ('Completada','Cerrada') AND cerrado IS NOT NULL").all();
  assert.equal(all.metricas.completadas, db.prepare("SELECT COUNT(*) n FROM operaciones WHERE estado IN ('Completada','Cerrada')").get().n);
  const esp = Math.round((comp.filter((o) => o.cerrado <= o.fecha_limite).length / comp.length) * 1000) / 10;
  assert.equal(all.metricas.cumplimiento, esp);
  assert.ok(all.metricas.tiempo_promedio_horas > 0);
});
test('HU-2.7 Exporta CSV solo con permiso, con fecha de generación y filtros, y neutraliza fórmulas', async () => {
  const sup = await sesion('supervisor');
  await nueva(sup, { titulo: '=HYPERLINK("http://x")', responsable_id: uid('ingeniero') });
  assert.equal((await call('GET', '/api/informes/exportar', null, await sesion('auditor'))).s, 403); // solo puede ver, no exportar
  assert.equal((await call('GET', '/api/informes/exportar', null, await sesion('ingeniero'))).s, 403);
  const r = await call('GET', '/api/informes/exportar?estado=Creada', null, await sesion('gerente'));
  assert.equal(r.s, 200); assert.match(r.text, /Generado,/); assert.match(r.text, /Filtros,.*Estado: Creada/); assert.match(r.text, /Codigo,Titulo/);
  assert.ok(r.text.includes("\"'=HYPERLINK") || r.text.includes("'=HYPERLINK")); assert.ok(!/,=HYPERLINK/.test(r.text));
  assert.equal(ultimaBit().accion, 'Informe exportado (CSV)');
});

// ---------- HU-2.8 Bitácora de cambios ----------
test('HU-2.8 La bitácora registra actor, fecha y hora, entidad, acción y resultado, con valores anteriores y nuevos', async () => {
  const sup = await sesion('supervisor'), { codigo } = (await nueva(sup)).d;
  await call('PUT', `/api/operaciones/${codigo}`, { prioridad: 'Crítica' }, sup);
  const b = (await call('GET', `/api/bitacora?operacion=${codigo}`, null, sup)).d.items, u = b.find((x) => x.accion === 'Operación actualizada');
  assert.equal(u.actor, 'supervisor@aguaclara.do'); assert.ok(u.t > 0); assert.equal(u.entidad, 'operacion'); assert.equal(u.resultado, 'Exitoso');
  assert.equal(JSON.parse(u.antes).prioridad, 'Media'); assert.equal(JSON.parse(u.despues).prioridad, 'Crítica');
});
test('HU-2.8 Busca por operación, usuario y periodo', async () => {
  const au = await sesion('auditor');
  const porOp = (await call('GET', '/api/bitacora?operacion=OP-0002', null, au)).d.items; assert.ok(porOp.length > 0 && porOp.every((x) => x.operacion === 'OP-0002'));
  const porUsr = (await call('GET', '/api/bitacora?usuario=supervisor', null, au)).d.items; assert.ok(porUsr.length > 0 && porUsr.every((x) => x.actor.includes('supervisor')));
  assert.equal((await call('GET', '/api/bitacora?desde=2099-01-01', null, au)).d.items.length, 0);
  const hoy = new Date().toISOString().slice(0, 10); assert.ok((await call('GET', `/api/bitacora?desde=${hoy}&hasta=${hoy}`, null, au)).d.items.length > 0);
  assert.ok((await call('GET', '/api/bitacora?q=Operaci%C3%B3n%20creada', null, au)).d.items.length > 0);
});
test('HU-2.8 La bitácora no se puede modificar ni eliminar (ni por la API ni por la base de datos)', async () => {
  assert.throws(() => db.prepare("UPDATE bitacora SET accion='alterado'").run(), /no se puede modificar/);
  assert.throws(() => db.prepare('DELETE FROM bitacora').run(), /no se puede eliminar/);
  const sa = await sesion('super');
  assert.equal((await call('DELETE', '/api/bitacora', null, sa)).s, 404);
  assert.equal((await call('PUT', '/api/bitacora/1', { accion: 'x' }, sa)).s, 404);
});
test('HU-2.8 Solo quien tiene permiso consulta la bitácora; Auditor sí, Cliente no', async () => {
  assert.equal((await call('GET', '/api/bitacora', null, await sesion('cliente'))).s, 403);
  assert.equal((await call('GET', '/api/bitacora', null, await sesion('ingeniero'))).s, 403);
  assert.equal((await call('GET', '/api/bitacora', null, await sesion('auditor'))).s, 200);
});
test('Seguridad: la bitácora y los registros no exponen contraseñas ni tokens', () => {
  const todo = JSON.stringify(db.prepare('SELECT * FROM bitacora').all()) + JSON.stringify(db.prepare('SELECT * FROM auditoria').all());
  assert.ok(!/clave_hash|\$2[aby]\$|Demo123|ac_sid/.test(todo));
});
test('Permisos: los 7 módulos nuevos y los roles Auditor y Gerente aparecen en la matriz', async () => {
  const m = (await call('GET', '/api/permisos', null, await sesion('super'))).d.items;
  for (const mod of ['operaciones', 'asignaciones', 'aprobaciones', 'incidencias', 'informes', 'tipos', 'bitacora']) assert.ok(m['Supervisor'][mod], mod);
  assert.ok(m['Auditor'] && m['Gerente']);
  assert.equal(m['Auditor'].bitacora.r, 1); assert.equal(m['Gerente'].informes.c, 1); assert.equal(m['Cliente'].operaciones.r, 0);
});
test('Permisos: un cambio de permiso en operaciones se aplica de inmediato', async () => {
  const cl = await sesion('cliente');
  assert.equal((await call('GET', '/api/operaciones', null, cl)).s, 403);
  await call('PUT', '/api/permisos', { rol: 'Cliente', modulo: 'operaciones', accion: 'r', valor: true }, await sesion('super'));
  assert.equal((await call('GET', '/api/operaciones', null, cl)).s, 200);
  await call('PUT', '/api/permisos', { rol: 'Cliente', modulo: 'operaciones', accion: 'r', valor: false }, await sesion('super'));
});
test('Migración: una base de la Épica 1 se actualiza sin perder usuarios ni datos', () => {
  const f2 = path.join(os.tmpdir(), `ac-mig-${process.pid}.db`), D = require('better-sqlite3'), d = new D(f2);
  d.exec("CREATE TABLE roles(id INTEGER PRIMARY KEY, nombre TEXT UNIQUE NOT NULL COLLATE NOCASE, activo INTEGER NOT NULL DEFAULT 1)");
  d.close(); fs.rmSync(f2, { force: true });
  const e1 = open(f2, { seedDemo: true }); e1.exec('DROP TRIGGER bitacora_sin_modificar; DROP TRIGGER bitacora_sin_eliminar; DROP TABLE bitacora; DROP TABLE notificaciones; DROP TABLE incidencia_comentarios; DROP TABLE incidencias; DROP TABLE aprobaciones; DROP TABLE asignaciones; DROP TABLE operaciones; DROP TABLE tipos_operacion;');
  e1.prepare("DELETE FROM config WHERE clave IN ('demo_e2','ventanaAlertaH')").run(); e1.prepare("DELETE FROM permisos WHERE modulo IN ('operaciones','bitacora')").run(); e1.close();
  const e2 = open(f2, { seedDemo: true });
  assert.ok(e2.prepare('SELECT COUNT(*) n FROM usuarios').get().n >= 9); assert.ok(e2.prepare('SELECT COUNT(*) n FROM tipos_operacion').get().n === 4);
  assert.equal(e2.prepare("SELECT COUNT(*) n FROM permisos WHERE modulo='bitacora'").get().n, e2.prepare('SELECT COUNT(*) n FROM roles').get().n);
  e2.close(); ['', '-wal', '-shm'].forEach((s) => fs.rmSync(f2 + s, { force: true }));
});
