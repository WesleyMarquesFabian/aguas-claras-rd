# Agua Clara RD

Página web de reportes de averías y falta de agua (proyecto académico, República Dominicana), con API en **Node.js + Express** y base de datos **SQLite**.

| Épica | Contenido | Entrega |
|---|---|---|
| 1 | Gestión de Usuarios y Accesos (usuarios, roles, permisos, sesión, auditoría de accesos) | 29 oct 2026 |
| 2 | **Gestión Operativa** (operaciones, asignaciones, aprobaciones, alertas, incidencias, reportes y bitácora) | 5 nov 2026, 20:00 |

## Cómo ejecutarlo

Requisitos: [Node.js](https://nodejs.org) 18 o superior.

```bash
git clone <URL-del-repositorio>
cd aguas-claras
npm install
cp .env.example .env      # en Windows: copy .env.example .env
npm start
```

Abre http://localhost:3000. La base de datos (`data/aguas-claras.db`) se crea sola la primera vez, con los roles, los permisos, las cuentas de demostración y 6 operaciones de ejemplo. Si ya tenías una base de la Épica 1, se actualiza sola al iniciar, sin perder datos.

Cuentas de demostración (contraseña `Demo123*`), con el dominio `@aguaclara.do`:

| Rol | Correo | Para qué sirve en la Épica 2 |
|---|---|---|
| Supervisor | `supervisor@` | Crea, asigna, aprueba y configura plazos |
| Ingeniero / Arquitecto / Agente | `ingeniero@`, `arquitecto@`, `agente@` | Operadores: registran y siguen sus operaciones |
| Gerente | `gerente@` | Genera y exporta reportes |
| Auditor | `auditor@` | Consulta la bitácora (solo lectura) |
| Administrador | `admin@` | Todo, menos modificar permisos |
| Super Administrador | `super@` | Todo |
| Cliente | `cliente@` | Sin acceso a operaciones |

Para empezar de cero: detén el servidor y borra la carpeta `data/`.

## Pruebas

```bash
npm test
```

Ejecuta **63 casos** contra la API con una base de datos temporal: 24 de la Épica 1 y 39 de la Épica 2 (reglas de negocio, permisos, alertas, informes y bitácora). Resultado esperado: `# pass 63`.

## Épica 2 – Gestión Operativa

**Estados oficiales:** Creada → En proceso → (En aprobación →) Completada → Cerrada. También Rechazada (se puede reabrir) y Cancelada.

**Reglas de negocio principales**
- No se inicia una operación sin responsable; no hay transiciones fuera del ciclo de vida.
- Un tipo con aprobación obligatoria no puede completarse sin la decisión del rol aprobador; quien tiene la operación asignada no puede aprobarla.
- Cancelar, reabrir, devolver, rechazar y reasignar exigen un motivo; cerrar exige el resultado.
- No se cierra una operación con incidencias sin resolver, ni se registran incidencias en una cerrada o cancelada.
- Un operador solo modifica lo propio; supervisión modifica todo.
- La bitácora no se puede modificar ni eliminar (lo impide la propia base de datos).

| Historia | Dónde verla |
|---|---|
| HU-2.1 Panel de operaciones | Panel → Operaciones |
| HU-2.2 Registro y seguimiento | Operaciones → Nueva operación / Ver |
| HU-2.3 Asignación de responsables | Detalle de la operación → Asignar |
| HU-2.4 Flujos de aprobación | Aprobaciones; Tipos y plazos |
| HU-2.5 Alertas y vencimientos | Tipos y plazos; Alertas (🔔) |
| HU-2.6 Incidencias operativas | Incidencias |
| HU-2.7 Reportes operativos | Informes (generar y exportar CSV) |
| HU-2.8 Bitácora de cambios | Bitácora |

## Arquitectura

```
Navegador (public/)  →  API REST (server/)  →  SQLite (data/aguas-claras.db)
```

La página solo muestra datos. **Todas las reglas de seguridad y de negocio se validan en el servidor:** la API responde `401` (sin sesión), `403` (sin permiso) o `409` (regla de negocio) y deja constancia.

| Tabla | Contenido |
|---|---|
| `usuarios`, `roles`, `permisos`, `sesiones`, `tokens_recuperacion`, `auditoria`, `reportes`, `config` | Épica 1 |
| `tipos_operacion` | Tipos, plazo (SLA), aviso previo y flujo de aprobación |
| `operaciones` | Operaciones con código `OP-0001`, estado, responsable y fecha límite |
| `asignaciones` | Quién asignó a quién, cuándo y por qué |
| `aprobaciones` | Aprobador, decisión, fecha y comentario |
| `incidencias`, `incidencia_comentarios` | Incidencias `INC-0001` vinculadas a una operación |
| `notificaciones` | Alertas y avisos, con canal y resultado del envío |
| `bitacora` | Historial inmutable: actor, fecha, entidad, acción, resultado, valores antes y después |

### Endpoints de la Épica 2

| Ruta | Qué hace | Módulo y permiso |
|---|---|---|
| `GET /api/operaciones` | Lista con filtros e indicadores | Operaciones: consultar |
| `POST /api/operaciones`, `PUT …/:codigo` | Crear y actualizar | Operaciones: crear / modificar |
| `POST …/:codigo/estado` | Cambiar estado con reglas | Operaciones: modificar |
| `POST …/:codigo/asignar` | Asignar o reasignar | Asignaciones: crear |
| `POST …/:codigo/aprobacion`, `GET /api/aprobaciones` | Decidir y ver pendientes | Aprobaciones |
| `GET/POST/PUT /api/tipos`, `PUT /api/alertas/config` | Plazos y flujos | Tipos y plazos |
| `POST /api/alertas/generar`, `GET /api/alertas`, `GET /api/notificaciones` | Alertas y avisos | Operaciones / sesión |
| `GET/POST /api/incidencias…` | Incidencias y comentarios | Incidencias |
| `GET /api/informes`, `GET /api/informes/exportar` | Reporte y CSV | Informes: consultar / crear (exportar) |
| `GET /api/bitacora` | Historial de cambios | Bitácora: consultar |

## Configuración (`.env`)

| Variable | Para qué sirve |
|---|---|
| `PORT` | Puerto del servidor (3000 por defecto) |
| `DB_FILE` | Ruta del archivo SQLite |
| `SEED_DEMO` | `1` crea cuentas y operaciones de demostración; `0` para uso real |
| `ADMIN_EMAIL` / `ADMIN_PASSWORD` | Super Administrador inicial cuando `SEED_DEMO=0` |
| `MODO_DEMO` | `1` muestra el enlace de recuperación en pantalla (correo simulado) |
| `COOKIE_SECURE`, `TRUST_PROXY` | Poner en `1` al publicar con HTTPS / detrás de un proxy |

**El archivo `.env` y la carpeta `data/` nunca se suben a Git** (están en `.gitignore`).

## Script de base de datos

La aplicación crea la base sola al iniciar, pero el repositorio incluye los mismos scripts SQL para usarlos a mano (por ejemplo en DB Browser, pestaña *Execute SQL*):

```bash
sqlite3 data/aguas-claras.db < database/schema.sql      # 28 tablas, índices y 4 triggers (Épicas 1-3)
sqlite3 data/aguas-claras.db < database/seed.sql        # roles, permisos, tipos y configuración
sqlite3 data/aguas-claras.db < database/seed_demo.sql   # opcional: usuarios de demostración
```

Los diagramas del diseño (arquitectura, secuencia, estados y entidad-relación) están en `docs/diagramas/`, y el documento completo en `docs/entregable-1-analisis-y-diseno.docx`.

## Limitaciones conocidas

- Las notificaciones usan el canal interno de la página (campana 🔔). No se envían correos ni mensajes externos.
- El correo de recuperación de contraseña es simulado (ver `MODO_DEMO`).
- La localización por IP devuelve “Red local” o “No disponible”; para la ciudad real: `npm install geoip-lite`.
- Si se publica en internet, usar HTTPS y `COOKIE_SECURE=1`.

## Estructura

```
public/             Página (index.html, css/, js/app.js, js/operaciones.js)
server/index.js     API: sesión, usuarios, roles, permisos, auditoría y reportes
server/operaciones.js  API de la Épica 2
server/db.js        Esquema SQLite, migración y datos iniciales
database/           Scripts SQL: schema.sql, seed.sql y seed_demo.sql (ver abajo)
tests/              Pruebas de la API (Épica 1 y Épica 2)
docs/               Documentación actualizada
evidencia/          Videos de las demostraciones
.env.example        Plantilla de configuración
```

## Épica 3 – Gestión Logística

Módulos nuevos del panel (menú «Gestión logística»): Catálogo, Solicitudes, Planificación, Inventario, Entregas, Devoluciones y mantenimiento, Proveedores, Indicadores y reportes.

| Historia | Contenido |
|---|---|
| HU-3.1 | Catálogo de recursos (materiales, equipos, vehículos), categorías y almacenes |
| HU-3.2 | Solicitudes de recursos con validaciones y seguimiento |
| HU-3.3 | Aprobación o rechazo (nadie decide su propia solicitud) y cancelación |
| HU-3.4 | Inventario: entradas, salidas, ajustes; saldo = suma de movimientos inmutables; sin saldos negativos |
| HU-3.5 | Planificación: asignación con responsable, validación de disponibilidad y conflictos con confirmación |
| HU-3.6 | Entregas por hitos, evidencia opcional/obligatoria configurable, cierre con datos mínimos |
| HU-3.7 | Devoluciones (Buena / Dañado / Requiere mantenimiento) y mantenimiento de equipos y vehículos |
| HU-3.8 | Proveedores, órdenes de servicio, indicadores y reportes (CSV) |

Cuentas nuevas de demostración (clave `Demo123*`): `coordinador@aguaclara.do` y `encargado@aguaclara.do`.
Pruebas: `npm test` ejecuta 93 pruebas automáticas (30 nuevas de la Épica 3). Evidencia en `evidencia/capturas-epica-3/` y `evidencia/demo-epica-3.mp4`.

## Documentación de la API (Swagger) e integración

- Con el servidor encendido abre **http://localhost:3000/api-docs**: especificación OpenAPI con todos los endpoints (más de 100), el permiso que exige cada uno y ejemplos. Para probar, ejecuta `POST /api/login` con `super@aguaclara.do` / `Demo123*` y luego cualquier endpoint protegido.
- La especificación en JSON está en `/api-docs.json` y se genera leyendo las rutas reales del código.
- En el panel, la opción **Integración API y datos** muestra en vivo la conexión página → API → SQLite: estado, tablas con su número de filas y un CRUD completo (crear, consultar, modificar, eliminar) con la petición y la respuesta visibles.
- La opción **Acerca de** define el alcance: portal institucional de un servicio de agua, con parte pública para la ciudadanía y panel interno para el personal.
