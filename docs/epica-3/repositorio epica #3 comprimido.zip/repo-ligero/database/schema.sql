-- Agua Clara RD · esquema completo (Épicas 1, 2 y 3): 28 tablas, 9 índices, 4 triggers
PRAGMA foreign_keys = ON;
CREATE TABLE roles(
  id INTEGER PRIMARY KEY, nombre TEXT UNIQUE NOT NULL COLLATE NOCASE, activo INTEGER NOT NULL DEFAULT 1);
CREATE TABLE usuarios(
  id INTEGER PRIMARY KEY, nombre TEXT NOT NULL, correo TEXT UNIQUE NOT NULL COLLATE NOCASE,
  telefono TEXT DEFAULT '', clave_hash TEXT NOT NULL,
  rol_id INTEGER NOT NULL REFERENCES roles(id),
  estado TEXT NOT NULL DEFAULT 'Activo', motivo TEXT DEFAULT '', foto TEXT, actualizado INTEGER NOT NULL);
CREATE TABLE permisos(
  rol_id INTEGER NOT NULL REFERENCES roles(id) ON DELETE CASCADE, modulo TEXT NOT NULL,
  crear INTEGER NOT NULL DEFAULT 0, consultar INTEGER NOT NULL DEFAULT 0,
  modificar INTEGER NOT NULL DEFAULT 0, eliminar INTEGER NOT NULL DEFAULT 0,
  PRIMARY KEY(rol_id, modulo));
CREATE TABLE sesiones(
  token TEXT PRIMARY KEY, usuario_id INTEGER NOT NULL REFERENCES usuarios(id) ON DELETE CASCADE, expira INTEGER NOT NULL);
CREATE TABLE tokens_recuperacion(
  token TEXT PRIMARY KEY, usuario_id INTEGER NOT NULL REFERENCES usuarios(id) ON DELETE CASCADE,
  expira INTEGER NOT NULL, usado INTEGER NOT NULL DEFAULT 0);
CREATE TABLE auditoria(
  id INTEGER PRIMARY KEY, fecha INTEGER NOT NULL, usuario TEXT NOT NULL, evento TEXT NOT NULL,
  ip TEXT, localizacion TEXT, detalle TEXT DEFAULT '');
CREATE TABLE reportes(
  id INTEGER PRIMARY KEY, codigo TEXT UNIQUE NOT NULL, municipio TEXT NOT NULL, sector TEXT NOT NULL,
  tipo TEXT NOT NULL, desde TEXT, descripcion TEXT NOT NULL, estado INTEGER NOT NULL DEFAULT 0,
  contacto_nombre TEXT, contacto_telefono TEXT, creado INTEGER NOT NULL);
CREATE TABLE config(clave TEXT PRIMARY KEY, valor TEXT NOT NULL);
CREATE TABLE tipos_operacion(
  id INTEGER PRIMARY KEY, nombre TEXT UNIQUE NOT NULL COLLATE NOCASE,
  sla_horas INTEGER NOT NULL DEFAULT 48, aviso_horas INTEGER NOT NULL DEFAULT 12,
  requiere_aprobacion INTEGER NOT NULL DEFAULT 0, aprobador_rol_id INTEGER REFERENCES roles(id) ON DELETE SET NULL,
  activo INTEGER NOT NULL DEFAULT 1);
CREATE TABLE operaciones(
  id INTEGER PRIMARY KEY, codigo TEXT UNIQUE NOT NULL, tipo_id INTEGER NOT NULL REFERENCES tipos_operacion(id),
  titulo TEXT NOT NULL, descripcion TEXT NOT NULL, prioridad TEXT NOT NULL DEFAULT 'Media',
  estado TEXT NOT NULL DEFAULT 'Creada',
  responsable_id INTEGER REFERENCES usuarios(id) ON DELETE SET NULL, creado_por INTEGER REFERENCES usuarios(id) ON DELETE SET NULL,
  reporte_codigo TEXT, fecha_limite INTEGER NOT NULL, resultado TEXT,
  creado INTEGER NOT NULL, actualizado INTEGER NOT NULL, cerrado INTEGER);
CREATE TABLE asignaciones(
  id INTEGER PRIMARY KEY, operacion_id INTEGER NOT NULL REFERENCES operaciones(id) ON DELETE CASCADE,
  responsable_id INTEGER REFERENCES usuarios(id) ON DELETE SET NULL, asignado_por INTEGER REFERENCES usuarios(id) ON DELETE SET NULL,
  fecha INTEGER NOT NULL, motivo TEXT DEFAULT '');
CREATE TABLE aprobaciones(
  id INTEGER PRIMARY KEY, operacion_id INTEGER NOT NULL REFERENCES operaciones(id) ON DELETE CASCADE,
  aprobador_id INTEGER REFERENCES usuarios(id) ON DELETE SET NULL, decision TEXT NOT NULL,
  comentario TEXT DEFAULT '', fecha INTEGER NOT NULL);
CREATE TABLE incidencias(
  id INTEGER PRIMARY KEY, codigo TEXT UNIQUE NOT NULL, operacion_id INTEGER NOT NULL REFERENCES operaciones(id) ON DELETE CASCADE,
  categoria TEXT NOT NULL, descripcion TEXT NOT NULL, prioridad TEXT NOT NULL DEFAULT 'Media',
  responsable_id INTEGER REFERENCES usuarios(id) ON DELETE SET NULL, estado TEXT NOT NULL DEFAULT 'Abierta',
  resolucion TEXT, creado_por INTEGER REFERENCES usuarios(id) ON DELETE SET NULL, creado INTEGER NOT NULL, actualizado INTEGER NOT NULL);
CREATE TABLE incidencia_comentarios(
  id INTEGER PRIMARY KEY, incidencia_id INTEGER NOT NULL REFERENCES incidencias(id) ON DELETE CASCADE,
  usuario TEXT NOT NULL, texto TEXT NOT NULL, fecha INTEGER NOT NULL);
CREATE TABLE notificaciones(
  id INTEGER PRIMARY KEY, usuario_id INTEGER NOT NULL REFERENCES usuarios(id) ON DELETE CASCADE, tipo TEXT NOT NULL,
  operacion_id INTEGER REFERENCES operaciones(id) ON DELETE CASCADE, mensaje TEXT NOT NULL,
  canal TEXT NOT NULL DEFAULT 'interno', resultado TEXT NOT NULL DEFAULT 'Entregada', leida INTEGER NOT NULL DEFAULT 0, fecha INTEGER NOT NULL);
CREATE TABLE bitacora(
  id INTEGER PRIMARY KEY, fecha INTEGER NOT NULL, actor_id INTEGER, actor TEXT NOT NULL, entidad TEXT NOT NULL, entidad_id TEXT,
  operacion TEXT, accion TEXT NOT NULL, resultado TEXT NOT NULL DEFAULT 'Exitoso', antes TEXT, despues TEXT, detalle TEXT DEFAULT '');
CREATE TABLE categorias_recurso(
  id INTEGER PRIMARY KEY, nombre TEXT UNIQUE NOT NULL COLLATE NOCASE, activo INTEGER NOT NULL DEFAULT 1);
CREATE TABLE almacenes(
  id INTEGER PRIMARY KEY, codigo TEXT UNIQUE NOT NULL, nombre TEXT UNIQUE NOT NULL COLLATE NOCASE,
  ubicacion TEXT DEFAULT '', activo INTEGER NOT NULL DEFAULT 1);
CREATE TABLE recursos(
  id INTEGER PRIMARY KEY, codigo TEXT UNIQUE NOT NULL, nombre TEXT NOT NULL,
  categoria_id INTEGER NOT NULL REFERENCES categorias_recurso(id),
  tipo TEXT NOT NULL DEFAULT 'Material', unidad TEXT NOT NULL DEFAULT 'unidad', descripcion TEXT DEFAULT '',
  stock_minimo REAL NOT NULL DEFAULT 0, estado TEXT NOT NULL DEFAULT 'Operativo', activo INTEGER NOT NULL DEFAULT 1,
  creado INTEGER NOT NULL, actualizado INTEGER NOT NULL);
CREATE TABLE movimientos(
  id INTEGER PRIMARY KEY, recurso_id INTEGER NOT NULL REFERENCES recursos(id), almacen_id INTEGER NOT NULL REFERENCES almacenes(id),
  tipo TEXT NOT NULL, cantidad REAL NOT NULL, saldo_despues REAL NOT NULL, motivo TEXT NOT NULL, referencia TEXT,
  usuario_id INTEGER, usuario TEXT NOT NULL, fecha INTEGER NOT NULL);
CREATE TABLE solicitudes(
  id INTEGER PRIMARY KEY, codigo TEXT UNIQUE NOT NULL, solicitante_id INTEGER REFERENCES usuarios(id) ON DELETE SET NULL,
  actividad TEXT NOT NULL, requerimiento TEXT NOT NULL, recurso_id INTEGER REFERENCES recursos(id), cantidad REAL NOT NULL DEFAULT 1,
  fecha_requerida INTEGER NOT NULL, ubicacion TEXT NOT NULL, justificacion TEXT NOT NULL, prioridad TEXT NOT NULL DEFAULT 'Media',
  operacion_codigo TEXT, estado TEXT NOT NULL DEFAULT 'Pendiente', decision_comentario TEXT,
  decidido_por INTEGER REFERENCES usuarios(id) ON DELETE SET NULL, creado INTEGER NOT NULL, actualizado INTEGER NOT NULL);
CREATE TABLE solicitud_comentarios(
  id INTEGER PRIMARY KEY, solicitud_id INTEGER NOT NULL REFERENCES solicitudes(id) ON DELETE CASCADE,
  usuario TEXT NOT NULL, texto TEXT NOT NULL, fecha INTEGER NOT NULL);
CREATE TABLE asignaciones_recurso(
  id INTEGER PRIMARY KEY, solicitud_id INTEGER NOT NULL REFERENCES solicitudes(id) ON DELETE CASCADE,
  recurso_id INTEGER NOT NULL REFERENCES recursos(id), almacen_id INTEGER NOT NULL REFERENCES almacenes(id),
  cantidad REAL NOT NULL, responsable_id INTEGER REFERENCES usuarios(id) ON DELETE SET NULL,
  fecha_programada INTEGER NOT NULL, ubicacion TEXT NOT NULL, estado TEXT NOT NULL DEFAULT 'Reservada',
  con_conflicto INTEGER NOT NULL DEFAULT 0, devuelta REAL NOT NULL DEFAULT 0,
  creado_por INTEGER REFERENCES usuarios(id) ON DELETE SET NULL, creado INTEGER NOT NULL, actualizado INTEGER NOT NULL);
CREATE TABLE entregas_hitos(
  id INTEGER PRIMARY KEY, solicitud_id INTEGER NOT NULL REFERENCES solicitudes(id) ON DELETE CASCADE,
  asignacion_id INTEGER REFERENCES asignaciones_recurso(id) ON DELETE SET NULL, tipo TEXT NOT NULL, fecha INTEGER NOT NULL,
  responsable_id INTEGER REFERENCES usuarios(id) ON DELETE SET NULL, nota TEXT DEFAULT '', recibido_por TEXT,
  evidencia_nombre TEXT, evidencia TEXT, creado INTEGER NOT NULL);
CREATE TABLE devoluciones(
  id INTEGER PRIMARY KEY, asignacion_id INTEGER NOT NULL REFERENCES asignaciones_recurso(id) ON DELETE CASCADE,
  cantidad REAL NOT NULL, condicion TEXT NOT NULL, observaciones TEXT DEFAULT '', fecha INTEGER NOT NULL,
  usuario_id INTEGER REFERENCES usuarios(id) ON DELETE SET NULL);
CREATE TABLE mantenimientos(
  id INTEGER PRIMARY KEY, recurso_id INTEGER NOT NULL REFERENCES recursos(id), tipo TEXT NOT NULL,
  estado TEXT NOT NULL DEFAULT 'En curso', descripcion TEXT NOT NULL, fecha_inicio INTEGER NOT NULL, fecha_fin INTEGER,
  resultado TEXT, observaciones TEXT DEFAULT '', responsable_id INTEGER REFERENCES usuarios(id) ON DELETE SET NULL);
CREATE TABLE proveedores(
  id INTEGER PRIMARY KEY, codigo TEXT UNIQUE NOT NULL, nombre TEXT UNIQUE NOT NULL COLLATE NOCASE, contacto TEXT DEFAULT '',
  telefono TEXT DEFAULT '', correo TEXT DEFAULT '', estado TEXT NOT NULL DEFAULT 'Activo', notas TEXT DEFAULT '',
  creado INTEGER NOT NULL, actualizado INTEGER NOT NULL);
CREATE TABLE ordenes_servicio(
  id INTEGER PRIMARY KEY, codigo TEXT UNIQUE NOT NULL, proveedor_id INTEGER NOT NULL REFERENCES proveedores(id),
  solicitud_id INTEGER NOT NULL REFERENCES solicitudes(id), alcance TEXT NOT NULL, fecha_inicio INTEGER, fecha_fin INTEGER,
  costo REAL, estado TEXT NOT NULL DEFAULT 'Emitida', creado_por INTEGER REFERENCES usuarios(id) ON DELETE SET NULL,
  creado INTEGER NOT NULL, actualizado INTEGER NOT NULL);
CREATE INDEX idx_auditoria_fecha ON auditoria(fecha DESC);
CREATE INDEX idx_op_estado ON operaciones(estado);
CREATE INDEX idx_notif_usuario ON notificaciones(usuario_id, leida);
CREATE INDEX idx_bitacora_op ON bitacora(operacion);
CREATE INDEX idx_bitacora_fecha ON bitacora(fecha DESC);
CREATE UNIQUE INDEX uq_recurso_nombre ON recursos(nombre COLLATE NOCASE, categoria_id);
CREATE INDEX idx_mov_recurso ON movimientos(recurso_id, almacen_id);
CREATE INDEX idx_mov_fecha ON movimientos(fecha DESC);
CREATE INDEX idx_sol_estado ON solicitudes(estado);
CREATE TRIGGER bitacora_sin_modificar BEFORE UPDATE ON bitacora
  BEGIN SELECT RAISE(ABORT, 'La bitácora no se puede modificar'); END;
CREATE TRIGGER bitacora_sin_eliminar BEFORE DELETE ON bitacora
  BEGIN SELECT RAISE(ABORT, 'La bitácora no se puede eliminar'); END;
CREATE TRIGGER movimientos_sin_modificar BEFORE UPDATE ON movimientos
  BEGIN SELECT RAISE(ABORT, 'Los movimientos de inventario no se pueden modificar'); END;
CREATE TRIGGER movimientos_sin_eliminar BEFORE DELETE ON movimientos
  BEGIN SELECT RAISE(ABORT, 'Los movimientos de inventario no se pueden eliminar'); END;
