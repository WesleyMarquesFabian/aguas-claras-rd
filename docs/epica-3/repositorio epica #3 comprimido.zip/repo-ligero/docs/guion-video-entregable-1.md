# Guion de la presentación en video del diseño

Entregable 1 · Agua Clara RD. Cada diapositiva dura el tiempo indicado; el texto es el que aparece como subtítulo y sirve para narrar con tu voz.

## Diapositiva 1 · Agua Clara RD · Entregable 1: Diseño y configuración del entorno
*Tiempo: 0:00 – 0:20 (20 s)*

Presentamos el diseño y la configuración del entorno de Agua Clara RD, un sistema para reportar averías y falta de agua y gestionar su atención. En este video resumimos los requerimientos, las tecnologías, la arquitectura y el modelo de datos.

## Diapositiva 2 · 1. Requerimientos funcionales y no funcionales
*Tiempo: 0:20 – 0:44 (24 s)*

Definimos veintitrés requerimientos funcionales: la parte pública, la gestión de usuarios y accesos, y la gestión operativa con aprobaciones, alertas, incidencias, reportes y una bitácora inmutable. También catorce no funcionales, como seguridad, integridad, trazabilidad, rendimiento y portabilidad. Medimos que, con cinco mil operaciones, las consultas responden en menos de sesenta milisegundos.

## Diapositiva 3 · 2. Tecnologías: código abierto y propietarias
*Tiempo: 0:44 – 1:06 (22 s)*

Elegimos tecnologías de código abierto: Node.js con Express para la API, SQLite como base de datos, bcrypt para cifrar contraseñas y JavaScript estándar en el front-end. Como servicios propietarios usamos GitHub y Google Fonts, y evaluamos correo, mensajería, geolocalización y alojamiento para la siguiente fase.

## Diapositiva 4 · 3. Arquitectura en tres capas
*Tiempo: 1:06 – 1:30 (24 s)*

La arquitectura tiene tres capas. La página en el navegador, el servidor Node.js con la API y las reglas de negocio, y la base de datos SQLite. La página nunca habla directamente con la base de datos: todo pasa por la API, que valida la sesión y los permisos.

## Diapositiva 5 · 4. Estructura del front-end
*Tiempo: 1:30 – 1:55 (25 s)*

El front-end es una aplicación de una sola página sin framework. El archivo app punto js contiene la comunicación con la API, el estado y el enrutador de vistas; operaciones punto js agrega las pantallas de la Épica 2 sin modificar el núcleo. Los botones se habilitan según los permisos del usuario.

## Diapositiva 6 · 5. Estructura del back-end
*Tiempo: 1:55 – 2:16 (21 s)*

En el back-end, cada petición pasa por una cadena fija: lectura de JSON, cabeceras de seguridad, identificación de la sesión, autorización por módulo y acción, reglas de negocio y, finalmente, consultas SQL parametrizadas. Sin sesión responde cuatrocientos uno y sin permiso, cuatrocientos tres.

## Diapositiva 7 · 6. Interacción entre componentes
*Tiempo: 2:16 – 2:36 (20 s)*

Este diagrama muestra cómo se crea una operación. Se valida el permiso y las reglas de negocio; si algo falla, el rechazo queda en la bitácora. Si todo es válido, una transacción guarda la operación, la asignación, la bitácora y la notificación.

## Diapositiva 8 · 7. Ciclo de vida de una operación
*Tiempo: 2:36 – 2:55 (19 s)*

El ciclo de vida de una operación define las únicas transiciones permitidas. Por ejemplo, no se inicia sin responsable, un tipo con aprobación no se completa sin que el aprobador decida, y no se cierra con incidencias sin resolver.

## Diapositiva 9 · 8. Modelo relacional
*Tiempo: 2:55 – 3:16 (21 s)*

El modelo relacional tiene dieciséis tablas, diecinueve llaves foráneas, cinco índices y dos triggers. Está en tercera forma normal. La bitácora no tiene llaves foráneas a propósito, para conservar el historial aunque se eliminen usuarios u operaciones, y dos triggers impiden modificarla o borrarla.

## Diapositiva 10 · 9. Script de base de datos
*Tiempo: 3:16 – 3:43 (27 s)*

El repositorio incluye el script de la base de datos: schema punto sql crea las tablas, índices y triggers; seed punto sql carga roles, permisos y tipos; y seed demo agrega usuarios de prueba. Verificamos que una base creada solo con estos scripts es idéntica a la de la aplicación y que el sistema arranca sobre ella.

## Diapositiva 11 · 10. Configuración del entorno y cierre
*Tiempo: 3:43 – 4:00 (17 s)*

Para ejecutarlo basta clonar el repositorio, instalar dependencias, copiar el archivo de configuración y ejecutar npm start. El diseño ya está implementado y probado con sesenta y tres pruebas automáticas. Gracias por su atención.

**Duración total: 4 min 0 s**