/* Accesibilidad: tema claro / oscuro / automático. Se recuerda en este navegador y se aplica antes de pintar la página. */
(function () {
  var K = 'ac_tema';
  function leer() { try { return localStorage.getItem(K) || 'auto'; } catch (e) { return 'auto'; } }
  function aplicar(t) { var h = document.documentElement; if (t === 'light' || t === 'dark') h.setAttribute('data-theme', t); else h.removeAttribute('data-theme'); }
  aplicar(leer());
  window.addEventListener('DOMContentLoaded', function () {
    var w = document.createElement('div'); w.id = 'acc';
    w.innerHTML = '<button type="button" id="acc-b" aria-haspopup="true" aria-expanded="false" aria-controls="acc-p" title="Accesibilidad">Accesibilidad</button>' +
      '<div id="acc-p" role="group" aria-label="Opciones de accesibilidad" hidden><b>Tema de la página</b>' +
      '<label><input type="radio" name="acc-t" value="light"> Claro</label><label><input type="radio" name="acc-t" value="dark"> Oscuro</label><label><input type="radio" name="acc-t" value="auto"> Automático (según tu dispositivo)</label></div>';
    document.body.appendChild(w);
    var b = w.querySelector('#acc-b'), p = w.querySelector('#acc-p');
    function sync() { var t = leer(); w.querySelectorAll('input').forEach(function (i) { i.checked = i.value === t; }); }
    b.onclick = function () { var o = p.hidden; p.hidden = !o; b.setAttribute('aria-expanded', String(o)); sync(); };
    w.addEventListener('change', function (e) { var t = e.target.value; try { localStorage.setItem(K, t); } catch (x) {} aplicar(t); });
    document.addEventListener('keydown', function (e) { if (e.key === 'Escape' && !p.hidden) { p.hidden = true; b.setAttribute('aria-expanded', 'false'); b.focus(); } });
    sync();
  });
})();
