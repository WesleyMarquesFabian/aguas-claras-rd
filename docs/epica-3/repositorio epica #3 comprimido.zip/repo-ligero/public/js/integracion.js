/* Integración API ↔ base de datos: muestra en vivo que la pantalla, la API y SQLite están conectadas (CRUD completo con la petición y la respuesta visibles). */
var I = { est: null, cats: null, last: null, err: '' };
LOAD_EXTRA.integracion = async function () {
  const [e, c] = await Promise.all([g('/sistema/estado'), g('/categorias-recurso')]);
  I.est = e; I.cats = c ? c.items : [];
};
async function peticion(metodo, url, body) {
  const t0 = performance.now(), r = await api(metodo, url, body), { ok, s, ...datos } = r;
  I.last = { metodo, url: '/api' + url, body, estado: r.s || 0, ms: Math.round(performance.now() - t0), resp: datos }; I.err = r.ok ? '' : (r.error || 'La API rechazó la petición.');
  await loadTab(); return r;
}
const iNueva = () => peticion('POST', '/categorias-recurso', { nombre: v$('i_nom') });
const iGuardar = (id) => peticion('PUT', '/categorias-recurso/' + id, { nombre: v$('i_n' + id) });
const iBorrar = (id) => peticion('DELETE', '/categorias-recurso/' + id);
function tIntegracion() {
  const e = I.est; if (!e) return '<div class="card">Cargando…</div>';
  const db = e.baseDatos;
  return `<h2 style="margin:0 0 4px">Integración entre la página, la API y la base de datos</h2>
<p class="mu">Cada botón de esta pantalla llama a la API, la API valida permisos y reglas, y guarda o lee en SQLite. Aquí puedes verlo en vivo.</p>
<div class="inds" style="margin:10px 0"><div class="ind"><b>${esc(e.api)}</b><span>Estado de la API</span></div><div class="ind"><b>${esc(db.motor)}</b><span>Base de datos (${esc(db.archivo)})</span></div><div class="ind"><b>${db.tablas.length}</b><span>Tablas</span></div><div class="ind"><b>${db.total_filas}</b><span>Filas guardadas</span></div><div class="ind"><b>${e.endpoints}</b><span>Endpoints documentados</span></div></div>
<p><a class="btn s sm" href="/api-docs" target="_blank" rel="noopener">Abrir documentación Swagger</a> <span class="mu sm">Permite probar cada endpoint desde el navegador.</span></p>
<div class="g2" style="align-items:start;margin-top:12px"><div class="card"><h3>Categorías de recursos: crear, consultar, modificar y eliminar</h3>
<div class="row"><input id="i_nom" placeholder="Nombre de la nueva categoría" aria-label="Nombre de la nueva categoría">${act('catalogo', 'c', 'iNueva()', 'Crear', '')}</div>
${I.err ? `<div class="banner er" role="alert">${esc(I.err)}</div>` : ''}
<div class="tw"><table><tr><th>Id</th><th>Nombre</th><th>Recursos</th><th></th></tr>${I.cats.map((c) => `<tr><td>${c.id}</td><td><input id="i_n${c.id}" value="${esc(c.nombre)}" aria-label="Nombre de la categoría ${c.id}"></td><td>${c.recursos}</td><td>${act('catalogo', 'u', `iGuardar(${c.id})`, 'Guardar')} ${act('catalogo', 'd', `iBorrar(${c.id})`, 'Eliminar', 'r')}</td></tr>`).join('')}</table></div>
<p class="hint">Una categoría con recursos no se puede eliminar. El permiso de eliminar lo tiene solo el Super Administrador.</p></div>
<div class="card"><h3>Última petición a la API</h3>${I.last ? `<p><span class="tag">${I.last.metodo}</span> <code>${esc(I.last.url)}</code> → <span class="tag ${I.last.estado >= 400 ? 'er' : ''}">${I.last.estado}</span> <span class="mu sm">${I.last.ms} ms</span></p>${I.last.body ? `<p class="sm"><b>Enviado</b></p><pre style="white-space:pre-wrap;overflow:auto">${esc(JSON.stringify(I.last.body, null, 2))}</pre>` : ''}<p class="sm"><b>Respuesta de la API</b></p><pre style="white-space:pre-wrap;overflow:auto">${esc(JSON.stringify(I.last.resp, null, 2))}</pre>` : '<p class="mu">Crea, modifica o elimina una categoría para ver aquí la petición y la respuesta.</p>'}</div></div>
<div class="card" style="margin-top:12px"><h3>Contenido actual de la base de datos</h3><div class="tw"><table><tr><th>Tabla</th><th>Filas</th></tr>${db.tablas.map((t) => `<tr><td>${esc(t.nombre)}</td><td>${t.filas}</td></tr>`).join('')}</table></div></div>`;
}
TABS_EXTRA.integracion = tIntegracion;
