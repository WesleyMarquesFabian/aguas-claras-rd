/* Épica 3 – Gestión Logística (pantallas del panel). Usa app.js y operaciones.js: api, g, can, act, esc, toast, R, tab, opts, dt, qs, v$, stTag, accion, dif, bitTabla */
var L = { rec: null, cats: [], alms: [], f: {}, fRec: {}, nuevoRec: false, editRec: null, sol: null, solF: {}, solSel: null, solDet: null, nuevaSol: false, plan: null, asg: [], resp: [], conf: null,
  inv: null, mov: null, fi: {}, fm: {}, entregas: null, ent: null, mant: null, prov: null, ord: null, ind: null, fInd: {}, err: '', cfg: { evidenciaHabilitada: true, evidenciaObligatoria: false }, evid: null, aviso: '' };
const SOL_EST = ['Pendiente', 'Aprobada', 'Planificada', 'En ejecución', 'Entregada', 'Cerrada', 'Rechazada', 'Cancelada'];
const lErr = () => (L.err ? `<div class="banner er" role="alert">${esc(L.err)}</div>` : '') + (L.aviso ? `<div class="banner" role="status">${esc(L.aviso)}</div>` : '');
const n$ = (n) => (n === null || n === undefined ? '—' : Number(n).toLocaleString('es-DO'));
const dia = (t) => (t ? new Date(t).toLocaleDateString('es-DO') : '—');
const hoyISO = (d = 0) => new Date(Date.now() + d * 864e5).toISOString().slice(0, 10);
const cTag = (c) => `<span class="tag ${['Agotado', 'Fuera de servicio', 'Inactivo'].includes(c) ? 'er' : ['Reservado', 'Mantenimiento'].includes(c) ? 'warn' : ''}">${esc(c)}</span>`;
const sTag = (e) => `<span class="tag ${['Rechazada', 'Cancelada'].includes(e) ? 'er' : ['Pendiente'].includes(e) ? 'warn' : ''}">${esc(e)}</span>`;
async function lAcc(p, ok, despues) { const r = await p; L.err = r.ok ? '' : (r.error || 'No se pudo completar la acción.'); L.aviso = r.ok && r.advertencia ? r.advertencia : r.ok && r.avisos && r.avisos.length ? r.avisos.join(' ') : ''; if (r.ok && ok) toast(ok); if (despues) await despues(r); await loadTab(); return r; }
function lVol() { L.err = ''; L.aviso = ''; }

/* ---- carga de datos por pestaña ---- */
var LOAD_EXTRA = {
  async catalogo() { const r = await g('/recursos?' + qs({ ...L.fRec, activo: L.fRec.activo || '1' })); L.rec = r ? r.items : []; if (r) { L.cats = r.categorias; L.alms = r.almacenes; } },
  async solicitudes() {
    const [s, r] = await Promise.all([g('/solicitudes?' + qs(L.solF)), g('/recursos')]);
    L.sol = s ? s.items : []; L.porEstado = s ? s.porEstado : []; if (r) { L.rec = r.items; L.cats = r.categorias; L.alms = r.almacenes; }
    if (L.solSel) { L.solDet = await g('/solicitudes/' + L.solSel); if (!L.solDet) L.solSel = null; if (L.solDet && can('planificacion', 'r') && !L.resp.length) { const rs = await g('/logistica/responsables'); L.resp = rs ? rs.items : []; } }
  },
  async planificacion() {
    const [p, a, rs, rc] = await Promise.all([g('/planificacion/pendientes'), g('/asignaciones-recurso'), g('/logistica/responsables'), g('/recursos')]);
    L.plan = p ? p.items : []; L.alms = p ? p.almacenes : L.alms; L.asg = a ? a.items : []; L.resp = rs ? rs.items : []; L.rec = rc ? rc.items : [];
  },
  async inventario() { const [e, m, r] = await Promise.all([g('/inventario/existencias?' + qs(L.fi)), g('/inventario/movimientos?' + qs(L.fm)), g('/recursos')]); L.inv = e ? e.items : []; L.mov = m ? m.items : []; if (r) { L.rec = r.items; L.cats = r.categorias; L.alms = r.almacenes; } },
  async entregas() {
    const [e, c] = await Promise.all([g('/entregas'), g('/logistica/config')]); L.entregas = e ? e.items : []; if (c) L.cfg = c.cfg;
    if (L.entSel) { L.ent = await g('/solicitudes/' + L.entSel); if (!L.ent) L.entSel = null; }
  },
  async mantenimiento() { const [m, r] = await Promise.all([g('/mantenimientos'), g('/recursos')]); L.mant = m || { items: [], devoluciones: [], pendientesDevolucion: [] }; L.rec = r ? r.items : []; },
  async proveedores() { const [p, o, s] = await Promise.all([g('/proveedores'), g('/ordenes-servicio'), g('/solicitudes')]); L.prov = p ? p.items : []; L.ord = o ? o.items : []; L.sol = s ? s.items : []; },
  async indicadores() { const r = await g('/logistica/indicadores?' + qs(L.fInd)); L.ind = r; },
};

/* ---- HU-3.1 Catálogo ---- */
function tCatalogo() {
  if (L.rec === null) return '<div class="card">Cargando…</div>';
  const f = L.fRec;
  return `<span class="hu">HU-3.1 · Catálogo de recursos</span><div class="card" style="margin:8px 0"><h3>Filtros</h3><div class="g3">
<div><label for="c_q">Buscar (código o nombre)</label><input id="c_q" value="${esc(f.q || '')}"></div>
<div><label for="c_tipo">Tipo</label><select id="c_tipo">${opts(['Material', 'Equipo', 'Vehículo'].map((x) => [x, x]), f.tipo, 'Todos')}</select></div>
<div><label for="c_cat">Categoría</label><select id="c_cat">${opts(L.cats.map((c) => [c.id, c.nombre]), f.categoria, 'Todas')}</select></div>
<div><label for="c_cond">Disponibilidad</label><select id="c_cond">${opts(['Disponible', 'Reservado', 'Agotado', 'Mantenimiento', 'Fuera de servicio'].map((x) => [x, x]), f.condicion, 'Todas')}</select></div>
<div><label for="c_act">Estado del registro</label><select id="c_act">${opts([['1', 'Activos'], ['0', 'Inactivos'], ['todos', 'Todos']], f.activo || '1')}</select></div></div>
<div class="row"><button class="btn" onclick="L.fRec={q:v$('c_q'),tipo:v$('c_tipo'),categoria:v$('c_cat'),condicion:v$('c_cond'),activo:v$('c_act')};loadTab()">Filtrar</button><button class="btn s" onclick="L.fRec={};loadTab()">Limpiar</button>
${act('catalogo', 'c', 'L.nuevoRec=!L.nuevoRec;L.editRec=null;lVol();R()', L.nuevoRec ? 'Cancelar' : '+ Nuevo recurso', '')}</div></div>
${L.nuevoRec ? formRec() : ''}${L.editRec ? formRec(L.rec.find((x) => x.codigo === L.editRec)) : ''}${!L.nuevoRec && !L.editRec ? lErr() : ''}
<div class="card"><div class="tw"><table><tr><th>Código</th><th>Recurso</th><th>Tipo</th><th>Categoría</th><th>Existencias</th><th>Disponible</th><th>Condición</th><th></th></tr>
${L.rec.map((r) => `<tr><td><b>${r.codigo}</b></td><td>${esc(r.nombre)}</td><td>${esc(r.tipo)}</td><td>${esc(r.categoria)}</td><td>${n$(r.existencias)} ${esc(r.unidad)}</td><td>${n$(r.disponible)}${r.bajo_minimo ? ' <span class="tag er">Bajo mínimo</span>' : ''}</td><td>${cTag(r.condicion)}</td>
<td>${act('catalogo', 'u', `L.editRec='${r.codigo}';L.nuevoRec=false;lVol();R();scrollTo(0,0)`, 'Editar')} ${r.activo ? act('catalogo', 'u', `desactivarRec('${r.codigo}')`, 'Desactivar') : act('catalogo', 'u', `reactivarRec('${r.codigo}')`, 'Reactivar')}</td></tr>`).join('') || '<tr><td colspan="8" class="mu">No hay recursos con esos filtros.</td></tr>'}</table></div></div>
<div class="g2" style="margin-top:12px"><div class="card"><h3>Categorías</h3><p>${L.cats.map((c) => `<span class="tag">${esc(c.nombre)}</span>`).join(' ')}</p>${can('catalogo', 'c') ? `<div class="row"><input id="c_ncat" placeholder="Nueva categoría" aria-label="Nueva categoría"><button class="btn s sm" onclick="lAcc(api('POST','/categorias-recurso',{nombre:v$('c_ncat')}),'Categoría creada')">Agregar</button></div>` : ''}</div>
<div class="card"><h3>Almacenes</h3><p>${L.alms.map((a) => `<span class="tag ${a.activo ? '' : 'er'}">${esc(a.codigo)} · ${esc(a.nombre)}</span>`).join(' ')}</p>${can('catalogo', 'c') ? `<div class="row"><input id="c_nalm" placeholder="Nombre del almacén" aria-label="Nombre del almacén"><input id="c_nubi" placeholder="Ubicación" aria-label="Ubicación"><button class="btn s sm" onclick="lAcc(api('POST','/almacenes',{nombre:v$('c_nalm'),ubicacion:v$('c_nubi')}),'Almacén creado')">Agregar</button></div>` : ''}</div></div>`;
}
function formRec(r) {
  const e = !!r;
  return `<div class="card" style="margin-bottom:10px"><h3>${e ? 'Editar ' + r.codigo : 'Nuevo recurso'}</h3><div class="g2">
<div><label for="r_nom">Nombre * (mínimo 3 caracteres)</label><input id="r_nom" value="${e ? esc(r.nombre) : ''}"></div>
<div><label for="r_cat">Categoría *</label><select id="r_cat">${opts(L.cats.map((c) => [c.id, c.nombre]), e ? r.categoria_id : '')}</select></div>
<div><label for="r_tipo">Tipo *</label><select id="r_tipo" ${e ? 'disabled' : ''}>${opts(['Material', 'Equipo', 'Vehículo'].map((x) => [x, x]), e ? r.tipo : 'Material')}</select></div>
<div><label for="r_uni">Unidad (materiales)</label><input id="r_uni" value="${e ? esc(r.unidad) : 'unidad'}" ${e ? 'disabled' : ''}></div>
<div><label for="r_min">Stock mínimo</label><input id="r_min" type="number" min="0" value="${e ? r.stock_minimo : 0}"></div>
<div><label for="r_cod">Código (opcional)</label><input id="r_cod" ${e ? 'disabled value="' + r.codigo + '"' : 'placeholder="Se genera automáticamente"'}></div></div>
<label for="r_desc">Descripción</label><textarea id="r_desc">${e ? esc(r.descripcion || '') : ''}</textarea>${lErr()}
<div class="row"><button class="btn" onclick="${e ? `guardarRec('${r.codigo}')` : 'crearRec()'}">${e ? 'Guardar cambios' : 'Crear recurso'}</button></div></div>`;
}
const datosRec = () => ({ nombre: v$('r_nom'), categoria_id: +v$('r_cat'), tipo: v$('r_tipo'), unidad: v$('r_uni'), stock_minimo: v$('r_min'), codigo: v$('r_cod'), descripcion: v$('r_desc') });
async function crearRec() { const r = await lAcc(api('POST', '/recursos', datosRec()), 'Recurso creado'); if (r.ok) { L.nuevoRec = false; L.err = ''; R(); } }
async function guardarRec(c) { const r = await lAcc(api('PUT', '/recursos/' + c, datosRec()), 'Recurso actualizado'); if (r.ok) { L.editRec = null; L.err = ''; R(); } }
function desactivarRec(c) { const m = prompt('Motivo para desactivar ' + c + ' (se conserva el historial):'); if (m !== null) lAcc(api('POST', `/recursos/${c}/activo`, { activo: false, motivo: m }), 'Recurso desactivado'); }
function reactivarRec(c) { lAcc(api('POST', `/recursos/${c}/activo`, { activo: true }), 'Recurso reactivado'); }

/* ---- HU-3.2 / 3.3 Solicitudes ---- */
function tSolicitudes() {
  if (L.sol === null) return '<div class="card">Cargando…</div>';
  if (L.solSel && L.solDet) return vSolDet();
  const f = L.solF;
  return `<span class="hu">HU-3.2 · HU-3.3 · Solicitudes de recursos</span><div class="inds" style="margin:8px 0">${(L.porEstado || []).filter((x) => x.total || ['Pendiente', 'Aprobada'].includes(x.estado)).map((x) => `<button class="ind ${f.estado === x.estado ? 'on' : ''}" onclick="L.solF={estado:'${x.estado}'};loadTab()"><b>${x.total}</b><span>${x.estado}</span></button>`).join('')}</div>
<div class="card" style="margin:8px 0"><div class="row" style="align-items:end"><div><label for="s_q">Buscar</label><input id="s_q" value="${esc(f.q || '')}"></div><div><label for="s_e">Estado</label><select id="s_e">${opts(SOL_EST.map((x) => [x, x]), f.estado, 'Todos')}</select></div>
<button class="btn" onclick="L.solF={q:v$('s_q'),estado:v$('s_e')};loadTab()">Filtrar</button><button class="btn s" onclick="L.solF={};loadTab()">Limpiar</button>${act('solicitudes', 'c', 'L.nuevaSol=!L.nuevaSol;lVol();R()', L.nuevaSol ? 'Cancelar' : '+ Nueva solicitud', '')}</div></div>
${L.nuevaSol ? formSol() : lErr()}
<div class="card"><div class="tw"><table><tr><th>Código</th><th>Actividad</th><th>Recurso</th><th>Cantidad</th><th>Necesaria para</th><th>Prioridad</th><th>Estado</th><th></th></tr>
${L.sol.map((s) => `<tr><td><b>${s.codigo}</b></td><td>${esc(s.actividad)}<div class="mu sm">${esc(s.solicitante)}</div></td><td>${s.recurso ? esc(s.recurso.nombre) : '<span class="mu">Servicio externo</span>'}</td><td>${n$(s.cantidad)}${s.recurso ? ' ' + esc(s.recurso.unidad) : ''}</td><td>${dia(s.fecha_requerida)}${s.vencida ? ' <span class="tag er">Vencida</span>' : ''}</td><td>${esc(s.prioridad)}</td><td>${sTag(s.estado)}</td><td><button class="btn s sm" onclick="L.solSel='${s.codigo}';lVol();loadTab();scrollTo(0,0)">Ver</button></td></tr>`).join('') || '<tr><td colspan="8" class="mu">No hay solicitudes.</td></tr>'}</table></div></div>`;
}
function formSol() {
  return `<div class="card" style="margin-bottom:10px"><h3>Nueva solicitud</h3><div class="g2">
<div><label for="n_act">Actividad * </label><input id="n_act" placeholder="Ej.: Reparación de tubería principal"></div>
<div><label for="n_req">Requerimiento *</label><input id="n_req" placeholder="Ej.: Tubería y accesorios"></div>
<div><label for="n_rec">Recurso (vacío = servicio externo)</label><select id="n_rec" onchange="lUni()">${opts(L.rec.filter((r) => r.activo && r.condicion !== 'Fuera de servicio').map((r) => [r.codigo, `${r.codigo} · ${r.nombre} (disp. ${n$(r.disponible)} ${r.unidad})`]), '', 'Servicio / sin recurso')}</select></div>
<div><label for="n_can">Cantidad *</label><input id="n_can" type="number" min="1" value="1"></div>
<div><label for="n_fec">Fecha en que se necesita *</label><input id="n_fec" type="date" min="${hoyISO()}" value="${hoyISO(3)}"></div>
<div><label for="n_pri">Prioridad</label><select id="n_pri">${opts(['Baja', 'Media', 'Alta', 'Crítica'].map((x) => [x, x]), 'Media')}</select></div>
<div><label for="n_ubi">Ubicación *</label><input id="n_ubi"></div><div><label for="n_op">Operación vinculada (opcional)</label><input id="n_op" placeholder="OP-0001"></div></div>
<label for="n_jus">Justificación * (mínimo 10 caracteres)</label><textarea id="n_jus"></textarea>${lErr()}<div class="row"><button class="btn" onclick="crearSol()">Enviar solicitud</button></div></div>`;
}
function lUni() { const r = L.rec.find((x) => x.codigo === v$('n_rec')); if (r && r.tipo !== 'Material') $('#n_can').value = 1; }
async function crearSol() {
  const r = await lAcc(api('POST', '/solicitudes', { actividad: v$('n_act'), requerimiento: v$('n_req'), recurso_codigo: v$('n_rec'), cantidad: v$('n_can'), fecha_requerida: v$('n_fec'), prioridad: v$('n_pri'), ubicacion: v$('n_ubi'), operacion_codigo: v$('n_op'), justificacion: v$('n_jus') }), 'Solicitud creada');
  if (r.ok) { L.nuevaSol = false; L.err = ''; L.aviso = (r.advertencias || []).join(' '); L.solSel = r.codigo; await loadTab(); }
}
function vSolDet() {
  const d = L.solDet, s = d.item, kv = (k, v) => `<div><span>${k}</span><b>${v}</b></div>`;
  return `<button class="btn s sm" onclick="L.solSel=null;lVol();loadTab()">← Volver al listado</button>
<div class="card" style="margin-top:10px"><span class="hu">HU-3.2 · Seguimiento de la solicitud</span><h3>${s.codigo} · ${esc(s.actividad)}</h3><p>${sTag(s.estado)} <span class="tag">${esc(s.prioridad)}</span>${s.vencida ? ' <span class="tag er">Vencida</span>' : ''}</p>
<div class="kv" style="margin:10px 0">${kv('Solicitante', esc(s.solicitante))}${kv('Recurso', s.recurso ? esc(s.recurso.codigo + ' · ' + s.recurso.nombre) : 'Servicio externo')}${kv('Cantidad', n$(s.cantidad) + (s.recurso ? ' ' + esc(s.recurso.unidad) : ''))}${kv('Asignado', n$(d.asignado))}${kv('Se necesita', dia(s.fecha_requerida))}${kv('Ubicación', esc(s.ubicacion))}${kv('Operación', esc(s.operacion || '—'))}</div>
<p><b>Requerimiento:</b> ${esc(s.requerimiento)}</p><p><b>Justificación:</b> ${esc(s.justificacion)}</p>${s.decision ? `<p><b>Decisión:</b> ${esc(s.decision)}</p>` : ''}
${(d.advertencias || []).map((a) => `<div class="banner">${esc(a)}</div>`).join('')}${lErr()}
${d.puedeDecidir ? `<h3 style="margin-top:12px">HU-3.3 · Decisión</h3><label for="d_com">Comentario (obligatorio para rechazar)</label><input id="d_com"><div class="row"><button class="btn sm" onclick="decidirSol('${s.codigo}','Aprobada')">Aprobar</button><button class="btn r sm" onclick="decidirSol('${s.codigo}','Rechazada')">Rechazar</button></div>` : ''}
${d.puedeCancelar ? `<label for="d_mot" style="margin-top:10px">Motivo de cancelación</label><div class="row"><input id="d_mot"><button class="btn s sm" onclick="lAcc(api('POST','/solicitudes/${s.codigo}/cancelar',{motivo:v$('d_mot')}),'Solicitud cancelada')">Cancelar solicitud</button></div>` : ''}
${d.puedeCerrar ? `<div class="row"><button class="btn sm" onclick="lAcc(api('POST','/solicitudes/${s.codigo}/cerrar',{}),'Solicitud cerrada')">Cerrar solicitud</button></div>` : ''}</div>
${d.asignaciones.length ? `<div class="card" style="margin-top:12px"><h3>Asignaciones</h3><div class="tw"><table><tr><th>Recurso</th><th>Cantidad</th><th>Almacén</th><th>Responsable</th><th>Fecha programada</th><th>Estado</th></tr>${d.asignaciones.map((a) => `<tr><td>${a.recurso} · ${esc(a.rnombre)}</td><td>${n$(a.cantidad)} ${esc(a.unidad)}</td><td>${esc(a.almacen)}</td><td>${esc(a.responsable || '—')}</td><td>${dia(a.fecha_programada)}${a.con_conflicto ? ' <span class="tag warn">Con conflicto</span>' : ''}</td><td>${sTag(a.estado)}</td></tr>`).join('')}</table></div></div>` : ''}
<div class="g2" style="margin-top:12px;align-items:start"><div class="card"><h3>Comentarios</h3>${d.comentarios.map((c) => `<p><b>${esc(c.usuario)}</b> <span class="mu sm">${dt(c.fecha)}</span><br>${esc(c.texto)}</p>`).join('') || '<p class="mu">Sin comentarios.</p>'}<label for="d_nc">Nuevo comentario</label><div class="row"><input id="d_nc"><button class="btn s sm" onclick="lAcc(api('POST','/solicitudes/${s.codigo}/comentarios',{texto:v$('d_nc')}),'Comentario agregado')">Comentar</button></div></div>
<div class="card"><h3>Hitos de entrega</h3>${d.hitos.map((h) => `<p><b>${esc(h.tipo)}</b> · ${dt(h.fecha)} · ${esc(h.responsable || '')}<br>${esc(h.nota || '')}${h.recibido_por ? ' Recibió: ' + esc(h.recibido_por) : ''}${h.tiene_evidencia ? ` <button class="btn s sm" onclick="verEvid('${s.codigo}',${h.id})">Ver evidencia</button>` : ''}</p>`).join('') || '<p class="mu">Sin hitos registrados.</p>'}</div></div>
<div class="card" style="margin-top:12px"><span class="hu">Trazabilidad</span><h3>Historial de cambios</h3>${bitTabla(d.historial)}</div>`;
}
const decidirSol = (c, dec) => lAcc(api('POST', `/solicitudes/${c}/decision`, { decision: dec, comentario: v$('d_com') }), 'Solicitud ' + dec.toLowerCase());
async function verEvid(c, id) { const r = await g(`/solicitudes/${c}/evidencia/${id}`); if (r) { const w = window.open(); if (w) w.document.write(`<title>${esc(r.nombre)}</title><img alt="Evidencia" style="max-width:100%" src="${r.evidencia}">`); } }

/* ---- HU-3.5 Planificación ---- */
function tPlanificacion() {
  if (L.plan === null) return '<div class="card">Cargando…</div>';
  const mc = L.conf;
  return `<span class="hu">HU-3.5 · Planificación y asignación de recursos</span>${lErr()}
<div class="card" style="margin-top:8px"><h3>Solicitudes pendientes de asignar</h3><div class="tw"><table><tr><th>Código</th><th>Actividad</th><th>Recurso</th><th>Pendiente</th><th>Fecha requerida</th><th>Estado</th><th></th></tr>
${L.plan.map((s) => `<tr><td><b>${s.codigo}</b></td><td>${esc(s.actividad)}</td><td>${s.recurso ? esc(s.recurso.nombre) : '<span class="mu">Servicio externo</span>'}</td><td>${s.servicio ? '—' : n$(s.pendiente) + ' ' + esc(s.recurso.unidad)}</td><td>${dia(s.fecha_requerida)}</td><td>${sTag(s.estado)}</td>
<td>${s.servicio ? '<span class="mu sm">Usa una orden de servicio</span>' : act('planificacion', 'c', `L.sel='${s.codigo}';L.conf=null;lVol();R()`, 'Asignar')}</td></tr>`).join('') || '<tr><td colspan="7" class="mu">No hay solicitudes por asignar.</td></tr>'}</table></div></div>
${L.sel ? formAsg(L.plan.find((x) => x.codigo === L.sel)) : ''}
<div class="card" style="margin-top:12px"><h3>Asignaciones registradas</h3><div class="tw"><table><tr><th>Solicitud</th><th>Recurso</th><th>Cantidad</th><th>Almacén</th><th>Responsable</th><th>Fecha</th><th>Estado</th><th></th></tr>
${L.asg.map((a) => `<tr><td>${a.solicitud}</td><td>${a.recurso} · ${esc(a.rnombre)}</td><td>${n$(a.cantidad)} ${esc(a.unidad)}</td><td>${esc(a.almacen)}</td><td>${esc(a.responsable || '—')}</td><td>${dia(a.fecha_programada)}${a.con_conflicto ? ' <span class="tag warn">Con conflicto</span>' : ''}</td><td>${sTag(a.estado)}</td>
<td>${a.estado === 'Reservada' ? act('planificacion', 'u', `cancelarAsg(${a.id})`, 'Cancelar reserva') : ''}</td></tr>`).join('') || '<tr><td colspan="8" class="mu">Aún no hay asignaciones.</td></tr>'}</table></div></div>`;
}
function formAsg(s) {
  if (!s) return '';
  const rec = s.recurso && L.rec.find((r) => r.codigo === s.recurso.codigo);
  return `<div class="card" style="margin-top:12px"><h3>Asignar ${s.codigo}${rec ? ' · ' + esc(rec.nombre) : ''}</h3><p class="mu sm">Disponible hoy: <b>${rec ? n$(rec.disponible) + ' ' + esc(rec.unidad) : '—'}</b> (existencias ${rec ? n$(rec.existencias) : '—'}, reservado ${rec ? n$(rec.reservado) : '—'})</p><div class="g2">
<div><label for="a_alm">Almacén de origen *</label><select id="a_alm">${opts(L.alms.filter((a) => a.activo !== 0).map((a) => [a.id, `${a.codigo} · ${a.nombre}`]), L.asgF ? L.asgF.alm : '')}</select></div>
<div><label for="a_can">Cantidad *</label><input id="a_can" type="number" min="1" value="${esc(L.asgF ? L.asgF.can : s.pendiente)}"></div>
<div><label for="a_resp">Responsable *</label><select id="a_resp">${opts(L.resp.map((r) => [r.id, `${r.nombre} · ${r.rol}`]), L.asgF ? L.asgF.resp : '')}</select></div>
<div><label for="a_fec">Fecha programada *</label><input id="a_fec" type="date" min="${hoyISO()}" value="${esc(L.asgF ? L.asgF.fec : s.fecha_requerida ? new Date(s.fecha_requerida).toISOString().slice(0, 10) : hoyISO(1))}"></div></div>
${L.conf ? `<div class="banner er" role="alert"><b>Hay conflictos de disponibilidad:</b><ul>${L.conf.map((c) => `<li>${esc(c)}</li>`).join('')}</ul>¿Quieres asignar de todos modos? Quedará marcado «Con conflicto» en la bitácora.</div>` : ''}
<div class="row"><button class="btn" onclick="asignarRec('${s.codigo}',${L.conf ? 'true' : 'false'})">${L.conf ? 'Asignar de todos modos' : 'Asignar recurso'}</button><button class="btn s" onclick="L.sel=null;L.conf=null;L.asgF=null;lVol();R()">Cancelar</button></div></div>`;
}
async function asignarRec(c, forzar) {
  L.asgF = { alm: v$('a_alm'), can: v$('a_can'), resp: v$('a_resp'), fec: v$('a_fec') };
  const r = await api('POST', `/solicitudes/${c}/asignar`, { almacen_id: +L.asgF.alm, cantidad: L.asgF.can, responsable_id: +L.asgF.resp, fecha_programada: L.asgF.fec, forzar });
  if (r.requiereConfirmacion) { L.conf = r.advertencias; L.err = ''; return R(); }
  L.err = r.ok ? '' : r.error; if (r.ok) { toast('Recurso asignado'); L.sel = null; L.conf = null; L.asgF = null; }
  await loadTab();
}
function cancelarAsg(id) { const m = prompt('Motivo de la cancelación (mínimo 5 caracteres):'); if (m !== null) lAcc(api('POST', `/asignaciones-recurso/${id}/cancelar`, { motivo: m }), 'Reserva cancelada'); }

/* ---- HU-3.4 Inventario ---- */
function tInventario() {
  if (L.inv === null) return '<div class="card">Cargando…</div>';
  const f = L.fi, m = L.fm;
  return `<span class="hu">HU-3.4 · Inventario y movimientos</span>${lErr()}
<div class="card" style="margin:8px 0"><h3>Registrar movimiento</h3><div class="g3">
<div><label for="m_tipo">Tipo *</label><select id="m_tipo">${opts(['Entrada', 'Salida', 'Ajuste'].map((x) => [x, x + (x === 'Ajuste' ? ' (positivo o negativo)' : '')]))}</select></div>
<div><label for="m_rec">Recurso *</label><select id="m_rec">${opts(L.rec.filter((r) => r.activo).map((r) => [r.codigo, `${r.codigo} · ${r.nombre}`]))}</select></div>
<div><label for="m_alm">Almacén *</label><select id="m_alm">${opts(L.alms.filter((a) => a.activo !== 0).map((a) => [a.id, a.nombre]))}</select></div>
<div><label for="m_can">Cantidad *</label><input id="m_can" type="number" step="any" value="1"></div>
<div style="grid-column:span 2"><label for="m_mot">Motivo * (mínimo 5 caracteres)</label><input id="m_mot"></div></div>
<div class="row">${act('inventario', 'c', 'registrarMov()', 'Registrar movimiento', '')}</div><p class="hint">El saldo nunca puede quedar negativo ni consumir lo reservado. Los movimientos no se pueden editar ni borrar.</p></div>
<div class="card"><h3>Existencias por almacén</h3><div class="row" style="align-items:end"><div><label for="i_q">Buscar</label><input id="i_q" value="${esc(f.q || '')}"></div><div><label for="i_alm">Almacén</label><select id="i_alm">${opts(L.alms.map((a) => [a.id, a.nombre]), f.almacen, 'Todos')}</select></div><label style="display:flex;gap:6px;align-items:center"><input id="i_bajo" type="checkbox" ${f.bajo ? 'checked' : ''}> Solo stock bajo</label><button class="btn" onclick="L.fi={q:v$('i_q'),almacen:v$('i_alm'),bajo:$('#i_bajo').checked?'1':''};loadTab()">Filtrar</button></div>
<div class="tw"><table><tr><th>Código</th><th>Recurso</th><th>Almacén</th><th>Existencias</th><th>Reservado</th><th>Disponible</th><th>Mínimo</th></tr>${L.inv.map((x) => `<tr><td><b>${x.codigo}</b></td><td>${esc(x.nombre)}</td><td>${esc(x.almacen)}</td><td>${n$(x.existencias)} ${esc(x.unidad)}</td><td>${n$(x.reservado)}</td><td>${n$(x.disponible)}${x.bajo_minimo ? ' <span class="tag er">Bajo mínimo</span>' : ''}</td><td>${x.tipo === 'Material' ? n$(x.stock_minimo) : '—'}</td></tr>`).join('') || '<tr><td colspan="7" class="mu">Sin existencias para esos filtros.</td></tr>'}</table></div></div>
<div class="card" style="margin-top:12px"><span class="hu">HU-3.4 · Historial de movimientos</span><h3>Movimientos</h3><div class="row" style="align-items:end"><div><label for="h_tipo">Tipo</label><select id="h_tipo">${opts(['Entrada', 'Salida', 'Devolución', 'Ajuste'].map((x) => [x, x]), m.tipo, 'Todos')}</select></div><div><label for="h_rec">Recurso</label><select id="h_rec">${opts(L.rec.map((r) => [r.codigo, `${r.codigo} · ${r.nombre}`]), m.recurso, 'Todos')}</select></div><div><label for="h_des">Desde</label><input id="h_des" type="date" value="${esc(m.desde || '')}"></div><div><label for="h_has">Hasta</label><input id="h_has" type="date" value="${esc(m.hasta || '')}"></div><button class="btn" onclick="L.fm={tipo:v$('h_tipo'),recurso:v$('h_rec'),desde:v$('h_des'),hasta:v$('h_has')};loadTab()">Filtrar</button><button class="btn s" onclick="L.fm={};loadTab()">Limpiar</button></div>
<div class="tw"><table><tr><th>Fecha</th><th>Tipo</th><th>Recurso</th><th>Almacén</th><th>Cantidad</th><th>Saldo</th><th>Motivo</th><th>Referencia</th><th>Usuario</th></tr>${L.mov.map((x) => `<tr><td>${dt(x.fecha)}</td><td>${esc(x.tipo)}</td><td>${x.recurso} · ${esc(x.rnombre)}</td><td>${esc(x.almacen)}</td><td>${x.cantidad > 0 ? '+' : ''}${n$(x.cantidad)}</td><td>${n$(x.saldo_despues)}</td><td>${esc(x.motivo)}</td><td>${esc(x.referencia || '—')}</td><td>${esc(x.usuario)}</td></tr>`).join('') || '<tr><td colspan="9" class="mu">Sin movimientos.</td></tr>'}</table></div></div>`;
}
async function registrarMov() { await lAcc(api('POST', '/inventario/movimientos', { tipo: v$('m_tipo'), recurso_codigo: v$('m_rec'), almacen_id: +v$('m_alm'), cantidad: v$('m_can'), motivo: v$('m_mot') }), 'Movimiento registrado'); }

/* ---- HU-3.6 Entregas ---- */
function tEntregas() {
  if (L.entregas === null) return '<div class="card">Cargando…</div>';
  if (L.entSel && L.ent) return vEntDet();
  return `<span class="hu">HU-3.6 · Seguimiento de entregas</span>${lErr()}
<div class="card" style="margin-top:8px"><h3>Entregas en curso</h3><div class="tw"><table><tr><th>Solicitud</th><th>Actividad</th><th>Recurso</th><th>Fecha requerida</th><th>Estado</th><th>Hitos</th><th></th></tr>${L.entregas.map((s) => `<tr><td><b>${s.codigo}</b></td><td>${esc(s.actividad)}</td><td>${s.recurso ? esc(s.recurso.nombre) : 'Servicio'}</td><td>${dia(s.fecha_requerida)}${s.vencida ? ' <span class="tag er">Vencida</span>' : ''}</td><td>${sTag(s.estado)}${s.retrasos ? ' <span class="tag warn">' + s.retrasos + ' retraso(s)</span>' : ''}</td><td>${s.n_hitos}</td><td><button class="btn s sm" onclick="L.entSel='${s.codigo}';lVol();loadTab()">Gestionar</button></td></tr>`).join('') || '<tr><td colspan="7" class="mu">No hay entregas en curso.</td></tr>'}</table></div></div>
${can('entregas', 'u') ? `<div class="card" style="margin-top:12px"><h3>Evidencia de entrega</h3><label style="display:flex;gap:6px;align-items:center"><input type="checkbox" id="cf_h" ${L.cfg.evidenciaHabilitada ? 'checked' : ''}> Permitir adjuntar evidencia (foto)</label><label style="display:flex;gap:6px;align-items:center"><input type="checkbox" id="cf_o" ${L.cfg.evidenciaObligatoria ? 'checked' : ''}> Hacerla obligatoria al registrar una entrega</label><div class="row"><button class="btn s sm" onclick="lAcc(api('PUT','/logistica/config',{evidenciaHabilitada:$('#cf_h').checked,evidenciaObligatoria:$('#cf_o').checked}),'Configuración guardada')">Guardar</button></div></div>` : ''}`;
}
function vEntDet() {
  const d = L.ent, s = d.item, rsv = d.asignaciones.filter((a) => a.estado === 'Reservada');
  return `<button class="btn s sm" onclick="L.entSel=null;L.evid=null;lVol();loadTab()">← Volver a entregas</button>
<div class="card" style="margin-top:10px"><h3>${s.codigo} · ${esc(s.actividad)}</h3><p>${sTag(s.estado)} Destino: ${esc(s.ubicacion)} · Se necesita: ${dia(s.fecha_requerida)}</p>${lErr()}
${d.puedeRegistrarHito ? `<h3 style="margin-top:12px">Registrar hito</h3><div class="g2"><div><label for="h_t">Hito *</label><select id="h_t">${opts(['Preparación', 'Despacho', 'En tránsito', 'Entrega', 'Retraso', 'Incidencia'].map((x) => [x, x]))}</select></div>
<div><label for="h_a">Asignación (para la entrega)</label><select id="h_a">${opts(rsv.map((a) => [a.id, `${a.recurso} · ${n$(a.cantidad)} ${a.unidad}`]), '', '—')}</select></div>
<div><label for="h_r">Recibido por (entrega)</label><input id="h_r"></div><div><label for="h_n">Nota (obligatoria en retraso o incidencia)</label><input id="h_n"></div></div>
${L.cfg.evidenciaHabilitada ? `<label for="h_e">Evidencia (imagen${L.cfg.evidenciaObligatoria ? ', obligatoria' : ', opcional'})</label><input id="h_e" type="file" accept="image/*" onchange="leerEvid(this)"><p class="hint" id="evid_ok">${L.evid ? 'Imagen lista: ' + esc(L.evid.nombre) : ''}</p>` : ''}
<div class="row"><button class="btn" onclick="registrarHito('${s.codigo}')">Registrar hito</button></div>` : '<p class="mu">Tu rol solo permite consultar esta entrega.</p>'}</div>
<div class="card" style="margin-top:12px"><h3>Línea de tiempo</h3>${d.hitos.map((h) => `<p><b>${esc(h.tipo)}</b> · ${dt(h.fecha)} · ${esc(h.responsable || '')}<br>${esc(h.nota || '')}${h.recibido_por ? ' Recibió: ' + esc(h.recibido_por) : ''}${h.tiene_evidencia ? ` <button class="btn s sm" onclick="verEvid('${s.codigo}',${h.id})">Ver evidencia</button>` : ''}</p>`).join('') || '<p class="mu">Sin hitos todavía.</p>'}</div>`;
}
function leerEvid(inp) { // reduce la imagen para que quepa en el límite de 150 KB
  const f = inp.files[0]; if (!f) return; const rd = new FileReader();
  rd.onload = () => { const im = new Image(); im.onload = () => { let w = Math.min(900, im.width), q = 0.8, out; const c = document.createElement('canvas');
    do { c.width = w; c.height = Math.round(im.height * w / im.width); c.getContext('2d').drawImage(im, 0, 0, c.width, c.height); out = c.toDataURL('image/jpeg', q); q -= 0.1; w = Math.round(w * 0.85); } while (out.length > 140000 && q > 0.2);
    L.evid = { data: out, nombre: f.name }; const o = $('#evid_ok'); if (o) o.textContent = 'Imagen lista: ' + f.name; }; im.src = rd.result; }; rd.readAsDataURL(f);
}
async function registrarHito(c) { const r = await lAcc(api('POST', `/solicitudes/${c}/hitos`, { tipo: v$('h_t'), asignacion_id: +v$('h_a') || undefined, recibido_por: v$('h_r'), nota: v$('h_n'), evidencia: L.evid ? L.evid.data : undefined, evidencia_nombre: L.evid ? L.evid.nombre : undefined }), 'Hito registrado'); if (r.ok) L.evid = null; }

/* ---- HU-3.7 Devoluciones y mantenimiento ---- */
function tMantenimiento() {
  if (L.mant === null) return '<div class="card">Cargando…</div>';
  const m = L.mant, ops = L.rec.filter((r) => r.activo && r.tipo !== 'Material' && r.estado === 'Operativo');
  return `<span class="hu">HU-3.7 · Devoluciones y mantenimiento</span>${lErr()}
<div class="card" style="margin-top:8px"><h3>Pendientes de devolución</h3><div class="tw"><table><tr><th>Solicitud</th><th>Recurso</th><th>Entregado</th><th>Devuelto</th><th>Devolver</th></tr>${m.pendientesDevolucion.map((a) => `<tr><td>${a.solicitud}</td><td>${a.recurso} · ${esc(a.rnombre)}</td><td>${n$(a.cantidad)} ${esc(a.unidad)}</td><td>${n$(a.devuelta)}</td>
<td><div class="row"><input id="dv_c${a.id}" type="number" min="1" value="${a.cantidad - a.devuelta}" aria-label="Cantidad" style="width:70px"><select id="dv_k${a.id}" aria-label="Condición">${opts(['Buena', 'Dañado', 'Requiere mantenimiento'].map((x) => [x, x]))}</select><input id="dv_o${a.id}" placeholder="Observaciones" aria-label="Observaciones">${act('mantenimiento', 'c', `devolver(${a.id})`, 'Registrar', '')}</div></td></tr>`).join('') || '<tr><td colspan="5" class="mu">No hay recursos pendientes de devolver.</td></tr>'}</table></div></div>
<div class="g2" style="margin-top:12px;align-items:start"><div class="card"><h3>Iniciar mantenimiento</h3><label for="mt_r">Equipo o vehículo operativo</label><select id="mt_r">${opts(ops.map((r) => [r.codigo, `${r.codigo} · ${r.nombre}`]))}</select><label for="mt_t">Tipo</label><select id="mt_t">${opts(['Preventivo', 'Correctivo'].map((x) => [x, x]))}</select><label for="mt_d">Trabajo a realizar *</label><input id="mt_d"><div class="row">${act('mantenimiento', 'c', 'iniciarMant()', 'Iniciar mantenimiento', '')}</div></div>
<div class="card"><h3>Historial de devoluciones</h3><div class="tw"><table><tr><th>Fecha</th><th>Recurso</th><th>Cant.</th><th>Condición</th></tr>${m.devoluciones.map((d) => `<tr><td>${dt(d.fecha)}</td><td>${d.recurso} · ${esc(d.rnombre)}</td><td>${n$(d.cantidad)}</td><td>${cTag(d.condicion)}</td></tr>`).join('') || '<tr><td colspan="4" class="mu">Sin devoluciones.</td></tr>'}</table></div></div></div>
<div class="card" style="margin-top:12px"><h3>Mantenimientos</h3><div class="tw"><table><tr><th>Recurso</th><th>Tipo</th><th>Trabajo</th><th>Inicio</th><th>Estado</th><th>Cierre</th></tr>${m.items.map((x) => `<tr><td>${x.recurso} · ${esc(x.rnombre)}</td><td>${esc(x.tipo)}</td><td>${esc(x.descripcion)}</td><td>${dt(x.fecha_inicio)}</td><td>${sTag(x.estado === 'En curso' ? 'En ejecución' : 'Entregada').replace(/>[^<]+</, '>' + x.estado + '<')}</td>
<td>${x.estado === 'En curso' && can('mantenimiento', 'u') ? `<div class="row"><select id="mf_r${x.id}" aria-label="Resultado">${opts(['Operativo', 'Fuera de servicio'].map((y) => [y, y]))}</select><input id="mf_o${x.id}" placeholder="Observaciones" aria-label="Observaciones"><button class="btn s sm" onclick="lAcc(api('POST','/mantenimientos/${x.id}/finalizar',{resultado:v$('mf_r${x.id}'),observaciones:v$('mf_o${x.id}')}),'Mantenimiento finalizado')">Finalizar</button></div>` : esc(x.resultado || '—')}</td></tr>`).join('') || '<tr><td colspan="6" class="mu">Sin mantenimientos.</td></tr>'}</table></div></div>`;
}
const devolver = (id) => lAcc(api('POST', `/asignaciones-recurso/${id}/devolucion`, { cantidad: v$('dv_c' + id), condicion: v$('dv_k' + id), observaciones: v$('dv_o' + id) }), 'Devolución registrada');
const iniciarMant = () => lAcc(api('POST', '/mantenimientos', { recurso_codigo: v$('mt_r'), tipo: v$('mt_t'), descripcion: v$('mt_d') }), 'Mantenimiento iniciado');

/* ---- HU-3.8 Proveedores y órdenes de servicio ---- */
function tProveedores() {
  if (L.prov === null) return '<div class="card">Cargando…</div>';
  const serv = L.sol.filter((s) => ['Aprobada', 'Planificada', 'En ejecución'].includes(s.estado));
  return `<span class="hu">HU-3.8 · Proveedores y servicios externos</span>${lErr()}
<div class="card" style="margin-top:8px"><h3>Proveedores</h3><div class="tw"><table><tr><th>Código</th><th>Nombre</th><th>Contacto</th><th>Teléfono</th><th>Correo</th><th>Estado</th></tr>${L.prov.map((p) => `<tr><td>${p.codigo}</td><td>${esc(p.nombre)}</td><td>${esc(p.contacto || '—')}</td><td>${esc(p.telefono || '—')}</td><td>${esc(p.correo || '—')}</td><td>${sTag(p.estado === 'Activo' ? 'Aprobada' : 'Cancelada').replace(/>[^<]+</, '>' + p.estado + '<')}</td></tr>`).join('')}</table></div>
${can('proveedores', 'c') ? `<details><summary><b>+ Nuevo proveedor</b></summary><div class="g2"><div><label for="p_n">Nombre *</label><input id="p_n"></div><div><label for="p_c">Contacto</label><input id="p_c"></div><div><label for="p_t">Teléfono</label><input id="p_t"></div><div><label for="p_e">Correo</label><input id="p_e"></div></div><div class="row"><button class="btn sm" onclick="lAcc(api('POST','/proveedores',{nombre:v$('p_n'),contacto:v$('p_c'),telefono:v$('p_t'),correo:v$('p_e')}),'Proveedor creado')">Guardar proveedor</button></div></details>` : ''}</div>
<div class="card" style="margin-top:12px"><h3>Órdenes de servicio</h3><div class="tw"><table><tr><th>Orden</th><th>Proveedor</th><th>Solicitud</th><th>Alcance</th><th>Costo</th><th>Estado</th><th></th></tr>${L.ord.map((o) => `<tr><td><b>${o.codigo}</b></td><td>${esc(o.proveedor)}</td><td>${o.solicitud}</td><td>${esc(o.alcance)}</td><td>${o.costo === null || o.costo === undefined ? '—' : 'RD$ ' + n$(o.costo)}</td><td>${esc(o.estado)}</td>
<td>${can('proveedores', 'u') && !['Completada', 'Cancelada'].includes(o.estado) ? `<select id="os_${o.codigo}" aria-label="Nuevo estado">${opts(['En ejecución', 'Completada', 'Cancelada'].map((x) => [x, x]))}</select> <button class="btn s sm" onclick="lAcc(api('POST','/ordenes-servicio/${o.codigo}/estado',{estado:v$('os_${o.codigo}'),motivo:'Cambio desde el panel'}),'Orden actualizada')">Cambiar</button>` : ''}</td></tr>`).join('') || '<tr><td colspan="7" class="mu">Sin órdenes.</td></tr>'}</table></div>
${can('proveedores', 'c') ? `<details><summary><b>+ Nueva orden de servicio</b></summary><div class="g2"><div><label for="o_pv">Proveedor *</label><select id="o_pv">${opts(L.prov.filter((p) => p.estado === 'Activo').map((p) => [p.codigo, p.nombre]))}</select></div><div><label for="o_so">Solicitud aprobada *</label><select id="o_so">${opts(serv.map((s) => [s.codigo, `${s.codigo} · ${s.actividad}`]))}</select></div><div><label for="o_co">Costo (RD$)</label><input id="o_co" type="number" min="0"></div><div><label for="o_al">Alcance * (mínimo 10 caracteres)</label><input id="o_al"></div></div><div class="row"><button class="btn sm" onclick="lAcc(api('POST','/ordenes-servicio',{proveedor_codigo:v$('o_pv'),solicitud_codigo:v$('o_so'),alcance:v$('o_al'),costo:v$('o_co')}),'Orden creada')">Crear orden</button></div></details>` : ''}</div>`;
}

/* ---- HU-3.8 Indicadores y reportes ---- */
function tIndicadores() {
  const d = L.ind; if (!d) return '<div class="card">Cargando…</div>';
  const m = d.metricas, f = L.fInd, def = d.definiciones, p = (v) => (v === null ? 'Sin datos' : v + ' %');
  const k = (n, l, t) => `<div class="ind" title="${esc(t)}"><b>${n}</b><span>${l}</span></div>`;
  const bar = (n, max) => `<div style="background:var(--b);border-radius:4px;height:10px"><div style="width:${max ? Math.round(n / max * 100) : 0}%;background:var(--t);height:10px;border-radius:4px"></div></div>`;
  const mx = Math.max(1, ...d.consumo.map((c) => c.total));
  return `<span class="hu">HU-3.8 · Indicadores y reportes logísticos</span>
<div class="card" style="margin:8px 0"><div class="row" style="align-items:end"><div><label for="k_d">Desde</label><input id="k_d" type="date" value="${esc(f.desde || '')}"></div><div><label for="k_h">Hasta</label><input id="k_h" type="date" value="${esc(f.hasta || '')}"></div><div><label for="k_c">Categoría</label><select id="k_c">${opts(d.categorias.map((c) => [c.id, c.nombre]), f.categoria, 'Todas')}</select></div><div><label for="k_a">Almacén</label><select id="k_a">${opts(d.almacenes.map((c) => [c.id, c.nombre]), f.almacen, 'Todos')}</select></div>
<button class="btn" onclick="L.fInd={desde:v$('k_d'),hasta:v$('k_h'),categoria:v$('k_c'),almacen:v$('k_a')};loadTab()">Aplicar</button><button class="btn s" onclick="L.fInd={};loadTab()">Limpiar</button></div>
<p class="hint">Periodo: ${esc(d.filtros.periodo)} · Categoría: ${esc(d.filtros.categoria)} · Ubicación: ${esc(d.filtros.ubicacion)} · Generado ${dt(d.generado)} por ${esc(d.generado_por)}</p></div>
<div class="inds">${k(p(m.cumplimiento_fechas_pct), 'Cumplimiento de fechas', def.cumplimiento_fechas.formula)}${k(p(m.solicitudes_atendidas_pct), 'Solicitudes atendidas', def.solicitudes_atendidas.formula)}${k(p(m.utilizacion_activos_pct), 'Utilización de activos', def.utilizacion_activos.formula)}${k(n$(m.consumo_total), 'Consumo de materiales', def.consumo_materiales.formula)}${k(m.retrasos + m.incidencias, 'Retrasos e incidencias', def.retrasos_incidencias.formula)}${k(m.materiales_stock_bajo, 'Materiales con stock bajo', def.stock_bajo.formula)}</div>
<div class="g2" style="margin-top:12px;align-items:start"><div class="card"><h3>Materiales más consumidos</h3>${d.consumo.map((c) => `<p style="margin:6px 0">${esc(c.nombre)} <b>${n$(c.total)} ${esc(c.unidad)}</b>${bar(c.total, mx)}</p>`).join('') || '<p class="mu">Sin consumo en el periodo.</p>'}</div>
<div class="card"><h3>Solicitudes por estado</h3>${d.por_estado.map((e) => `<p style="margin:6px 0">${esc(e.nombre)} <b>${e.total}</b>${bar(e.total, m.solicitudes)}</p>`).join('') || '<p class="mu">Sin solicitudes.</p>'}<h3 style="margin-top:12px">Stock bajo</h3>${d.stock_bajo.map((s) => `<p>${esc(s.nombre)}: <b>${n$(s.disponible)}</b> / mín. ${n$(s.minimo)} ${esc(s.unidad)}</p>`).join('') || '<p class="mu">Ningún material bajo el mínimo.</p>'}</div></div>
<details class="card" style="margin-top:12px"><summary><b>¿Cómo se calculan estos indicadores?</b></summary>${Object.entries(def).map(([k2, v2]) => `<p><b>${k2.replace(/_/g, ' ')}:</b> ${esc(v2.formula)}<br><span class="mu sm">Fuente: ${esc(v2.fuente)}</span></p>`).join('')}</details>
<div class="card" style="margin-top:12px"><h3>Reportes de stock y movimientos</h3><p class="mu sm">Se generan con los filtros de arriba. La exportación CSV requiere permiso de creación sobre indicadores.</p><div class="row"><button class="btn s" onclick="verReporte('existencias')">Ver reporte de existencias</button><button class="btn s" onclick="verReporte('movimientos')">Ver reporte de movimientos</button>${act('indicadores', 'c', "descargar('existencias')", 'Exportar existencias (CSV)')}${act('indicadores', 'c', "descargar('movimientos')", 'Exportar movimientos (CSV)')}</div><div id="rep_out"></div></div>`;
}
async function verReporte(t) {
  const r = await g('/logistica/reportes/' + t + '?' + qs(L.fInd)); if (!r) return;
  $('#rep_out').innerHTML = `<p class="hint">Generado ${dt(r.generado)} por ${esc(r.generado_por)} · ${r.items.length} filas</p><div class="tw"><table>` + (t === 'existencias'
    ? '<tr><th>Código</th><th>Recurso</th><th>Almacén</th><th>Existencias</th><th>Reservado</th><th>Disponible</th></tr>' + r.items.map((x) => `<tr><td>${x.codigo}</td><td>${esc(x.nombre)}</td><td>${esc(x.almacen)}</td><td>${n$(x.existencias)}</td><td>${n$(x.reservado)}</td><td>${n$(x.disponible)}${x.bajo_minimo ? ' <span class="tag er">Bajo</span>' : ''}</td></tr>`).join('')
    : '<tr><th>Fecha</th><th>Tipo</th><th>Recurso</th><th>Almacén</th><th>Cantidad</th><th>Saldo</th><th>Usuario</th></tr>' + r.items.map((x) => `<tr><td>${dt(x.fecha)}</td><td>${esc(x.tipo)}</td><td>${x.recurso}</td><td>${esc(x.almacen)}</td><td>${n$(x.cantidad)}</td><td>${n$(x.saldo_despues)}</td><td>${esc(x.usuario)}</td></tr>`).join('')) + '</table></div>';
}
async function descargar(t) {
  const r = await fetch('/api/logistica/reportes/' + t + '/exportar?' + qs(L.fInd), { credentials: 'same-origin' });
  if (!r.ok) { L.err = (await r.json().catch(() => ({}))).error || 'No se pudo exportar.'; return R(); }
  const a = document.createElement('a'); a.href = URL.createObjectURL(await r.blob()); a.download = t + '-' + hoyISO() + '.csv'; a.click(); toast('Reporte exportado');
}

Object.assign(TABS_EXTRA, { catalogo: tCatalogo, solicitudes: tSolicitudes, planificacion: tPlanificacion, inventario: tInventario, entregas: tEntregas, mantenimiento: tMantenimiento, proveedores: tProveedores, indicadores: tIndicadores });
