// Esquema de la base de datos SQLite y datos iniciales.
const Database = require('better-sqlite3');
const bcrypt = require('bcryptjs');

const MODULOS = ['reportes', 'usuarios', 'roles', 'permisos', 'auditoria',
  'operaciones', 'asignaciones', 'aprobaciones', 'incidencias', 'informes', 'tipos', 'bitacora',
  'catalogo', 'solicitudes', 'planificacion', 'inventario', 'entregas', 'mantenimiento', 'proveedores', 'indicadores'];
const MODN = { reportes: 'Reportes', usuarios: 'Usuarios', roles: 'Roles', permisos: 'Permisos', auditoria: 'Auditoría',
  operaciones: 'Operaciones', asignaciones: 'Asignaciones', aprobaciones: 'Aprobaciones', incidencias: 'Incidencias',
  informes: 'Informes', tipos: 'Tipos y plazos', bitacora: 'Bitácora',
  catalogo: 'Catálogo', solicitudes: 'Solicitudes', planificacion: 'Planificación', inventario: 'Inventario',
  entregas: 'Entregas', mantenimiento: 'Mantenimiento', proveedores: 'Proveedores', indicadores: 'Indicadores' };
const TIPOS = ['Falta de agua', 'Fuga en vía pública', 'Tubería dañada'];
const ROLES = ['Super Administrador', 'Administrador', 'Agente Inmobiliario', 'Arquitecto', 'Ingeniero', 'Cliente', 'Supervisor'];
const ROLES_E2 = ['Auditor', 'Gerente']; // roles nuevos de la Épica 2
const ROLES_E3 = ['Coordinador Logístico', 'Encargado de Almacén']; // roles nuevos de la Épica 3
const COSTO = process.env.NODE_ENV === 'test' ? 4 : 10;
const hash = (p) => bcrypt.hashSync(p, COSTO);

const SCHEMA = `
CREATE TABLE IF NOT EXISTS roles(
  id INTEGER PRIMARY KEY, nombre TEXT UNIQUE NOT NULL COLLATE NOCASE, activo INTEGER NOT NULL DEFAULT 1);
CREATE TABLE IF NOT EXISTS usuarios(
  id INTEGER PRIMARY KEY, nombre TEXT NOT NULL, correo TEXT UNIQUE NOT NULL COLLATE NOCASE,
  telefono TEXT DEFAULT '', clave_hash TEXT NOT NULL,
  rol_id INTEGER NOT NULL REFERENCES roles(id),
  estado TEXT NOT NULL DEFAULT 'Activo', motivo TEXT DEFAULT '', foto TEXT, actualizado INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS permisos(
  rol_id INTEGER NOT NULL REFERENCES roles(id) ON DELETE CASCADE, modulo TEXT NOT NULL,
  crear INTEGER NOT NULL DEFAULT 0, consultar INTEGER NOT NULL DEFAULT 0,
  modificar INTEGER NOT NULL DEFAULT 0, eliminar INTEGER NOT NULL DEFAULT 0,
  PRIMARY KEY(rol_id, modulo));
CREATE TABLE IF NOT EXISTS sesiones(
  token TEXT PRIMARY KEY, usuario_id INTEGER NOT NULL REFERENCES usuarios(id) ON DELETE CASCADE, expira INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS tokens_recuperacion(
  token TEXT PRIMARY KEY, usuario_id INTEGER NOT NULL REFERENCES usuarios(id) ON DELETE CASCADE,
  expira INTEGER NOT NULL, usado INTEGER NOT NULL DEFAULT 0);
CREATE TABLE IF NOT EXISTS auditoria(
  id INTEGER PRIMARY KEY, fecha INTEGER NOT NULL, usuario TEXT NOT NULL, evento TEXT NOT NULL,
  ip TEXT, localizacion TEXT, detalle TEXT DEFAULT '');
CREATE INDEX IF NOT EXISTS idx_auditoria_fecha ON auditoria(fecha DESC);
CREATE TABLE IF NOT EXISTS reportes(
  id INTEGER PRIMARY KEY, codigo TEXT UNIQUE NOT NULL, municipio TEXT NOT NULL, sector TEXT NOT NULL,
  tipo TEXT NOT NULL, desde TEXT, descripcion TEXT NOT NULL, estado INTEGER NOT NULL DEFAULT 0,
  contacto_nombre TEXT, contacto_telefono TEXT, creado INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS config(clave TEXT PRIMARY KEY, valor TEXT NOT NULL);
`;

const SCHEMA_E2 = `
CREATE TABLE IF NOT EXISTS tipos_operacion(
  id INTEGER PRIMARY KEY, nombre TEXT UNIQUE NOT NULL COLLATE NOCASE,
  sla_horas INTEGER NOT NULL DEFAULT 48, aviso_horas INTEGER NOT NULL DEFAULT 12,
  requiere_aprobacion INTEGER NOT NULL DEFAULT 0, aprobador_rol_id INTEGER REFERENCES roles(id) ON DELETE SET NULL,
  activo INTEGER NOT NULL DEFAULT 1);
CREATE TABLE IF NOT EXISTS operaciones(
  id INTEGER PRIMARY KEY, codigo TEXT UNIQUE NOT NULL, tipo_id INTEGER NOT NULL REFERENCES tipos_operacion(id),
  titulo TEXT NOT NULL, descripcion TEXT NOT NULL, prioridad TEXT NOT NULL DEFAULT 'Media',
  estado TEXT NOT NULL DEFAULT 'Creada',
  responsable_id INTEGER REFERENCES usuarios(id) ON DELETE SET NULL, creado_por INTEGER REFERENCES usuarios(id) ON DELETE SET NULL,
  reporte_codigo TEXT, fecha_limite INTEGER NOT NULL, resultado TEXT,
  creado INTEGER NOT NULL, actualizado INTEGER NOT NULL, cerrado INTEGER);
CREATE INDEX IF NOT EXISTS idx_op_estado ON operaciones(estado);
CREATE TABLE IF NOT EXISTS asignaciones(
  id INTEGER PRIMARY KEY, operacion_id INTEGER NOT NULL REFERENCES operaciones(id) ON DELETE CASCADE,
  responsable_id INTEGER REFERENCES usuarios(id) ON DELETE SET NULL, asignado_por INTEGER REFERENCES usuarios(id) ON DELETE SET NULL,
  fecha INTEGER NOT NULL, motivo TEXT DEFAULT '');
CREATE TABLE IF NOT EXISTS aprobaciones(
  id INTEGER PRIMARY KEY, operacion_id INTEGER NOT NULL REFERENCES operaciones(id) ON DELETE CASCADE,
  aprobador_id INTEGER REFERENCES usuarios(id) ON DELETE SET NULL, decision TEXT NOT NULL,
  comentario TEXT DEFAULT '', fecha INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS incidencias(
  id INTEGER PRIMARY KEY, codigo TEXT UNIQUE NOT NULL, operacion_id INTEGER NOT NULL REFERENCES operaciones(id) ON DELETE CASCADE,
  categoria TEXT NOT NULL, descripcion TEXT NOT NULL, prioridad TEXT NOT NULL DEFAULT 'Media',
  responsable_id INTEGER REFERENCES usuarios(id) ON DELETE SET NULL, estado TEXT NOT NULL DEFAULT 'Abierta',
  resolucion TEXT, creado_por INTEGER REFERENCES usuarios(id) ON DELETE SET NULL, creado INTEGER NOT NULL, actualizado INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS incidencia_comentarios(
  id INTEGER PRIMARY KEY, incidencia_id INTEGER NOT NULL REFERENCES incidencias(id) ON DELETE CASCADE,
  usuario TEXT NOT NULL, texto TEXT NOT NULL, fecha INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS notificaciones(
  id INTEGER PRIMARY KEY, usuario_id INTEGER NOT NULL REFERENCES usuarios(id) ON DELETE CASCADE, tipo TEXT NOT NULL,
  operacion_id INTEGER REFERENCES operaciones(id) ON DELETE CASCADE, mensaje TEXT NOT NULL,
  canal TEXT NOT NULL DEFAULT 'interno', resultado TEXT NOT NULL DEFAULT 'Entregada', leida INTEGER NOT NULL DEFAULT 0, fecha INTEGER NOT NULL);
CREATE INDEX IF NOT EXISTS idx_notif_usuario ON notificaciones(usuario_id, leida);
CREATE TABLE IF NOT EXISTS bitacora(
  id INTEGER PRIMARY KEY, fecha INTEGER NOT NULL, actor_id INTEGER, actor TEXT NOT NULL, entidad TEXT NOT NULL, entidad_id TEXT,
  operacion TEXT, accion TEXT NOT NULL, resultado TEXT NOT NULL DEFAULT 'Exitoso', antes TEXT, despues TEXT, detalle TEXT DEFAULT '');
CREATE INDEX IF NOT EXISTS idx_bitacora_op ON bitacora(operacion);
CREATE INDEX IF NOT EXISTS idx_bitacora_fecha ON bitacora(fecha DESC);
CREATE TRIGGER IF NOT EXISTS bitacora_sin_modificar BEFORE UPDATE ON bitacora
  BEGIN SELECT RAISE(ABORT, 'La bitácora no se puede modificar'); END;
CREATE TRIGGER IF NOT EXISTS bitacora_sin_eliminar BEFORE DELETE ON bitacora
  BEGIN SELECT RAISE(ABORT, 'La bitácora no se puede eliminar'); END;
`;

// Permisos por defecto de los módulos de la Épica 2: [Crear, Consultar, Modificar, Eliminar]
const A = [1, 1, 1, 1], R_ = [0, 1, 0, 0], N0 = [0, 0, 0, 0];
const OPERADOR = { operaciones: [1, 1, 1, 0], asignaciones: R_, aprobaciones: R_, incidencias: [1, 1, 1, 0] };
const PERMISOS_E2 = {
  'Super Administrador': Object.fromEntries(['operaciones', 'asignaciones', 'aprobaciones', 'incidencias', 'informes', 'tipos', 'bitacora'].map((m) => [m, A])),
  'Administrador': { operaciones: A, asignaciones: A, aprobaciones: [0, 1, 1, 0], incidencias: A, informes: [1, 1, 0, 0], tipos: [1, 1, 1, 0], bitacora: R_ },
  'Agente Inmobiliario': OPERADOR, 'Arquitecto': OPERADOR, 'Ingeniero': OPERADOR,
  'Supervisor': { operaciones: [1, 1, 1, 0], asignaciones: [1, 1, 1, 0], aprobaciones: [0, 1, 1, 0], incidencias: [1, 1, 1, 0], informes: [1, 1, 0, 0], tipos: [0, 1, 1, 0], bitacora: R_ },
  'Auditor': { operaciones: R_, incidencias: R_, informes: R_, bitacora: R_, auditoria: R_ },
  'Gerente': { operaciones: R_, incidencias: R_, aprobaciones: R_, informes: [1, 1, 0, 0] },
};

const SCHEMA_E3 = `
CREATE TABLE IF NOT EXISTS categorias_recurso(
  id INTEGER PRIMARY KEY, nombre TEXT UNIQUE NOT NULL COLLATE NOCASE, activo INTEGER NOT NULL DEFAULT 1);
CREATE TABLE IF NOT EXISTS almacenes(
  id INTEGER PRIMARY KEY, codigo TEXT UNIQUE NOT NULL, nombre TEXT UNIQUE NOT NULL COLLATE NOCASE,
  ubicacion TEXT DEFAULT '', activo INTEGER NOT NULL DEFAULT 1);
CREATE TABLE IF NOT EXISTS recursos(
  id INTEGER PRIMARY KEY, codigo TEXT UNIQUE NOT NULL, nombre TEXT NOT NULL,
  categoria_id INTEGER NOT NULL REFERENCES categorias_recurso(id),
  tipo TEXT NOT NULL DEFAULT 'Material', unidad TEXT NOT NULL DEFAULT 'unidad', descripcion TEXT DEFAULT '',
  stock_minimo REAL NOT NULL DEFAULT 0, estado TEXT NOT NULL DEFAULT 'Operativo', activo INTEGER NOT NULL DEFAULT 1,
  creado INTEGER NOT NULL, actualizado INTEGER NOT NULL);
CREATE UNIQUE INDEX IF NOT EXISTS uq_recurso_nombre ON recursos(nombre COLLATE NOCASE, categoria_id);
CREATE TABLE IF NOT EXISTS movimientos(
  id INTEGER PRIMARY KEY, recurso_id INTEGER NOT NULL REFERENCES recursos(id), almacen_id INTEGER NOT NULL REFERENCES almacenes(id),
  tipo TEXT NOT NULL, cantidad REAL NOT NULL, saldo_despues REAL NOT NULL, motivo TEXT NOT NULL, referencia TEXT,
  usuario_id INTEGER, usuario TEXT NOT NULL, fecha INTEGER NOT NULL);
CREATE INDEX IF NOT EXISTS idx_mov_recurso ON movimientos(recurso_id, almacen_id);
CREATE INDEX IF NOT EXISTS idx_mov_fecha ON movimientos(fecha DESC);
CREATE TRIGGER IF NOT EXISTS movimientos_sin_modificar BEFORE UPDATE ON movimientos
  BEGIN SELECT RAISE(ABORT, 'Los movimientos de inventario no se pueden modificar'); END;
CREATE TRIGGER IF NOT EXISTS movimientos_sin_eliminar BEFORE DELETE ON movimientos
  BEGIN SELECT RAISE(ABORT, 'Los movimientos de inventario no se pueden eliminar'); END;
CREATE TABLE IF NOT EXISTS solicitudes(
  id INTEGER PRIMARY KEY, codigo TEXT UNIQUE NOT NULL, solicitante_id INTEGER REFERENCES usuarios(id) ON DELETE SET NULL,
  actividad TEXT NOT NULL, requerimiento TEXT NOT NULL, recurso_id INTEGER REFERENCES recursos(id), cantidad REAL NOT NULL DEFAULT 1,
  fecha_requerida INTEGER NOT NULL, ubicacion TEXT NOT NULL, justificacion TEXT NOT NULL, prioridad TEXT NOT NULL DEFAULT 'Media',
  operacion_codigo TEXT, estado TEXT NOT NULL DEFAULT 'Pendiente', decision_comentario TEXT,
  decidido_por INTEGER REFERENCES usuarios(id) ON DELETE SET NULL, creado INTEGER NOT NULL, actualizado INTEGER NOT NULL);
CREATE INDEX IF NOT EXISTS idx_sol_estado ON solicitudes(estado);
CREATE TABLE IF NOT EXISTS solicitud_comentarios(
  id INTEGER PRIMARY KEY, solicitud_id INTEGER NOT NULL REFERENCES solicitudes(id) ON DELETE CASCADE,
  usuario TEXT NOT NULL, texto TEXT NOT NULL, fecha INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS asignaciones_recurso(
  id INTEGER PRIMARY KEY, solicitud_id INTEGER NOT NULL REFERENCES solicitudes(id) ON DELETE CASCADE,
  recurso_id INTEGER NOT NULL REFERENCES recursos(id), almacen_id INTEGER NOT NULL REFERENCES almacenes(id),
  cantidad REAL NOT NULL, responsable_id INTEGER REFERENCES usuarios(id) ON DELETE SET NULL,
  fecha_programada INTEGER NOT NULL, ubicacion TEXT NOT NULL, estado TEXT NOT NULL DEFAULT 'Reservada',
  con_conflicto INTEGER NOT NULL DEFAULT 0, devuelta REAL NOT NULL DEFAULT 0,
  creado_por INTEGER REFERENCES usuarios(id) ON DELETE SET NULL, creado INTEGER NOT NULL, actualizado INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS entregas_hitos(
  id INTEGER PRIMARY KEY, solicitud_id INTEGER NOT NULL REFERENCES solicitudes(id) ON DELETE CASCADE,
  asignacion_id INTEGER REFERENCES asignaciones_recurso(id) ON DELETE SET NULL, tipo TEXT NOT NULL, fecha INTEGER NOT NULL,
  responsable_id INTEGER REFERENCES usuarios(id) ON DELETE SET NULL, nota TEXT DEFAULT '', recibido_por TEXT,
  evidencia_nombre TEXT, evidencia TEXT, creado INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS devoluciones(
  id INTEGER PRIMARY KEY, asignacion_id INTEGER NOT NULL REFERENCES asignaciones_recurso(id) ON DELETE CASCADE,
  cantidad REAL NOT NULL, condicion TEXT NOT NULL, observaciones TEXT DEFAULT '', fecha INTEGER NOT NULL,
  usuario_id INTEGER REFERENCES usuarios(id) ON DELETE SET NULL);
CREATE TABLE IF NOT EXISTS mantenimientos(
  id INTEGER PRIMARY KEY, recurso_id INTEGER NOT NULL REFERENCES recursos(id), tipo TEXT NOT NULL,
  estado TEXT NOT NULL DEFAULT 'En curso', descripcion TEXT NOT NULL, fecha_inicio INTEGER NOT NULL, fecha_fin INTEGER,
  resultado TEXT, observaciones TEXT DEFAULT '', responsable_id INTEGER REFERENCES usuarios(id) ON DELETE SET NULL);
CREATE TABLE IF NOT EXISTS proveedores(
  id INTEGER PRIMARY KEY, codigo TEXT UNIQUE NOT NULL, nombre TEXT UNIQUE NOT NULL COLLATE NOCASE, contacto TEXT DEFAULT '',
  telefono TEXT DEFAULT '', correo TEXT DEFAULT '', estado TEXT NOT NULL DEFAULT 'Activo', notas TEXT DEFAULT '',
  creado INTEGER NOT NULL, actualizado INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS ordenes_servicio(
  id INTEGER PRIMARY KEY, codigo TEXT UNIQUE NOT NULL, proveedor_id INTEGER NOT NULL REFERENCES proveedores(id),
  solicitud_id INTEGER NOT NULL REFERENCES solicitudes(id), alcance TEXT NOT NULL, fecha_inicio INTEGER, fecha_fin INTEGER,
  costo REAL, estado TEXT NOT NULL DEFAULT 'Emitida', creado_por INTEGER REFERENCES usuarios(id) ON DELETE SET NULL,
  creado INTEGER NOT NULL, actualizado INTEGER NOT NULL);
`;

// Permisos por defecto de los módulos de la Épica 3: [Crear, Consultar, Modificar, Eliminar]
const SOLICITANTE = { catalogo: R_, solicitudes: [1, 1, 0, 0], entregas: R_ };
const PERMISOS_E3 = {
  'Super Administrador': Object.fromEntries(['catalogo', 'solicitudes', 'planificacion', 'inventario', 'entregas', 'mantenimiento', 'proveedores', 'indicadores'].map((m) => [m, A])),
  'Administrador': { catalogo: A, solicitudes: [1, 1, 1, 0], planificacion: [1, 1, 1, 0], inventario: [1, 1, 1, 0], entregas: [1, 1, 1, 0], mantenimiento: [1, 1, 1, 0], proveedores: [1, 1, 1, 0], indicadores: [1, 1, 0, 0] },
  'Coordinador Logístico': { catalogo: [1, 1, 1, 0], solicitudes: [1, 1, 1, 0], planificacion: [1, 1, 1, 0], inventario: R_, entregas: [1, 1, 1, 0], mantenimiento: R_, proveedores: [1, 1, 1, 0], indicadores: [1, 1, 0, 0] },
  'Encargado de Almacén': { catalogo: R_, solicitudes: R_, planificacion: R_, inventario: [1, 1, 1, 0], entregas: [1, 1, 0, 0], mantenimiento: [1, 1, 1, 0], indicadores: R_ },
  'Supervisor': { catalogo: R_, solicitudes: [1, 1, 1, 0], planificacion: R_, inventario: R_, entregas: R_, mantenimiento: R_, indicadores: [1, 1, 0, 0] },
  'Agente Inmobiliario': SOLICITANTE, 'Arquitecto': SOLICITANTE, 'Ingeniero': SOLICITANTE,
  'Gerente': { catalogo: R_, solicitudes: R_, planificacion: R_, inventario: R_, entregas: R_, mantenimiento: R_, proveedores: R_, indicadores: [1, 1, 0, 0] },
  'Auditor': { catalogo: R_, solicitudes: R_, planificacion: R_, inventario: R_, entregas: R_, mantenimiento: R_, proveedores: R_, indicadores: R_ },
};

function permisosIniciales(rol) {
  const z = { c: 0, r: 0, u: 0, d: 0 }, todo = { c: 1, r: 1, u: 1, d: 1 };
  const p = Object.fromEntries(MODULOS.map((m) => [m, { ...z }]));
  if (rol === ROLES[0]) MODULOS.forEach((m) => (p[m] = { ...todo }));
  if (rol === ROLES[1]) MODULOS.forEach((m) => (p[m] = m === 'permisos' ? { c: 0, r: 1, u: 0, d: 0 } : { ...todo }));
  if (rol === ROLES[2]) p.reportes = { c: 1, r: 1, u: 1, d: 0 };
  if (rol === ROLES[3] || rol === ROLES[4]) p.reportes = { c: 0, r: 1, u: 1, d: 0 };
  if (rol === ROLES[5]) p.reportes = { c: 0, r: 1, u: 0, d: 0 };
  if (rol === ROLES[6]) { p.reportes = { c: 0, r: 1, u: 1, d: 0 }; p.auditoria = { c: 0, r: 1, u: 0, d: 0 }; }
  Object.entries(PERMISOS_E2[rol] || {}).forEach(([m, v]) => (p[m] = { c: v[0], r: v[1], u: v[2], d: v[3] }));
  Object.entries(PERMISOS_E3[rol] || {}).forEach(([m, v]) => (p[m] = { c: v[0], r: v[1], u: v[2], d: v[3] }));
  return p;
}

const HORA = 3600e3;

// Datos de demostración de la Épica 2 (se crean una sola vez cuando SEED_DEMO != 0)
function sembrarOperacionesDemo(db) {
  const t = Date.now(), u = (c) => (db.prepare('SELECT id FROM usuarios WHERE correo=?').get(c + '@aguaclara.do') || {}).id || null;
  const tipo = (n) => db.prepare('SELECT id FROM tipos_operacion WHERE nombre=?').get(n).id;
  const bit = (op, accion, antes, despues, detalle, ms) =>
    db.prepare('INSERT INTO bitacora(fecha,actor_id,actor,entidad,entidad_id,operacion,accion,resultado,antes,despues,detalle) VALUES(?,?,?,?,?,?,?,?,?,?,?)')
      .run(ms, null, 'sistema (datos de demostración)', 'operacion', op, op, accion, 'Exitoso', antes && JSON.stringify(antes), despues && JSON.stringify(despues), detalle);
  const ops = [
    ['OP-0001', 'Fuga en la calle principal de Alma Rosa', 'Reparación de fuga', 'Alta', 'En proceso', 'ingeniero', 20 * HORA, 40 * HORA, 'DEMO-001', 'Fuga reportada por vecinos; hay agua acumulada junto a la acera.'],
    ['OP-0002', 'Sin suministro en el sector Los Mina', 'Restablecer suministro', 'Crítica', 'En proceso', 'agente', -5 * HORA, 30 * HORA, null, 'El sector lleva más de un día sin agua. Verificar válvula de entrada.'],
    ['OP-0003', 'Reemplazo de tubería principal en Av. Venezuela', 'Reparación de tubería', 'Alta', 'En aprobación', 'arquitecto', 60 * HORA, 70 * HORA, null, 'Se requiere cambiar 40 metros de tubería dañada por corrosión.'],
    ['OP-0004', 'Inspección de válvulas del barrio Invivienda', 'Inspección de campo', 'Media', 'Creada', null, 80 * HORA, 10 * HORA, null, 'Revisión programada de las válvulas de paso del barrio.'],
    ['OP-0005', 'Cambio de medidor en la calle 5', 'Restablecer suministro', 'Baja', 'Completada', 'ingeniero', -10 * HORA, 50 * HORA, null, 'Medidor con lectura errónea; se reemplazó por uno nuevo.'],
    ['OP-0006', 'Reparación de tubería rota en Villa Mella', 'Reparación de tubería', 'Alta', 'Rechazada', 'arquitecto', 50 * HORA, 90 * HORA, null, 'Tubería rota frente a la escuela del sector.'],
  ];
  const ins = db.prepare('INSERT INTO operaciones(codigo,tipo_id,titulo,descripcion,prioridad,estado,responsable_id,creado_por,reporte_codigo,fecha_limite,resultado,creado,actualizado,cerrado) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)');
  const sup = u('supervisor');
  ops.forEach(([cod, tit, tp, pri, est, resp, lim, edad, rep, desc], i) => {
    const creado = t - edad, cerrado = est === 'Completada' ? t - 12 * HORA : null;
    const id = ins.run(cod, tipo(tp), tit, desc, pri, est, resp ? u(resp) : null, sup, rep, t + lim, est === 'Completada' ? 'Medidor reemplazado y probado.' : null, creado, t - (i + 1) * HORA, cerrado).lastInsertRowid;
    bit(cod, 'Operación creada', null, { estado: 'Creada', tipo: tp, prioridad: pri }, tit, creado);
    if (resp) {
      db.prepare('INSERT INTO asignaciones(operacion_id,responsable_id,asignado_por,fecha,motivo) VALUES(?,?,?,?,?)').run(id, u(resp), sup, creado + HORA, '');
      bit(cod, 'Responsable asignado', null, { responsable: resp + '@aguaclara.do' }, '', creado + HORA);
    }
    if (est !== 'Creada') bit(cod, 'Cambio de estado', { estado: 'Creada' }, { estado: est }, '', creado + 2 * HORA);
    if (est === 'Rechazada') {
      db.prepare('INSERT INTO aprobaciones(operacion_id,aprobador_id,decision,comentario,fecha) VALUES(?,?,?,?,?)').run(id, sup, 'Rechazada', 'Falta el presupuesto de materiales.', t - 3 * HORA);
      bit(cod, 'Aprobación: Rechazada', { estado: 'En aprobación' }, { estado: 'Rechazada' }, 'Falta el presupuesto de materiales.', t - 3 * HORA);
    }
  });
  const op2 = db.prepare("SELECT id FROM operaciones WHERE codigo='OP-0002'").get().id;
  db.prepare('INSERT INTO incidencias(codigo,operacion_id,categoria,descripcion,prioridad,responsable_id,estado,creado_por,creado,actualizado) VALUES(?,?,?,?,?,?,?,?,?,?)')
    .run('INC-0001', op2, 'Falta de materiales', 'No hay repuesto de válvula en el almacén; se debe pedir al proveedor.', 'Alta', u('agente'), 'Abierta', u('agente'), t - 2 * HORA, t - 2 * HORA);
  db.prepare('INSERT INTO bitacora(fecha,actor_id,actor,entidad,entidad_id,operacion,accion,resultado,despues,detalle) VALUES(?,?,?,?,?,?,?,?,?,?)')
    .run(t - 2 * HORA, null, 'sistema (datos de demostración)', 'incidencia', 'INC-0001', 'OP-0002', 'Incidencia registrada', 'Exitoso', JSON.stringify({ estado: 'Abierta', prioridad: 'Alta' }), 'Falta de materiales');
}

// Migración idempotente: agrega lo de la Épica 2 a bases creadas antes (o a una base nueva)
function migrarEpica2(db, seedDemo) {
  db.exec(SCHEMA_E2);
  const cfg = (k, v) => db.prepare('INSERT OR IGNORE INTO config(clave,valor) VALUES(?,?)').run(k, v);
  cfg('ventanaAlertaH', '12');
  ROLES_E2.forEach((n) => db.prepare('INSERT OR IGNORE INTO roles(nombre) VALUES(?)').run(n));
  const insP = db.prepare('INSERT OR IGNORE INTO permisos(rol_id,modulo,crear,consultar,modificar,eliminar) VALUES(?,?,?,?,?,?)');
  db.prepare('SELECT id, nombre FROM roles').all().forEach((r) => {
    const p = permisosIniciales(r.nombre);
    MODULOS.forEach((m) => insP.run(r.id, m, p[m].c, p[m].r, p[m].u, p[m].d));
  });
  if (!db.prepare('SELECT COUNT(*) n FROM tipos_operacion').get().n) {
    const rolSup = db.prepare("SELECT id FROM roles WHERE nombre='Supervisor'").get().id;
    const ins = db.prepare('INSERT INTO tipos_operacion(nombre,sla_horas,aviso_horas,requiere_aprobacion,aprobador_rol_id) VALUES(?,?,?,?,?)');
    ins.run('Reparación de fuga', 48, 12, 0, null);
    ins.run('Restablecer suministro', 24, 6, 0, null);
    ins.run('Reparación de tubería', 72, 24, 1, rolSup);
    ins.run('Inspección de campo', 96, 24, 0, null);
  }
  if (seedDemo && !db.prepare("SELECT 1 FROM config WHERE clave='demo_e2'").get()) {
    const h = hash('Demo123*'), ins = db.prepare('INSERT OR IGNORE INTO usuarios(nombre,correo,telefono,clave_hash,rol_id,actualizado) VALUES(?,?,?,?,?,?)');
    [['Alberto Auditor', 'auditor', 'Auditor'], ['Gloria Gerente', 'gerente', 'Gerente']].forEach(([n, c, rol], i) =>
      ins.run(n, c + '@aguaclara.do', '809-555-020' + i, h, db.prepare('SELECT id FROM roles WHERE nombre=?').get(rol).id, Date.now()));
    if (!db.prepare('SELECT COUNT(*) n FROM operaciones').get().n) db.transaction(() => sembrarOperacionesDemo(db))();
    cfg('demo_e2', '1');
  }
}

// ---------------------------------------------------------------------------------------------
// Épica 3 – Gestión logística: migración idempotente y datos de demostración
// ---------------------------------------------------------------------------------------------
function sembrarLogisticaDemo(db) {
  const t = Date.now(), D = 24 * HORA, SIS = 'sistema (datos de demostración)';
  const uid = (c) => (db.prepare('SELECT id FROM usuarios WHERE correo=?').get(c + '@aguaclara.do') || {}).id || null;
  const nom = (c) => (db.prepare('SELECT nombre FROM usuarios WHERE correo=?').get(c + '@aguaclara.do') || {}).nombre || c;
  const cat = (n) => db.prepare('SELECT id FROM categorias_recurso WHERE nombre=?').get(n).id;
  const alm = (c) => db.prepare('SELECT id FROM almacenes WHERE codigo=?').get(c).id;
  const rid = (c) => db.prepare('SELECT id FROM recursos WHERE codigo=?').get(c).id;
  const bit = (ent, ref, accion, detalle, ms, antes, despues) =>
    db.prepare('INSERT INTO bitacora(fecha,actor_id,actor,entidad,entidad_id,operacion,accion,resultado,antes,despues,detalle) VALUES(?,?,?,?,?,?,?,?,?,?,?)')
      .run(ms, null, SIS, ent, ref, ref, accion, 'Exitoso', antes && JSON.stringify(antes), despues && JSON.stringify(despues), detalle || '');
  const saldo = (r, a) => db.prepare('SELECT COALESCE(SUM(cantidad),0) s FROM movimientos WHERE recurso_id=? AND almacen_id=?').get(r, a).s;
  const mov = (r, a, tipo, cant, motivo, ref, ms) => db.prepare('INSERT INTO movimientos(recurso_id,almacen_id,tipo,cantidad,saldo_despues,motivo,referencia,usuario_id,usuario,fecha) VALUES(?,?,?,?,?,?,?,?,?,?)')
    .run(r, a, tipo, cant, saldo(r, a) + cant, motivo, ref || null, uid('encargado'), nom('encargado'), ms);
  // Recursos
  const RE = [['Tubería PVC 6 pulgadas', 'Tuberías y accesorios', 'Material', 'metro', 50, 'Operativo', 'Tubería de presión para redes de agua potable.'],
    ['Válvula de compuerta 4 pulgadas', 'Válvulas y medidores', 'Material', 'unidad', 5, 'Operativo', 'Válvula de paso para redes de distribución.'],
    ['Medidor domiciliario', 'Válvulas y medidores', 'Material', 'unidad', 20, 'Operativo', 'Medidor de consumo residencial.'],
    ['Cloro granulado', 'Químicos de tratamiento', 'Material', 'kg', 100, 'Operativo', 'Desinfectante para el tratamiento del agua.'],
    ['Bomba sumergible 5 HP', 'Herramientas y equipos', 'Equipo', 'unidad', 0, 'Operativo', 'Bomba para extracción y trasvase de agua.'],
    ['Retroexcavadora CAT 420', 'Herramientas y equipos', 'Equipo', 'unidad', 0, 'Mantenimiento', 'Excavación de zanjas para reparar tuberías.'],
    ['Camión cisterna 10 000 L', 'Vehículos', 'Vehículo', 'unidad', 0, 'Operativo', 'Transporte de agua a sectores sin suministro.'],
    ['Kit de reparación de fugas', 'Tuberías y accesorios', 'Material', 'kit', 10, 'Operativo', 'Abrazaderas, sellos y herramientas para fugas.']];
  RE.forEach(([n, c, tp, u, mn, es, d], i) => db.prepare('INSERT INTO recursos(codigo,nombre,categoria_id,tipo,unidad,descripcion,stock_minimo,estado,creado,actualizado) VALUES(?,?,?,?,?,?,?,?,?,?)')
    .run('REC-' + String(i + 1).padStart(4, '0'), n, cat(c), tp, u, d, mn, es, t - 31 * D, t - 31 * D));
  const ent = [['REC-0001', 'ALM-01', 400], ['REC-0001', 'ALM-02', 150], ['REC-0002', 'ALM-01', 25], ['REC-0002', 'ALM-02', 8], ['REC-0003', 'ALM-01', 120], ['REC-0004', 'ALM-02', 60],
    ['REC-0005', 'ALM-03', 1], ['REC-0006', 'ALM-03', 1], ['REC-0007', 'ALM-03', 1], ['REC-0008', 'ALM-01', 30]];
  ent.forEach(([r, a, q]) => mov(rid(r), alm(a), 'Entrada', q, 'Inventario inicial', null, t - 30 * D));
  RE.forEach(([n], i) => bit('recurso', 'REC-' + String(i + 1).padStart(4, '0'), 'Recurso creado', n, t - 31 * D, null, { estado: RE[i][5] }));
  // Proveedores
  const insP = db.prepare('INSERT INTO proveedores(codigo,nombre,contacto,telefono,correo,estado,notas,creado,actualizado) VALUES(?,?,?,?,?,?,?,?,?)');
  insP.run('PRV-0001', 'Transportes Hídricos del Este', 'Luis Almonte', '809-555-0301', 'ventas@hidricos.example', 'Activo', 'Transporte de agua en camiones cisterna.', t - 40 * D, t - 40 * D);
  insP.run('PRV-0002', 'Ferretería Industrial Caribe', 'Rosa Medina', '809-555-0302', 'rosa@caribe.example', 'Activo', 'Tuberías, válvulas y accesorios.', t - 40 * D, t - 40 * D);
  insP.run('PRV-0003', 'Servicios Mecánicos RD', 'Pedro Cruz', '809-555-0303', 'info@mecanicos.example', 'Inactivo', 'Mantenimiento de maquinaria pesada.', t - 40 * D, t - 40 * D);
  const SO = [
    ['SOL-0001', 'ingeniero', 'Reparación de tubería en Av. Venezuela', 'Tubería PVC de 6 pulgadas', 'REC-0001', 40, t + 3 * D, 'Av. Venezuela, Santo Domingo Este', 'Se necesita reemplazar 40 metros de tubería dañada por corrosión.', 'Alta', 'OP-0003', 'Pendiente', null, t - 1 * D],
    ['SOL-0002', 'agente', 'Instalación de válvulas en Los Mina', 'Válvulas de compuerta de 4 pulgadas', 'REC-0002', 3, t + 4 * D, 'Sector Los Mina, Santo Domingo Este', 'Se instalarán válvulas de paso para aislar el sector durante reparaciones.', 'Media', null, 'Aprobada', 'Aprobada por el coordinador.', t - 2 * D],
    ['SOL-0003', 'arquitecto', 'Cambio de medidores en Invivienda', 'Medidores domiciliarios', 'REC-0003', 10, t + 5 * D, 'Barrio Invivienda', 'Reemplazo de medidores con lectura errónea reportados por vecinos.', 'Media', null, 'Planificada', 'Aprobada.', t - 3 * D],
    ['SOL-0004', 'ingeniero', 'Desinfección en la planta Alma Rosa', 'Cloro granulado para tratamiento', 'REC-0004', 20, t + 2 * D, 'Planta de tratamiento Alma Rosa', 'Reposición del cloro necesario para la desinfección semanal.', 'Alta', null, 'En ejecución', 'Aprobada con urgencia.', t - 4 * D],
    ['SOL-0005', 'agente', 'Reparación de fugas en Alma Rosa', 'Kits de reparación de fugas', 'REC-0008', 5, t - 6 * D, 'Sector Alma Rosa', 'Se atenderán cinco fugas reportadas por la comunidad.', 'Media', null, 'Entregada', 'Aprobada.', t - 12 * D],
    ['SOL-0006', 'arquitecto', 'Excavación en Villa Mella', 'Retroexcavadora para zanjas', 'REC-0006', 1, t + 2 * D, 'Villa Mella', 'Excavar la zanja para reparar la tubería rota frente a la escuela.', 'Alta', null, 'Rechazada', 'El equipo está en mantenimiento correctivo; solicitar de nuevo cuando esté operativo.', t - 2 * D],
    ['SOL-0007', 'ingeniero', 'Reposición de válvulas en Los Tres Ojos', 'Válvulas de compuerta de 4 pulgadas', 'REC-0002', 2, t - 10 * D, 'Los Tres Ojos', 'Reposición de dos válvulas dañadas en la red principal.', 'Media', null, 'Cerrada', 'Aprobada.', t - 15 * D],
    ['SOL-0008', 'arquitecto', 'Abastecimiento temporal en Los Mina', 'Transporte de agua con camión cisterna externo', null, 1, t + 2 * D, 'Sector Los Mina', 'Los camiones propios están ocupados; se contratará el servicio de transporte.', 'Alta', 'OP-0002', 'Planificada', 'Aprobada: se contratará el servicio.', t - 2 * D],
    ['SOL-0009', 'supervisor', 'Abastecimiento en Villa Mella', 'Camión cisterna propio', 'REC-0007', 1, t + 1 * D, 'Villa Mella', 'Entrega de agua a sectores sin suministro por avería.', 'Crítica', null, 'Planificada', 'Aprobada.', t - 1 * D]];
  const insS = db.prepare('INSERT INTO solicitudes(codigo,solicitante_id,actividad,requerimiento,recurso_id,cantidad,fecha_requerida,ubicacion,justificacion,prioridad,operacion_codigo,estado,decision_comentario,decidido_por,creado,actualizado) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)');
  const sid = {};
  SO.forEach(([c, so, ac, rq, rc, q, fr, ub, ju, pr, op, es, dc, cr], i) => {
    sid[c] = insS.run(c, uid(so), ac, rq, rc ? rid(rc) : null, q, fr, ub, ju, pr, op, es, dc, es === 'Pendiente' ? null : uid('coordinador'), cr, t - (10 - i) * HORA).lastInsertRowid;
    bit('solicitud', c, 'Solicitud creada', ac, cr, null, { estado: 'Pendiente', cantidad: q });
    if (es !== 'Pendiente') bit('solicitud', c, es === 'Rechazada' ? 'Decisión: Rechazada' : 'Decisión: Aprobada', dc, cr + 2 * HORA, { estado: 'Pendiente' }, { estado: es === 'Rechazada' ? 'Rechazada' : 'Aprobada' });
  });
  db.prepare('INSERT INTO solicitud_comentarios(solicitud_id,usuario,texto,fecha) VALUES(?,?,?,?)').run(sid['SOL-0004'], nom('coordinador'), 'Prioridad alta: la planta necesita el cloro esta semana.', t - 3 * D);
  const insA = db.prepare('INSERT INTO asignaciones_recurso(solicitud_id,recurso_id,almacen_id,cantidad,responsable_id,fecha_programada,ubicacion,estado,creado_por,creado,actualizado) VALUES(?,?,?,?,?,?,?,?,?,?,?)');
  const asg = {};
  [['SOL-0003', 'REC-0003', 'ALM-01', 10, 'encargado', t + 4 * D, 'Barrio Invivienda', 'Reservada'], ['SOL-0004', 'REC-0004', 'ALM-02', 20, 'encargado', t + 1 * D, 'Planta de tratamiento Alma Rosa', 'Reservada'],
   ['SOL-0005', 'REC-0008', 'ALM-01', 5, 'encargado', t - 7 * D, 'Sector Alma Rosa', 'Entregada'], ['SOL-0007', 'REC-0002', 'ALM-01', 2, 'encargado', t - 11 * D, 'Los Tres Ojos', 'Entregada'],
   ['SOL-0009', 'REC-0007', 'ALM-03', 1, 'coordinador', t + 1 * D, 'Villa Mella', 'Reservada']].forEach(([s, r, a, q, rs, f, ub, es]) => {
    asg[s] = insA.run(sid[s], rid(r), alm(a), q, uid(rs), f, ub, es, uid('coordinador'), f - 2 * D, f - 2 * D).lastInsertRowid;
    bit('solicitud', s, 'Recurso asignado', `${r} · ${q}`, f - 2 * D, null, { recurso: r, cantidad: q, estado: 'Reservada' });
  });
  mov(rid('REC-0008'), alm('ALM-01'), 'Salida', -5, 'Entrega de la solicitud SOL-0005', 'SOL-0005', t - 7 * D);
  mov(rid('REC-0002'), alm('ALM-01'), 'Salida', -2, 'Entrega de la solicitud SOL-0007', 'SOL-0007', t - 8 * D);
  const insH = db.prepare('INSERT INTO entregas_hitos(solicitud_id,asignacion_id,tipo,fecha,responsable_id,nota,recibido_por,creado) VALUES(?,?,?,?,?,?,?,?)');
  [['SOL-0004', 'Despacho', t - 2 * HORA, 'Salida del almacén hacia la planta.', null], ['SOL-0005', 'Preparación', t - 8 * D, 'Kits revisados y empacados.', null],
   ['SOL-0005', 'Entrega', t - 7 * D, 'Entrega conforme.', 'Pedro Gómez'], ['SOL-0007', 'Preparación', t - 11 * D, 'Válvulas separadas.', null],
   ['SOL-0007', 'Retraso', t - 10 * D, 'Falta de transporte; se reprograma la entrega.', null], ['SOL-0007', 'Entrega', t - 8 * D, 'Entrega con dos días de retraso.', 'María Pérez']]
    .forEach(([s, tp, f, nt, rb]) => { insH.run(sid[s], asg[s] || null, tp, f, uid('encargado'), nt, rb, f); bit('solicitud', s, 'Hito de entrega: ' + tp, nt, f); });
  db.prepare("INSERT INTO entregas_hitos(solicitud_id,tipo,fecha,responsable_id,nota,creado) VALUES(?,?,?,?,?,?)").run(sid['SOL-0007'], 'Incidencia', t - 9 * D, uid('encargado'), 'Una válvula llegó con la rosca dañada y se cambió.', t - 9 * D);
  const insM = db.prepare('INSERT INTO mantenimientos(recurso_id,tipo,estado,descripcion,fecha_inicio,fecha_fin,resultado,observaciones,responsable_id) VALUES(?,?,?,?,?,?,?,?,?)');
  insM.run(rid('REC-0006'), 'Correctivo', 'En curso', 'Falla del sistema hidráulico del brazo.', t - 3 * D, null, null, '', uid('encargado'));
  insM.run(rid('REC-0005'), 'Preventivo', 'Finalizado', 'Cambio de sellos y revisión eléctrica.', t - 20 * D, t - 18 * D, 'Operativo', 'Sin novedades.', uid('encargado'));
  bit('recurso', 'REC-0006', 'Mantenimiento iniciado', 'Falla del sistema hidráulico del brazo.', t - 3 * D, { estado: 'Operativo' }, { estado: 'Mantenimiento' });
  const pr = (c) => db.prepare('SELECT id FROM proveedores WHERE codigo=?').get(c).id;
  const insO = db.prepare('INSERT INTO ordenes_servicio(codigo,proveedor_id,solicitud_id,alcance,fecha_inicio,fecha_fin,costo,estado,creado_por,creado,actualizado) VALUES(?,?,?,?,?,?,?,?,?,?,?)');
  insO.run('ORD-0001', pr('PRV-0001'), sid['SOL-0008'], 'Transporte de agua en camión cisterna de 10 000 L durante tres días.', t - 1 * D, t + 2 * D, 45000, 'En ejecución', uid('coordinador'), t - 2 * D, t - 1 * D);
  insO.run('ORD-0002', pr('PRV-0002'), sid['SOL-0007'], 'Suministro de dos válvulas de compuerta de 4 pulgadas.', t - 14 * D, t - 11 * D, 8500, 'Completada', uid('coordinador'), t - 14 * D, t - 11 * D);
  bit('orden', 'ORD-0001', 'Orden creada', 'Transportes Hídricos del Este', t - 2 * D, null, { estado: 'Emitida' });
  bit('orden', 'ORD-0002', 'Orden creada', 'Ferretería Industrial Caribe', t - 14 * D, null, { estado: 'Emitida' });
  const insN = db.prepare('INSERT INTO notificaciones(usuario_id,tipo,mensaje,fecha) VALUES(?,?,?,?)');
  if (uid('coordinador')) insN.run(uid('coordinador'), 'Solicitud', 'Nueva solicitud logística SOL-0001 pendiente de aprobación.', t - 1 * D);
  if (uid('encargado')) { insN.run(uid('encargado'), 'Asignación logística', 'Se te asignó la entrega de la solicitud SOL-0003.', t - 2 * D); insN.run(uid('encargado'), 'Asignación logística', 'Se te asignó la entrega de la solicitud SOL-0004.', t - 3 * D); }
}

function migrarEpica3(db, seedDemo) {
  db.exec(SCHEMA_E3);
  const cfg = (k, v) => db.prepare('INSERT OR IGNORE INTO config(clave,valor) VALUES(?,?)').run(k, v);
  cfg('evidenciaHabilitada', '1'); cfg('evidenciaObligatoria', '0');
  ROLES_E3.forEach((n) => db.prepare('INSERT OR IGNORE INTO roles(nombre) VALUES(?)').run(n));
  const insP = db.prepare('INSERT OR IGNORE INTO permisos(rol_id,modulo,crear,consultar,modificar,eliminar) VALUES(?,?,?,?,?,?)');
  db.prepare('SELECT id, nombre FROM roles').all().forEach((r) => {
    const p = permisosIniciales(r.nombre);
    MODULOS.forEach((m) => insP.run(r.id, m, p[m].c, p[m].r, p[m].u, p[m].d));
  });
  if (!db.prepare('SELECT COUNT(*) n FROM categorias_recurso').get().n) {
    ['Tuberías y accesorios', 'Válvulas y medidores', 'Herramientas y equipos', 'Vehículos', 'Químicos de tratamiento'].forEach((n) => db.prepare('INSERT INTO categorias_recurso(nombre) VALUES(?)').run(n));
    [['ALM-01', 'Almacén Central', 'Santo Domingo Este'], ['ALM-02', 'Almacén Los Mina', 'Los Mina'], ['ALM-03', 'Depósito de equipos', 'Santo Domingo Norte']]
      .forEach(([c, n, u]) => db.prepare('INSERT INTO almacenes(codigo,nombre,ubicacion) VALUES(?,?,?)').run(c, n, u));
  }
  if (seedDemo && !db.prepare("SELECT 1 FROM config WHERE clave='demo_e3'").get()) {
    const h = hash('Demo123*'), ins = db.prepare('INSERT OR IGNORE INTO usuarios(nombre,correo,telefono,clave_hash,rol_id,actualizado) VALUES(?,?,?,?,?,?)');
    [['Carlos Coordinador', 'coordinador', 'Coordinador Logístico'], ['Elena Encargada', 'encargado', 'Encargado de Almacén']].forEach(([n, c, rol], i) =>
      ins.run(n, c + '@aguaclara.do', '809-555-030' + (i + 4), h, db.prepare('SELECT id FROM roles WHERE nombre=?').get(rol).id, Date.now()));
    if (!db.prepare('SELECT COUNT(*) n FROM recursos').get().n) db.transaction(() => sembrarLogisticaDemo(db))();
    cfg('demo_e3', '1');
  }
}

function open(file, opt = {}) {
  const db = new Database(file);
  db.pragma('journal_mode = WAL');
  db.pragma('foreign_keys = ON');
  db.exec(SCHEMA);
  const ahora = Date.now(), seedDemo = (opt.seedDemo ?? process.env.SEED_DEMO ?? '1') !== '0';
  if (!db.prepare('SELECT COUNT(*) n FROM roles').get().n) {
    const insR = db.prepare('INSERT INTO roles(nombre) VALUES(?)');
    const insP = db.prepare('INSERT INTO permisos(rol_id,modulo,crear,consultar,modificar,eliminar) VALUES(?,?,?,?,?,?)');
    db.transaction(() => {
      ROLES.concat(ROLES_E2).forEach((nombre) => {
        const id = insR.run(nombre).lastInsertRowid, p = permisosIniciales(nombre);
        MODULOS.forEach((m) => insP.run(id, m, p[m].c, p[m].r, p[m].u, p[m].d));
      });
      db.prepare("INSERT INTO config VALUES('resetMin','15')").run();
    })();
  }
  if (!db.prepare('SELECT COUNT(*) n FROM usuarios').get().n) {
    const rolId = (n) => db.prepare('SELECT id FROM roles WHERE nombre=?').get(n).id;
    const insU = db.prepare('INSERT INTO usuarios(nombre,correo,telefono,clave_hash,rol_id,actualizado) VALUES(?,?,?,?,?,?)');
    if (seedDemo) {
      const h = hash('Demo123*');
      [['Super Admin', 'super'], ['Ana Administradora', 'admin'], ['Agustín Agente', 'agente'], ['Aurora Arquitecta', 'arquitecto'],
       ['Iván Ingeniero', 'ingeniero'], ['Clara Cliente', 'cliente'], ['Sergio Supervisor', 'supervisor']]
        .forEach(([n, c], i) => insU.run(n, c + '@aguaclara.do', '809-555-010' + i, h, rolId(ROLES[i]), ahora));
      db.prepare('INSERT INTO reportes(codigo,municipio,sector,tipo,desde,descripcion,estado,creado) VALUES(?,?,?,?,?,?,?,?)')
        .run('DEMO-001', 'Santo Domingo Este', 'Alma Rosa', TIPOS[1], '2026-10-02',
          'Hay una fuga de agua en la calle principal del sector. El agua se acumula junto a la acera.', 0, ahora);
    } else if (process.env.ADMIN_EMAIL && process.env.ADMIN_PASSWORD) {
      insU.run('Administrador', process.env.ADMIN_EMAIL, '', hash(process.env.ADMIN_PASSWORD), rolId(ROLES[0]), ahora);
    }
  }
  migrarEpica2(db, seedDemo);
  migrarEpica3(db, seedDemo);
  return db;
}

module.exports = { open, hash, MODULOS, MODN, TIPOS, ROLES };
