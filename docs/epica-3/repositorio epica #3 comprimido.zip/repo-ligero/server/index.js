// API de Agua Clara RD (Express + SQLite). La seguridad se valida AQUÍ, no en la pantalla.
const express = require('express'), bcrypt = require('bcryptjs'), crypto = require('crypto');
const path = require('path'), fs = require('fs');
const { open, hash, MODULOS, MODN, TIPOS } = require('./db');

const ACCN = { c: 'Crear', r: 'Consultar', u: 'Modificar', d: 'Eliminar' };
const SUPER = 'Super Administrador', EM = /^\S+@\S+\.\S+$/;
const DUMMY = bcrypt.hashSync('relleno-para-igualar-tiempos', 4);
const now = () => Date.now();
const txt = (v, n = 200) => String(v == null ? '' : v).trim().slice(0, n);

function createApp(db, opt = {}) {
  const app = express(), fails = new Map();
  app.disable('x-powered-by');
  if (opt.trustProxy) app.set('trust proxy', 1);
  app.use(express.json({ limit: '400kb' }));
  app.use((req, res, next) => {
    res.set({ 'X-Content-Type-Options': 'nosniff', 'X-Frame-Options': 'DENY', 'Referrer-Policy': 'same-origin' });
    if (req.path.startsWith('/api')) res.set('Cache-Control', 'no-store');
    next();
  });

  const ipOf = (req) => String(req.ip || '').replace('::ffff:', '');
  function loc(ip) {
    if (!ip || ip === '::1' || /^(127\.|10\.|192\.168\.|172\.(1[6-9]|2\d|3[01])\.)/.test(ip)) return 'Red local';
    try { const g = require('geoip-lite').lookup(ip); if (g) return [g.city, g.country].filter(Boolean).join(', '); } catch (e) { /* geoip-lite es opcional */ }
    return 'No disponible';
  }
  function audit(req, ev, det, who) {
    const ip = ipOf(req);
    db.prepare('INSERT INTO auditoria(fecha,usuario,evento,ip,localizacion,detalle) VALUES(?,?,?,?,?,?)')
      .run(now(), who || (req.u && req.u.correo) || 'anónimo', ev, ip, loc(ip), det || '');
  }
  function permsOf(rolId) {
    const o = Object.fromEntries(MODULOS.map((m) => [m, { c: 0, r: 0, u: 0, d: 0 }]));
    db.prepare('SELECT * FROM permisos WHERE rol_id=?').all(rolId)
      .forEach((p) => (o[p.modulo] = { c: p.crear, r: p.consultar, u: p.modificar, d: p.eliminar }));
    return o;
  }
  const cfgMin = () => +db.prepare("SELECT valor FROM config WHERE clave='resetMin'").get().valor;
  const rolPorNombre = (n, soloActivo) => db.prepare('SELECT * FROM roles WHERE nombre=?' + (soloActivo ? ' AND activo=1' : '')).get(txt(n));
  const nActivos = (rolId) => db.prepare("SELECT COUNT(*) n FROM usuarios WHERE rol_id=? AND estado='Activo'").get(rolId).n;
  const nUsuarios = (rolId) => db.prepare('SELECT COUNT(*) n FROM usuarios WHERE rol_id=?').get(rolId).n;

  // ---- Sesión: lee la cookie y carga usuario y permisos desde la base de datos ----
  app.use((req, res, next) => {
    req.u = null;
    const m = /(?:^|;\s*)ac_sid=([a-f0-9]{64})/.exec(req.headers.cookie || '');
    if (m) {
      const r = db.prepare('SELECT u.*, r.nombre rol, s.expira FROM sesiones s JOIN usuarios u ON u.id=s.usuario_id JOIN roles r ON r.id=u.rol_id WHERE s.token=?').get(m[1]);
      if (r && r.expira > now() && r.estado === 'Activo') {
        req.u = { id: r.id, nombre: r.nombre, correo: r.correo, telefono: r.telefono, foto: r.foto, upd: r.actualizado, rol: r.rol, rolId: r.rol_id, perms: permsOf(r.rol_id) };
        req.tok = m[1];
      } else if (r) db.prepare('DELETE FROM sesiones WHERE token=?').run(m[1]);
    }
    next();
  });
  const auth = (req, res, next) => (req.u ? next() : res.status(401).json({ error: 'Debes iniciar sesión.' }));
  const need = (mod, a) => (req, res, next) => {
    if (!req.u) return res.status(401).json({ error: 'Debes iniciar sesión.' });
    if (req.u.perms[mod][a]) return next();
    audit(req, 'Acceso denegado', `${MODN[mod]} · ${ACCN[a]}`);
    res.status(403).json({ error: `Acceso denegado: tu rol no permite ${ACCN[a].toLowerCase()} en ${MODN[mod]}.` });
  };
  const bad = (res, msg, code = 400) => res.status(code).json({ error: msg });

  const U = (r) => ({ id: r.id, name: r.nombre, email: r.correo, phone: r.telefono, role: r.rol, status: r.estado, reason: r.motivo || '', upd: r.actualizado });
  const ME = (u) => ({ id: u.id, name: u.nombre, email: u.correo, phone: u.telefono, role: u.rol, photo: u.foto || null, upd: u.upd, perms: u.perms });
  const REP = (r) => ({ code: r.codigo, mun: r.municipio, sec: r.sector, tipo: r.tipo, desde: r.desde, desc: r.descripcion, est: r.estado });

  // ---- HU-1.1 Autenticación ----
  app.post('/api/login', (req, res) => {
    const correo = txt(req.body.correo), clave = String(req.body.clave || ''), k = correo.toLowerCase(), f = fails.get(k);
    if (f && f.n >= 5 && now() - f.t < 600000) { audit(req, 'Intento bloqueado', 'Demasiados intentos', correo || 'anónimo'); return bad(res, 'Demasiados intentos fallidos. Espera 10 minutos.', 429); }
    const u = db.prepare('SELECT u.*, r.nombre rol FROM usuarios u JOIN roles r ON r.id=u.rol_id WHERE u.correo=?').get(correo);
    const ok = bcrypt.compareSync(clave, u ? u.clave_hash : DUMMY) && u;
    if (!ok) {
      const x = f && now() - f.t < 600000 ? f : { n: 0, t: now() }; x.n++; fails.set(k, x);
      audit(req, 'Intento fallido', 'Credenciales inválidas', correo || 'anónimo');
      return bad(res, 'Correo o contraseña incorrectos.', 401);
    }
    if (u.estado === 'Bloqueado') { audit(req, 'Intento bloqueado', 'Usuario bloqueado', u.correo); return bad(res, 'Tu usuario está bloqueado. Contacta al administrador.', 403); }
    fails.delete(k);
    db.prepare('DELETE FROM sesiones WHERE expira<?').run(now());
    const token = crypto.randomBytes(32).toString('hex');
    db.prepare('INSERT INTO sesiones VALUES(?,?,?)').run(token, u.id, now() + 8 * 3600e3);
    res.cookie('ac_sid', token, { httpOnly: true, sameSite: 'lax', secure: !!opt.secure, maxAge: 8 * 3600e3, path: '/' });
    audit(req, 'Inicio de sesión', u.rol, u.correo);
    res.json({ ok: true });
  });
  app.post('/api/logout', (req, res) => {
    if (req.u) { audit(req, 'Cierre de sesión', ''); db.prepare('DELETE FROM sesiones WHERE token=?').run(req.tok); }
    res.clearCookie('ac_sid', { path: '/' });
    res.json({ ok: true });
  });
  app.get('/api/me', (req, res) => res.json({ me: req.u ? ME(req.u) : null })); // sin sesión devuelve me:null (no es un error)
  app.post('/api/acceso', auth, (req, res) => { // el panel avisa cuando alguien intenta abrir un módulo
    const m = txt(req.body.modulo);
    if (!MODULOS.includes(m)) return bad(res, 'Módulo desconocido.');
    if (req.u.perms[m].r) return res.json({ ok: true });
    audit(req, 'Acceso denegado', `${MODN[m]} · Consultar`);
    res.status(403).json({ error: 'Acceso denegado.' });
  });
  app.post('/api/probar', auth, (req, res) => {
    const items = [];
    MODULOS.forEach((m) => Object.keys(ACCN).forEach((a) => {
      const ok = !!req.u.perms[m][a]; items.push({ modulo: m, accion: a, ok });
      if (!ok) audit(req, 'Acceso denegado', `${MODN[m]} · ${ACCN[a]} (prueba)`);
    }));
    res.json({ items });
  });

  // ---- HU-1.2 Registro ----
  function crearUsuario(req, res, rolNombre, quien) {
    const nombre = txt(req.body.nombre, 120), correo = txt(req.body.correo, 160), telefono = txt(req.body.telefono, 40), clave = String(req.body.clave || '');
    if (!nombre || !EM.test(correo)) return bad(res, 'Escribe el nombre y un correo válido.');
    if (clave.length < 8) return bad(res, 'La contraseña necesita al menos 8 caracteres.');
    const rol = rolPorNombre(rolNombre, true);
    if (!rol) return bad(res, 'Ese rol no existe o está desactivado.');
    if (db.prepare('SELECT 1 FROM usuarios WHERE correo=?').get(correo)) return bad(res, 'Ese correo ya está registrado.', 409);
    db.prepare('INSERT INTO usuarios(nombre,correo,telefono,clave_hash,rol_id,actualizado) VALUES(?,?,?,?,?,?)').run(nombre, correo, telefono, hash(clave), rol.id, now());
    audit(req, quien, correo, quien === 'Registro de usuario' ? correo : undefined);
    res.status(201).json({ ok: true });
  }
  app.post('/api/registro', (req, res) => crearUsuario(req, res, 'Cliente', 'Registro de usuario'));
  app.post('/api/usuarios', need('usuarios', 'c'), (req, res) => crearUsuario(req, res, req.body.rol, 'Usuario creado'));
  app.get('/api/usuarios', need('usuarios', 'r'), (req, res) =>
    res.json({ items: db.prepare('SELECT u.*, r.nombre rol FROM usuarios u JOIN roles r ON r.id=u.rol_id ORDER BY u.id').all().map(U) }));
  app.put('/api/usuarios/:id/rol', need('usuarios', 'u'), (req, res) => {
    const u = db.prepare('SELECT * FROM usuarios WHERE id=?').get(+req.params.id), rol = rolPorNombre(req.body.rol, true);
    if (!u) return bad(res, 'Usuario no encontrado.', 404);
    if (!rol) return bad(res, 'Ese rol no existe o está desactivado.');
    db.prepare('UPDATE usuarios SET rol_id=?, actualizado=? WHERE id=?').run(rol.id, now(), u.id);
    audit(req, 'Rol asignado', `${u.correo} → ${rol.nombre}`);
    res.json({ ok: true });
  });
  // HU-1.6 Bloqueo
  app.put('/api/usuarios/:id/bloqueo', need('usuarios', 'u'), (req, res) => {
    const u = db.prepare('SELECT * FROM usuarios WHERE id=?').get(+req.params.id);
    if (!u) return bad(res, 'Usuario no encontrado.', 404);
    if (req.body.bloquear) {
      const motivo = txt(req.body.motivo, 200);
      if (!motivo) return bad(res, 'Escribe el motivo del bloqueo.');
      if (u.id === req.u.id) return bad(res, 'No puedes bloquear tu propio usuario.');
      db.prepare("UPDATE usuarios SET estado='Bloqueado', motivo=?, actualizado=? WHERE id=?").run(motivo, now(), u.id);
      db.prepare('DELETE FROM sesiones WHERE usuario_id=?').run(u.id);
      audit(req, 'Usuario bloqueado', `${u.correo} · ${motivo}`);
    } else {
      db.prepare("UPDATE usuarios SET estado='Activo', motivo='', actualizado=? WHERE id=?").run(now(), u.id);
      audit(req, 'Usuario reactivado', u.correo);
    }
    res.json({ ok: true });
  });
  app.delete('/api/usuarios/:id', need('usuarios', 'd'), (req, res) => {
    const u = db.prepare('SELECT * FROM usuarios WHERE id=?').get(+req.params.id);
    if (!u) return bad(res, 'Usuario no encontrado.', 404);
    if (u.id === req.u.id) return bad(res, 'No puedes eliminar tu propio usuario.');
    db.prepare('DELETE FROM usuarios WHERE id=?').run(u.id);
    audit(req, 'Usuario eliminado', u.correo);
    res.json({ ok: true });
  });

  // ---- HU-1.3 Roles ----
  app.get('/api/roles', auth, (req, res) =>
    res.json({ items: db.prepare('SELECT * FROM roles ORDER BY id').all().map((r) => ({ id: r.id, n: r.nombre, a: !!r.activo, k: nActivos(r.id) })) }));
  app.post('/api/roles', need('roles', 'c'), (req, res) => {
    const n = txt(req.body.nombre, 60);
    if (!n) return bad(res, 'Escribe el nombre del rol.');
    if (rolPorNombre(n)) return bad(res, 'Ese rol ya existe.', 409);
    db.transaction(() => {
      const id = db.prepare('INSERT INTO roles(nombre) VALUES(?)').run(n).lastInsertRowid;
      MODULOS.forEach((m) => db.prepare('INSERT INTO permisos(rol_id,modulo) VALUES(?,?)').run(id, m));
    })();
    audit(req, 'Rol creado', n);
    res.status(201).json({ ok: true });
  });
  const rolDe = (req, res) => {
    const r = db.prepare('SELECT * FROM roles WHERE id=?').get(+req.params.id);
    if (!r) bad(res, 'Rol no encontrado.', 404);
    else if (r.nombre === SUPER) bad(res, 'El rol Super Administrador está protegido y no se puede modificar.', 403);
    return r && r.nombre !== SUPER ? r : null;
  };
  app.put('/api/roles/:id', need('roles', 'u'), (req, res) => {
    const r = rolDe(req, res); if (!r) return;
    const n = txt(req.body.nombre, 60);
    if (!n) return bad(res, 'Escribe el nombre del rol.');
    const otro = rolPorNombre(n);
    if (otro && otro.id !== r.id) return bad(res, 'Ese rol ya existe.', 409);
    db.prepare('UPDATE roles SET nombre=? WHERE id=?').run(n, r.id);
    audit(req, 'Rol modificado', `${r.nombre} → ${n}`);
    res.json({ ok: true });
  });
  app.put('/api/roles/:id/estado', need('roles', 'u'), (req, res) => {
    const r = rolDe(req, res); if (!r) return;
    const activo = req.body.activo ? 1 : 0;
    if (!activo && nActivos(r.id)) return bad(res, `No puedes desactivar "${r.nombre}": tiene usuarios activos.`, 409);
    db.prepare('UPDATE roles SET activo=? WHERE id=?').run(activo, r.id);
    audit(req, activo ? 'Rol activado' : 'Rol desactivado', r.nombre);
    res.json({ ok: true });
  });
  app.delete('/api/roles/:id', need('roles', 'd'), (req, res) => {
    const r = rolDe(req, res); if (!r) return;
    if (nUsuarios(r.id)) return bad(res, `No puedes eliminar "${r.nombre}": tiene usuarios asociados.`, 409);
    db.prepare('DELETE FROM roles WHERE id=?').run(r.id);
    audit(req, 'Rol eliminado', r.nombre);
    res.json({ ok: true });
  });

  // ---- HU-1.4 Permisos ----
  app.get('/api/permisos', auth, (req, res) => {
    const items = {};
    db.prepare('SELECT * FROM roles ORDER BY id').all().forEach((r) => (items[r.nombre] = permsOf(r.id)));
    res.json({ items });
  });
  app.put('/api/permisos', need('permisos', 'u'), (req, res) => {
    const r = rolPorNombre(req.body.rol), m = txt(req.body.modulo), a = txt(req.body.accion);
    if (!r) return bad(res, 'Rol no encontrado.', 404);
    if (!MODULOS.includes(m) || !ACCN[a]) return bad(res, 'Módulo o acción inválidos.');
    if (r.nombre === SUPER) return bad(res, 'El Super Administrador no se puede restringir.', 403);
    const col = { c: 'crear', r: 'consultar', u: 'modificar', d: 'eliminar' }[a], v = req.body.valor ? 1 : 0;
    db.prepare(`UPDATE permisos SET ${col}=? WHERE rol_id=? AND modulo=?`).run(v, r.id, m);
    audit(req, 'Permiso modificado', `${r.nombre} · ${MODN[m]} · ${ACCN[a]} = ${v ? 'sí' : 'no'}`);
    res.json({ ok: true });
  });

  // ---- HU-1.8 Auditoría ----
  app.get('/api/auditoria', need('auditoria', 'r'), (req, res) =>
    res.json({ items: db.prepare('SELECT * FROM auditoria ORDER BY id DESC LIMIT 300').all().map((a) => ({ t: a.fecha, u: a.usuario, ev: a.evento, ip: a.ip, loc: a.localizacion, det: a.detalle })) }));

  // ---- Configuración ----
  app.get('/api/config', auth, (req, res) => res.json({ cfg: { resetMin: cfgMin() } }));
  app.put('/api/config', need('usuarios', 'u'), (req, res) => {
    const m = Math.round(+req.body.resetMin);
    if (!(m >= 1 && m <= 1440)) return bad(res, 'La vigencia debe estar entre 1 y 1440 minutos.');
    db.prepare("UPDATE config SET valor=? WHERE clave='resetMin'").run(String(m));
    audit(req, 'Configuración modificada', `Vigencia del enlace = ${m} min`);
    res.json({ ok: true });
  });

  // ---- HU-1.7 Perfil ----
  app.put('/api/perfil', auth, (req, res) => {
    const b = req.body, nombre = b.nombre === undefined ? req.u.nombre : txt(b.nombre, 120);
    if (!nombre) return bad(res, 'El nombre no puede quedar vacío.');
    let foto = req.u.foto;
    if (b.foto !== undefined) {
      if (typeof b.foto !== 'string' || !/^data:image\/(png|jpe?g|gif|webp);base64,/.test(b.foto) || b.foto.length > 220000) return bad(res, 'La foto debe ser una imagen de menos de 150 KB.');
      foto = b.foto;
    }
    db.prepare('UPDATE usuarios SET nombre=?, telefono=?, foto=?, actualizado=? WHERE id=?')
      .run(nombre, b.telefono === undefined ? req.u.telefono : txt(b.telefono, 40), foto, now(), req.u.id);
    audit(req, b.foto !== undefined ? 'Foto actualizada' : 'Perfil actualizado', '');
    res.json({ ok: true });
  });
  app.put('/api/perfil/clave', auth, (req, res) => {
    const row = db.prepare('SELECT clave_hash FROM usuarios WHERE id=?').get(req.u.id);
    if (!bcrypt.compareSync(String(req.body.actual || ''), row.clave_hash)) return bad(res, 'La contraseña actual no coincide.');
    if (String(req.body.nueva || '').length < 8) return bad(res, 'La nueva contraseña necesita al menos 8 caracteres.');
    db.prepare('UPDATE usuarios SET clave_hash=?, actualizado=? WHERE id=?').run(hash(String(req.body.nueva)), now(), req.u.id);
    audit(req, 'Contraseña cambiada', '');
    res.json({ ok: true });
  });

  // ---- HU-1.5 Recuperación de contraseña ----
  app.post('/api/recuperar', (req, res) => {
    const u = db.prepare('SELECT * FROM usuarios WHERE correo=?').get(txt(req.body.correo, 160));
    const demo = (opt.modoDemo ?? process.env.MODO_DEMO ?? '1') !== '0';
    if (!u) return demo ? bad(res, 'No encontramos una cuenta con ese correo.', 404) : res.json({ ok: true });
    db.prepare('UPDATE tokens_recuperacion SET usado=1 WHERE usuario_id=?').run(u.id);
    const k = crypto.randomBytes(24).toString('hex'), exp = now() + cfgMin() * 60000;
    db.prepare('INSERT INTO tokens_recuperacion(token,usuario_id,expira) VALUES(?,?,?)').run(k, u.id, exp);
    audit(req, 'Recuperación solicitada', '', u.correo);
    // Correo simulado: en modo demo el enlace se devuelve a la pantalla. En producción se enviaría por correo.
    if (!demo) console.log(`[correo simulado] enlace de recuperación para ${u.correo}: token ${k}`);
    res.json(demo ? { ok: true, k, exp } : { ok: true });
  });
  app.post('/api/recuperar/usar', (req, res) => {
    const t = db.prepare('SELECT * FROM tokens_recuperacion WHERE token=?').get(txt(req.body.token, 80));
    if (!t || t.usado) return bad(res, 'Este enlace ya no es válido.');
    if (t.expira < now()) return bad(res, 'El enlace expiró. Solicita uno nuevo.');
    const clave = String(req.body.clave || '');
    if (clave.length < 8) return bad(res, 'La contraseña necesita al menos 8 caracteres.');
    const u = db.prepare('SELECT * FROM usuarios WHERE id=?').get(t.usuario_id);
    db.transaction(() => {
      db.prepare('UPDATE usuarios SET clave_hash=?, actualizado=? WHERE id=?').run(hash(clave), now(), u.id);
      db.prepare('UPDATE tokens_recuperacion SET usado=1 WHERE usuario_id=?').run(u.id);
      db.prepare('DELETE FROM sesiones WHERE usuario_id=?').run(u.id);
    })();
    audit(req, 'Contraseña restablecida', '', u.correo);
    res.json({ ok: true });
  });

  // ---- Reportes ciudadanos ----
  app.post('/api/reportes', (req, res) => { // público: no requiere cuenta
    const b = req.body, sector = txt(b.sector, 80), desc = txt(b.descripcion, 1000), mun = txt(b.municipio, 80), tipo = txt(b.tipo, 60);
    if (!sector) return bad(res, 'Escribe el sector donde ocurre el problema.');
    if (desc.length < 10) return bad(res, 'Describe lo que observas (mínimo 10 caracteres).');
    if (!mun || !TIPOS.includes(tipo)) return bad(res, 'Elige el municipio y el tipo de problema.');
    const id = (db.prepare('SELECT COALESCE(MAX(id),0)+1 n FROM reportes').get().n), codigo = 'DEMO-' + String(id).padStart(3, '0');
    db.prepare('INSERT INTO reportes(id,codigo,municipio,sector,tipo,desde,descripcion,contacto_nombre,contacto_telefono,creado) VALUES(?,?,?,?,?,?,?,?,?,?)')
      .run(id, codigo, mun, sector, tipo, txt(b.desde, 10), desc, txt(b.contactoNombre, 80), txt(b.contactoTelefono, 40), now());
    audit(req, 'Reporte creado', codigo, 'anónimo');
    res.status(201).json({ ok: true, codigo });
  });
  app.get('/api/reportes/publico/:codigo', (req, res) => { // público: sin datos de contacto
    const r = db.prepare('SELECT * FROM reportes WHERE codigo=?').get(txt(req.params.codigo, 20).toUpperCase());
    r ? res.json({ item: REP(r) }) : bad(res, 'No encontramos ese código.', 404);
  });
  app.get('/api/reportes', need('reportes', 'r'), (req, res) => res.json({ items: db.prepare('SELECT * FROM reportes ORDER BY id').all().map(REP) }));
  app.put('/api/reportes/:codigo/estado', need('reportes', 'u'), (req, res) => {
    const e = +req.body.estado;
    if (![0, 1, 2].includes(e)) return bad(res, 'Estado inválido.');
    const r = db.prepare('UPDATE reportes SET estado=? WHERE codigo=?').run(e, txt(req.params.codigo, 20));
    if (!r.changes) return bad(res, 'Reporte no encontrado.', 404);
    audit(req, 'Reporte modificado', `${req.params.codigo} → ${['Recibido', 'En revisión', 'Atendido'][e]}`);
    res.json({ ok: true });
  });
  app.delete('/api/reportes/:codigo', need('reportes', 'd'), (req, res) => {
    const r = db.prepare('DELETE FROM reportes WHERE codigo=?').run(txt(req.params.codigo, 20));
    if (!r.changes) return bad(res, 'Reporte no encontrado.', 404);
    audit(req, 'Reporte eliminado', req.params.codigo);
    res.json({ ok: true });
  });

  // ---- Épica 2: Gestión de Operaciones ----
  const ops = require('./operaciones')(app, { db, audit, need, auth, bad, txt, now, permsOf, MODN });
  // ---- Épica 3: Gestión logística ----
  require('./openapi')(app, { db, need });
  require('./logistica')(app, { db, audit, need, auth, bad, txt, now, permsOf, MODN });
  if (opt.alertas !== false) { // revisa vencimientos al iniciar y cada 5 minutos
    const revisar = () => { try { ops.generarAlertas({}); } catch (e) { console.error('alertas:', e.message); } };
    revisar(); setInterval(revisar, 5 * 60e3).unref();
  }

  app.use('/api', (req, res) => bad(res, 'Ruta no encontrada.', 404));
  app.use(express.static(path.join(__dirname, '..', 'public')));
  app.use((err, req, res, next) => { // errores (por ejemplo JSON mal formado)
    if (err && err.type === 'entity.parse.failed') return bad(res, 'Solicitud mal formada.');
    console.error(err);
    bad(res, 'Error interno del servidor.', 500);
  });
  return app;
}

function cargarEnv() {
  const f = path.join(__dirname, '..', '.env');
  if (!fs.existsSync(f)) return;
  fs.readFileSync(f, 'utf8').split(/\r?\n/).forEach((l) => {
    const m = /^\s*([A-Z_]+)\s*=\s*(.*?)\s*$/.exec(l);
    if (m && !l.trim().startsWith('#') && process.env[m[1]] === undefined) process.env[m[1]] = m[2];
  });
}

if (require.main === module) {
  cargarEnv();
  const file = path.resolve(process.env.DB_FILE || path.join(__dirname, '..', 'data', 'aguas-claras.db'));
  fs.mkdirSync(path.dirname(file), { recursive: true });
  const app = createApp(open(file), { trustProxy: process.env.TRUST_PROXY === '1', secure: process.env.COOKIE_SECURE === '1' });
  const port = +process.env.PORT || 3000;
  app.listen(port, () => console.log(`Agua Clara RD en http://localhost:${port}  (base de datos: ${file})`));
}
module.exports = { createApp };
