// Épica 3 – Gestión logística. Las reglas de negocio se validan aquí, en el servidor.
const TIPOS_RECURSO = ['Material', 'Equipo', 'Vehículo'];
const PRIORIDADES = ['Baja', 'Media', 'Alta', 'Crítica'];
const SOL_ESTADOS = ['Pendiente', 'Aprobada', 'Rechazada', 'Planificada', 'En ejecución', 'Entregada', 'Cerrada', 'Cancelada'];
const SOL_TERMINAL = ['Entregada', 'Cerrada', 'Rechazada', 'Cancelada'];
const HITOS = ['Preparación', 'Despacho', 'En tránsito', 'Entrega', 'Retraso', 'Incidencia'];
const CONDICIONES = ['Buena', 'Requiere mantenimiento', 'Dañado'];
const ORD_TRANS = { 'Emitida': ['En ejecución', 'Cancelada'], 'En ejecución': ['Completada', 'Cancelada'], 'Completada': [], 'Cancelada': [] };
const HORA = 3600e3;

module.exports = function registrar(app, c) {
  const { db, need, auth, bad, txt, now, permsOf } = c;

  // ---------- utilidades ----------
  const r2 = (x) => Math.round(x * 100) / 100;
  const ms = (s, fin) => {
    if (!/^\d{4}-\d{2}-\d{2}$/.test(String(s || ''))) return 0;
    const t = Date.parse(s + (fin ? 'T23:59:59.999' : 'T00:00:00'));
    return isNaN(t) ? 0 : t;
  };
  const fechaOk = (v) => { const t = Date.parse(v); return isNaN(t) ? null : t; };
  const js = (o) => (o ? JSON.stringify(o) : null);
  const cfg = (k) => (db.prepare('SELECT valor FROM config WHERE clave=?').get(k) || {}).valor;
  const siguiente = (tabla, prefijo) => prefijo + String(db.prepare(`SELECT COALESCE(MAX(id),0)+1 n FROM ${tabla}`).get().n).padStart(4, '0');
  function bit(req, entidad, ref, accion, resultado, antes, despues, detalle) {
    db.prepare('INSERT INTO bitacora(fecha,actor_id,actor,entidad,entidad_id,operacion,accion,resultado,antes,despues,detalle) VALUES(?,?,?,?,?,?,?,?,?,?,?)')
      .run(now(), req && req.u ? req.u.id : null, req && req.u ? req.u.correo : 'sistema', entidad, String(ref), String(ref), accion, resultado || 'Exitoso', js(antes), js(despues), detalle || '');
  }
  const rechazar = (req, res, entidad, ref, accion, msg, code = 409) => { bit(req, entidad, ref, accion, 'Rechazado', null, null, msg); return bad(res, msg, code); };
  const notif = (uid, tipo, mensaje) => { if (uid) db.prepare('INSERT INTO notificaciones(usuario_id,tipo,mensaje,fecha) VALUES(?,?,?,?)').run(uid, tipo, mensaje, now()); };
  const usuariosCon = (mod, a, excluir) => db.prepare("SELECT id, rol_id FROM usuarios WHERE estado='Activo'").all().filter((u) => u.id !== excluir && permsOf(u.rol_id)[mod][a]);
  const entero = (unidad, q) => !['unidad', 'kit'].includes(unidad) || Number.isInteger(q);

  // ---------- recursos, existencias y disponibilidad ----------
  const SQL_REC = `SELECT r.*, c.nombre categoria,
    COALESCE((SELECT SUM(cantidad) FROM movimientos m WHERE m.recurso_id=r.id),0) existencias,
    COALESCE((SELECT SUM(cantidad) FROM asignaciones_recurso a WHERE a.recurso_id=r.id AND a.estado='Reservada'),0) reservado,
    COALESCE((SELECT SUM(cantidad-devuelta) FROM asignaciones_recurso a WHERE a.recurso_id=r.id AND a.estado='Entregada'),0) en_uso
    FROM recursos r JOIN categorias_recurso c ON c.id=r.categoria_id`;
  const condicion = (r) => {
    if (!r.activo) return 'Inactivo';
    if (r.estado !== 'Operativo') return r.estado;
    if (r.tipo === 'Material') return r.existencias - r.reservado > 0 ? 'Disponible' : r.reservado > 0 ? 'Reservado' : 'Agotado';
    return r.reservado > 0 || r.en_uso > 0 ? 'Reservado' : 'Disponible';
  };
  const REC = (r) => {
    const disponible = r2(r.existencias - r.reservado);
    return { codigo: r.codigo, nombre: r.nombre, categoria: r.categoria, categoria_id: r.categoria_id, tipo: r.tipo, unidad: r.unidad, descripcion: r.descripcion,
      stock_minimo: r.stock_minimo, estado: r.estado, activo: !!r.activo, existencias: r2(r.existencias), reservado: r2(r.reservado), disponible, en_uso: r2(r.en_uso),
      condicion: condicion(r), bajo_minimo: r.tipo === 'Material' && r.stock_minimo > 0 && disponible < r.stock_minimo };
  };
  const getRec = (codigo) => db.prepare(SQL_REC + ' WHERE r.codigo=?').get(txt(codigo, 20).toUpperCase());
  const existAlm = (rid, aid) => r2(db.prepare('SELECT COALESCE(SUM(cantidad),0) s FROM movimientos WHERE recurso_id=? AND almacen_id=?').get(rid, aid).s);
  const reservAlm = (rid, aid, excluir) => r2(db.prepare("SELECT COALESCE(SUM(cantidad),0) s FROM asignaciones_recurso WHERE recurso_id=? AND almacen_id=? AND estado='Reservada' AND id!=?").get(rid, aid, excluir || 0).s);

  app.get('/api/recursos', need('catalogo', 'r'), (req, res) => {
    const q = req.query, w = [], a = [];
    if (q.q) { const l = '%' + txt(q.q, 60) + '%'; w.push('(r.codigo LIKE ? OR r.nombre LIKE ?)'); a.push(l, l); }
    if (+q.categoria) { w.push('r.categoria_id=?'); a.push(+q.categoria); }
    if (TIPOS_RECURSO.includes(q.tipo)) { w.push('r.tipo=?'); a.push(q.tipo); }
    if (q.activo !== 'todos') { w.push('r.activo=?'); a.push(q.activo === '0' ? 0 : 1); }
    let items = db.prepare(SQL_REC + (w.length ? ' WHERE ' + w.join(' AND ') : '') + ' ORDER BY r.codigo').all(...a).map(REC);
    if (q.condicion) items = items.filter((i) => i.condicion === q.condicion);
    res.json({ items, categorias: db.prepare('SELECT id, nombre FROM categorias_recurso WHERE activo=1 ORDER BY nombre').all(),
      almacenes: db.prepare('SELECT id, codigo, nombre, ubicacion, activo FROM almacenes ORDER BY codigo').all() });
  });
  app.get('/api/recursos/:codigo', need('catalogo', 'r'), (req, res) => {
    const r = getRec(req.params.codigo);
    if (!r) return bad(res, 'Recurso no encontrado.', 404);
    const porAlm = db.prepare('SELECT a.id, a.codigo, a.nombre FROM almacenes a').all().map((a) => ({ ...a, existencias: existAlm(r.id, a.id), reservado: reservAlm(r.id, a.id) }))
      .map((a) => ({ ...a, disponible: r2(a.existencias - a.reservado) })).filter((a) => a.existencias || a.reservado);
    res.json({ item: REC(r), almacenes: porAlm,
      movimientos: db.prepare('SELECT m.fecha, m.tipo, m.cantidad, m.saldo_despues, m.motivo, m.referencia, m.usuario, a.nombre almacen FROM movimientos m JOIN almacenes a ON a.id=m.almacen_id WHERE m.recurso_id=? ORDER BY m.id DESC LIMIT 20').all(r.id),
      mantenimientos: db.prepare('SELECT m.id, m.tipo, m.estado, m.descripcion, m.fecha_inicio, m.fecha_fin, m.resultado, m.observaciones FROM mantenimientos m WHERE m.recurso_id=? ORDER BY m.id DESC').all(r.id),
      asignaciones: db.prepare("SELECT a.id, s.codigo solicitud, a.cantidad, a.estado, a.fecha_programada FROM asignaciones_recurso a JOIN solicitudes s ON s.id=a.solicitud_id WHERE a.recurso_id=? AND a.estado IN ('Reservada','Entregada') ORDER BY a.id DESC").all(r.id),
      historial: db.prepare('SELECT fecha t, actor, accion, resultado, antes, despues, detalle det FROM bitacora WHERE operacion=? ORDER BY id DESC LIMIT 50').all(r.codigo) });
  });
  app.post('/api/recursos', need('catalogo', 'c'), (req, res) => {
    const b = req.body, nombre = txt(b.nombre, 100), tipo = b.tipo || 'Material', desc = txt(b.descripcion, 300);
    const fail = (m, code = 400) => rechazar(req, res, 'recurso', 'nuevo', 'Crear recurso', m, code);
    if (nombre.length < 3) return fail('El nombre necesita al menos 3 caracteres.');
    if (!TIPOS_RECURSO.includes(tipo)) return fail('Elige el tipo de recurso: Material, Equipo o Vehículo.');
    const cat = db.prepare('SELECT * FROM categorias_recurso WHERE id=? AND activo=1').get(+b.categoria_id);
    if (!cat) return fail('Elige una categoría válida.');
    const unidad = tipo === 'Material' ? txt(b.unidad, 20) || 'unidad' : 'unidad', minimo = b.stock_minimo === undefined || b.stock_minimo === '' ? 0 : Number(b.stock_minimo);
    if (!(minimo >= 0) || !Number.isFinite(minimo)) return fail('El stock mínimo debe ser un número igual o mayor que 0.');
    let codigo = txt(b.codigo, 20).toUpperCase();
    if (codigo && !/^[A-Z0-9-]{3,20}$/.test(codigo)) return fail('El código solo admite letras, números y guiones (3 a 20 caracteres).');
    if (!codigo) codigo = siguiente('recursos', 'REC-');
    if (db.prepare('SELECT 1 FROM recursos WHERE codigo=?').get(codigo)) return fail('Ya existe un recurso con ese código.', 409);
    if (db.prepare('SELECT 1 FROM recursos WHERE nombre=? COLLATE NOCASE AND categoria_id=?').get(nombre, cat.id)) return fail('Ya existe un recurso con ese nombre en la categoría.', 409);
    const t = now(); db.prepare('INSERT INTO recursos(codigo,nombre,categoria_id,tipo,unidad,descripcion,stock_minimo,creado,actualizado) VALUES(?,?,?,?,?,?,?,?,?)').run(codigo, nombre, cat.id, tipo, unidad, desc, minimo, t, t);
    bit(req, 'recurso', codigo, 'Recurso creado', 'Exitoso', null, { nombre, categoria: cat.nombre, tipo, unidad }, '');
    res.status(201).json({ ok: true, codigo });
  });
  app.put('/api/recursos/:codigo', need('catalogo', 'u'), (req, res) => {
    const r = getRec(req.params.codigo);
    if (!r) return bad(res, 'Recurso no encontrado.', 404);
    const b = req.body, fail = (m, code = 400) => rechazar(req, res, 'recurso', r.codigo, 'Modificar recurso', m, code);
    const nombre = b.nombre === undefined ? r.nombre : txt(b.nombre, 100), desc = b.descripcion === undefined ? r.descripcion : txt(b.descripcion, 300);
    const catId = b.categoria_id === undefined ? r.categoria_id : +b.categoria_id, minimo = b.stock_minimo === undefined ? r.stock_minimo : Number(b.stock_minimo);
    const unidad = b.unidad === undefined || r.tipo !== 'Material' ? r.unidad : txt(b.unidad, 20);
    if (nombre.length < 3) return fail('El nombre necesita al menos 3 caracteres.');
    if (!db.prepare('SELECT 1 FROM categorias_recurso WHERE id=? AND activo=1').get(catId)) return fail('Elige una categoría válida.');
    if (!(minimo >= 0) || !Number.isFinite(minimo)) return fail('El stock mínimo debe ser un número igual o mayor que 0.');
    if (!unidad) return fail('Escribe la unidad de medida.');
    if (unidad !== r.unidad && db.prepare('SELECT 1 FROM movimientos WHERE recurso_id=?').get(r.id)) return fail('No se puede cambiar la unidad de un recurso que ya tiene movimientos.', 409);
    const dup = db.prepare('SELECT id FROM recursos WHERE nombre=? COLLATE NOCASE AND categoria_id=? AND id!=?').get(nombre, catId, r.id);
    if (dup) return fail('Ya existe un recurso con ese nombre en la categoría.', 409);
    const antes = { nombre: r.nombre, categoria_id: r.categoria_id, descripcion: r.descripcion, stock_minimo: r.stock_minimo, unidad: r.unidad }, despues = { nombre, categoria_id: catId, descripcion: desc, stock_minimo: minimo, unidad };
    if (JSON.stringify(antes) === JSON.stringify(despues)) return fail('No hay cambios que guardar.');
    db.prepare('UPDATE recursos SET nombre=?, categoria_id=?, descripcion=?, stock_minimo=?, unidad=?, actualizado=? WHERE id=?').run(nombre, catId, desc, minimo, unidad, now(), r.id);
    bit(req, 'recurso', r.codigo, 'Recurso modificado', 'Exitoso', antes, despues, '');
    res.json({ ok: true });
  });
  app.post('/api/recursos/:codigo/activo', need('catalogo', 'u'), (req, res) => { // desactivar sin borrar el historial
    const r = getRec(req.params.codigo);
    if (!r) return bad(res, 'Recurso no encontrado.', 404);
    const activo = req.body.activo ? 1 : 0, motivo = txt(req.body.motivo, 200), fail = (m, code = 409) => rechazar(req, res, 'recurso', r.codigo, activo ? 'Reactivar recurso' : 'Desactivar recurso', m, code);
    if (!!r.activo === !!activo) return fail(`El recurso ya está ${activo ? 'activo' : 'inactivo'}.`);
    if (!activo) {
      if (motivo.length < 5) return fail('Escribe el motivo de la desactivación (mínimo 5 caracteres).', 400);
      if (r.reservado > 0) return fail('No se puede desactivar: tiene reservas activas. Cancélalas o entrégalas primero.');
    }
    db.prepare('UPDATE recursos SET activo=?, actualizado=? WHERE id=?').run(activo, now(), r.id);
    bit(req, 'recurso', r.codigo, activo ? 'Recurso reactivado' : 'Recurso desactivado', 'Exitoso', { activo: !!r.activo }, { activo: !!activo }, motivo);
    res.json({ ok: true });
  });
  app.post('/api/categorias-recurso', need('catalogo', 'c'), (req, res) => {
    const n = txt(req.body.nombre, 60), fail = (m, code = 400) => rechazar(req, res, 'catalogo', 'categoria', 'Crear categoría', m, code);
    if (n.length < 3) return fail('El nombre necesita al menos 3 caracteres.');
    if (db.prepare('SELECT 1 FROM categorias_recurso WHERE nombre=?').get(n)) return fail('Esa categoría ya existe.', 409);
    const id = db.prepare('INSERT INTO categorias_recurso(nombre) VALUES(?)').run(n).lastInsertRowid;
    bit(req, 'catalogo', 'categoria', 'Categoría creada', 'Exitoso', null, { nombre: n }, '');
    res.status(201).json({ ok: true, id: Number(id), nombre: n });
  });
  // CRUD completo de categorías: consultar, modificar y eliminar (solo si no tiene recursos)
  app.get('/api/categorias-recurso', need('catalogo', 'r'), (req, res) =>
    res.json({ items: db.prepare('SELECT c.id, c.nombre, c.activo, (SELECT COUNT(*) FROM recursos r WHERE r.categoria_id=c.id) recursos FROM categorias_recurso c ORDER BY c.nombre').all() }));
  app.put('/api/categorias-recurso/:id', need('catalogo', 'u'), (req, res) => {
    const c = db.prepare('SELECT * FROM categorias_recurso WHERE id=?').get(+req.params.id), n = txt(req.body.nombre, 60);
    if (!c) return bad(res, 'Categoría no encontrada.', 404);
    const fail = (m, code = 400) => rechazar(req, res, 'catalogo', 'categoria', 'Modificar categoría', m, code);
    if (n.length < 3) return fail('El nombre necesita al menos 3 caracteres.');
    if (db.prepare('SELECT 1 FROM categorias_recurso WHERE nombre=? COLLATE NOCASE AND id!=?').get(n, c.id)) return fail('Esa categoría ya existe.', 409);
    db.prepare('UPDATE categorias_recurso SET nombre=? WHERE id=?').run(n, c.id);
    bit(req, 'catalogo', 'categoria', 'Categoría modificada', 'Exitoso', { nombre: c.nombre }, { nombre: n }, '');
    res.json({ ok: true, id: c.id, nombre: n });
  });
  app.delete('/api/categorias-recurso/:id', need('catalogo', 'd'), (req, res) => {
    const c = db.prepare('SELECT * FROM categorias_recurso WHERE id=?').get(+req.params.id);
    if (!c) return bad(res, 'Categoría no encontrada.', 404);
    if (db.prepare('SELECT 1 FROM recursos WHERE categoria_id=?').get(c.id)) return rechazar(req, res, 'catalogo', 'categoria', 'Eliminar categoría', 'No se puede eliminar: la categoría tiene recursos. Muévelos o desactívalos primero.', 409);
    db.prepare('DELETE FROM categorias_recurso WHERE id=?').run(c.id);
    bit(req, 'catalogo', 'categoria', 'Categoría eliminada', 'Exitoso', { nombre: c.nombre }, null, '');
    res.json({ ok: true });
  });
  app.post('/api/almacenes', need('catalogo', 'c'), (req, res) => {
    const n = txt(req.body.nombre, 80), u = txt(req.body.ubicacion, 120), fail = (m, code = 400) => rechazar(req, res, 'catalogo', 'almacen', 'Crear almacén', m, code);
    if (n.length < 3) return fail('El nombre necesita al menos 3 caracteres.');
    if (db.prepare('SELECT 1 FROM almacenes WHERE nombre=?').get(n)) return fail('Ese almacén ya existe.', 409);
    const codigo = 'ALM-' + String(db.prepare('SELECT COALESCE(MAX(id),0)+1 n FROM almacenes').get().n).padStart(2, '0');
    db.prepare('INSERT INTO almacenes(codigo,nombre,ubicacion) VALUES(?,?,?)').run(codigo, n, u);
    bit(req, 'catalogo', codigo, 'Almacén creado', 'Exitoso', null, { nombre: n, ubicacion: u }, '');
    res.status(201).json({ ok: true, codigo });
  });
  app.put('/api/almacenes/:id', need('catalogo', 'u'), (req, res) => {
    const a = db.prepare('SELECT * FROM almacenes WHERE id=?').get(+req.params.id), fail = (m, code = 409) => rechazar(req, res, 'catalogo', a ? a.codigo : 'almacen', 'Modificar almacén', m, code);
    if (!a) return bad(res, 'Almacén no encontrado.', 404);
    const n = req.body.nombre === undefined ? a.nombre : txt(req.body.nombre, 80), u = req.body.ubicacion === undefined ? a.ubicacion : txt(req.body.ubicacion, 120), act = req.body.activo === undefined ? a.activo : (req.body.activo ? 1 : 0);
    if (n.length < 3) return fail('El nombre necesita al menos 3 caracteres.', 400);
    const dup = db.prepare('SELECT id FROM almacenes WHERE nombre=? AND id!=?').get(n, a.id);
    if (dup) return fail('Ya existe un almacén con ese nombre.');
    if (!act && a.activo) {
      const stock = db.prepare('SELECT COALESCE(SUM(cantidad),0) s FROM movimientos WHERE almacen_id=?').get(a.id).s;
      if (stock > 0) return fail('No se puede desactivar: el almacén tiene existencias. Trasládalas primero.');
    }
    db.prepare('UPDATE almacenes SET nombre=?, ubicacion=?, activo=? WHERE id=?').run(n, u, act, a.id);
    bit(req, 'catalogo', a.codigo, 'Almacén modificado', 'Exitoso', { nombre: a.nombre, ubicacion: a.ubicacion, activo: !!a.activo }, { nombre: n, ubicacion: u, activo: !!act }, '');
    res.json({ ok: true });
  });

  // ---------- solicitudes ----------
  const SQL_SOL = `SELECT s.*, r.codigo rcodigo, r.nombre rnombre, r.unidad runidad, r.tipo rtipo, r.categoria_id rcat, u.nombre solicitante FROM solicitudes s
    LEFT JOIN recursos r ON r.id=s.recurso_id LEFT JOIN usuarios u ON u.id=s.solicitante_id`;
  const SOL = (s) => ({ codigo: s.codigo, solicitante: s.solicitante || '—', solicitante_id: s.solicitante_id, actividad: s.actividad, requerimiento: s.requerimiento,
    recurso: s.rcodigo ? { codigo: s.rcodigo, nombre: s.rnombre, unidad: s.runidad } : null, cantidad: s.cantidad, fecha_requerida: s.fecha_requerida, ubicacion: s.ubicacion,
    justificacion: s.justificacion, prioridad: s.prioridad, operacion: s.operacion_codigo, estado: s.estado, decision: s.decision_comentario, creado: s.creado, actualizado: s.actualizado,
    vencida: !SOL_TERMINAL.includes(s.estado) && s.fecha_requerida < now() });
  const getSol = (codigo) => db.prepare(SQL_SOL + ' WHERE s.codigo=?').get(txt(codigo, 20).toUpperCase());
  const ve = (u, s) => u.perms.solicitudes.u || u.perms.entregas.r || u.perms.planificacion.r || s.solicitante_id === u.id; // el personal logístico ve las solicitudes que atiende
  const asignado = (sid) => r2(db.prepare("SELECT COALESCE(SUM(cantidad),0) s FROM asignaciones_recurso WHERE solicitud_id=? AND estado!='Cancelada'").get(sid).s);

  app.get('/api/solicitudes', need('solicitudes', 'r'), (req, res) => {
    const q = req.query, w = [], a = [];
    if (!req.u.perms.solicitudes.u) { w.push('s.solicitante_id=?'); a.push(req.u.id); } // quien no gestiona ve solo las suyas
    if (SOL_ESTADOS.includes(q.estado)) { w.push('s.estado=?'); a.push(q.estado); }
    if (q.q) { const l = '%' + txt(q.q, 60) + '%'; w.push('(s.codigo LIKE ? OR s.actividad LIKE ? OR s.requerimiento LIKE ?)'); a.push(l, l, l); }
    const d = ms(q.desde), h = ms(q.hasta, true);
    if (d) { w.push('s.creado>=?'); a.push(d); } if (h) { w.push('s.creado<=?'); a.push(h); }
    const items = db.prepare(SQL_SOL + (w.length ? ' WHERE ' + w.join(' AND ') : '') + ' ORDER BY s.id DESC').all(...a).map(SOL);
    res.json({ items, porEstado: SOL_ESTADOS.map((e) => ({ estado: e, total: items.filter((i) => i.estado === e).length })) });
  });
  app.get('/api/solicitudes/:codigo', need('solicitudes', 'r'), (req, res) => {
    const s = getSol(req.params.codigo);
    if (!s) return bad(res, 'Solicitud no encontrada.', 404);
    if (!ve(req.u, s)) return bad(res, 'Solo puedes consultar tus propias solicitudes.', 403);
    const u = req.u, own = s.solicitante_id === u.id, com = !!u.perms.proveedores.r;
    const adv = []; if (s.recurso_id) { const r = getRec(s.rcodigo); if (r && s.cantidad > r.existencias - r.reservado && !SOL_TERMINAL.includes(s.estado)) adv.push(`La cantidad solicitada (${s.cantidad}) supera lo disponible hoy (${r2(r.existencias - r.reservado)}).`); }
    res.json({ item: SOL(s), advertencias: adv, asignado: asignado(s.id),
      puedeDecidir: s.estado === 'Pendiente' && !!u.perms.solicitudes.u && s.solicitante_id !== u.id,
      puedeCancelar: ['Pendiente', 'Aprobada', 'Planificada'].includes(s.estado) && ((own && ['Pendiente', 'Aprobada'].includes(s.estado)) || !!u.perms.solicitudes.u),
      puedeAsignar: !!u.perms.planificacion.c && ['Aprobada', 'Planificada', 'En ejecución'].includes(s.estado) && !!s.recurso_id,
      puedeRegistrarHito: !!u.perms.entregas.c && ['Planificada', 'En ejecución', 'Entregada'].includes(s.estado),
      puedeCerrar: !!u.perms.entregas.u && s.estado === 'Entregada',
      comentarios: db.prepare('SELECT usuario, texto, fecha FROM solicitud_comentarios WHERE solicitud_id=? ORDER BY id').all(s.id),
      asignaciones: db.prepare(`SELECT a.id, a.cantidad, a.estado, a.fecha_programada, a.ubicacion, a.con_conflicto, a.devuelta, r.codigo recurso, r.nombre rnombre, r.unidad, al.nombre almacen, al.id almacen_id, u.nombre responsable
        FROM asignaciones_recurso a JOIN recursos r ON r.id=a.recurso_id JOIN almacenes al ON al.id=a.almacen_id LEFT JOIN usuarios u ON u.id=a.responsable_id WHERE a.solicitud_id=? ORDER BY a.id`).all(s.id),
      hitos: db.prepare('SELECT h.id, h.tipo, h.fecha, h.nota, h.recibido_por, h.evidencia_nombre, (h.evidencia IS NOT NULL) tiene_evidencia, u.nombre responsable, h.asignacion_id FROM entregas_hitos h LEFT JOIN usuarios u ON u.id=h.responsable_id WHERE h.solicitud_id=? ORDER BY h.fecha, h.id').all(s.id),
      ordenes: db.prepare('SELECT o.codigo, o.estado, o.alcance, o.fecha_inicio, o.fecha_fin' + (com ? ', p.nombre proveedor, o.costo' : '') + ' FROM ordenes_servicio o JOIN proveedores p ON p.id=o.proveedor_id WHERE o.solicitud_id=? ORDER BY o.id').all(s.id),
      historial: db.prepare('SELECT fecha t, actor, accion, resultado, antes, despues, detalle det FROM bitacora WHERE operacion=? ORDER BY id DESC LIMIT 100').all(s.codigo) });
  });
  app.get('/api/solicitudes/:codigo/evidencia/:id', need('solicitudes', 'r'), (req, res) => {
    const s = getSol(req.params.codigo);
    if (!s) return bad(res, 'Solicitud no encontrada.', 404);
    if (!ve(req.u, s)) return bad(res, 'Solo puedes consultar tus propias solicitudes.', 403);
    const h = db.prepare('SELECT evidencia, evidencia_nombre FROM entregas_hitos WHERE id=? AND solicitud_id=? AND evidencia IS NOT NULL').get(+req.params.id, s.id);
    h ? res.json({ nombre: h.evidencia_nombre, evidencia: h.evidencia }) : bad(res, 'Evidencia no encontrada.', 404);
  });
  app.post('/api/solicitudes', need('solicitudes', 'c'), (req, res) => {
    const b = req.body, actividad = txt(b.actividad, 120), req_ = txt(b.requerimiento, 200), ub = txt(b.ubicacion, 150), just = txt(b.justificacion, 600), pri = PRIORIDADES.includes(b.prioridad) ? b.prioridad : 'Media';
    const fail = (m, code = 400) => rechazar(req, res, 'solicitud', 'nueva', 'Crear solicitud', m, code);
    if (actividad.length < 5) return fail('Describe la actividad (mínimo 5 caracteres).');
    if (req_.length < 5) return fail('Describe el requerimiento (mínimo 5 caracteres).');
    let recurso = null; const cant = Number(b.cantidad);
    if (b.recurso_codigo) {
      recurso = getRec(b.recurso_codigo);
      if (!recurso || !recurso.activo) return fail('El recurso elegido no existe o está inactivo.');
      if (recurso.estado === 'Fuera de servicio') return fail('Ese recurso está fuera de servicio y no se puede solicitar.', 409);
      if (!(cant > 0) || !Number.isFinite(cant)) return fail('La cantidad debe ser mayor que 0.');
      if (!entero(recurso.unidad, cant)) return fail(`La cantidad de ${recurso.unidad} debe ser un número entero.`);
      if (recurso.tipo !== 'Material' && cant !== 1) return fail('Los equipos y vehículos se solicitan de uno en uno.');
    } else if (!(cant > 0)) return fail('La cantidad debe ser mayor que 0.');
    const fr = fechaOk(b.fecha_requerida);
    if (fr === null) return fail('Indica la fecha en que se necesita.');
    if (fr < now() - 24 * HORA) return fail('La fecha requerida no puede estar en el pasado.');
    if (ub.length < 3) return fail('Indica la ubicación donde se necesita (mínimo 3 caracteres).');
    if (just.length < 10) return fail('Escribe la justificación (mínimo 10 caracteres).');
    const op = txt(b.operacion_codigo, 20).toUpperCase() || null;
    if (op && !db.prepare('SELECT 1 FROM operaciones WHERE codigo=?').get(op)) return fail('La operación vinculada no existe.');
    const codigo = siguiente('solicitudes', 'SOL-'), t = now(), adv = [];
    if (recurso && cant > recurso.existencias - recurso.reservado) adv.push(`La cantidad solicitada supera lo disponible hoy (${r2(recurso.existencias - recurso.reservado)} ${recurso.unidad}).`);
    db.transaction(() => {
      db.prepare('INSERT INTO solicitudes(codigo,solicitante_id,actividad,requerimiento,recurso_id,cantidad,fecha_requerida,ubicacion,justificacion,prioridad,operacion_codigo,creado,actualizado) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)')
        .run(codigo, req.u.id, actividad, req_, recurso ? recurso.id : null, cant, fr, ub, just, pri, op, t, t);
      bit(req, 'solicitud', codigo, 'Solicitud creada', 'Exitoso', null, { estado: 'Pendiente', recurso: recurso ? recurso.codigo : 'servicio', cantidad: cant, prioridad: pri }, actividad);
      usuariosCon('solicitudes', 'u', req.u.id).forEach((u) => notif(u.id, 'Solicitud', `Nueva solicitud logística ${codigo} pendiente de aprobación.`));
    })();
    res.status(201).json({ ok: true, codigo, advertencias: adv });
  });
  app.post('/api/solicitudes/:codigo/decision', need('solicitudes', 'u'), (req, res) => {
    const s = getSol(req.params.codigo);
    if (!s) return bad(res, 'Solicitud no encontrada.', 404);
    const dec = txt(req.body.decision, 20), com = txt(req.body.comentario, 300), fail = (m, code = 409) => rechazar(req, res, 'solicitud', s.codigo, `Decisión "${dec}"`, m, code);
    if (!['Aprobada', 'Rechazada'].includes(dec)) return fail('Decisión inválida.', 400);
    if (s.estado !== 'Pendiente') return fail(`La solicitud está "${s.estado}"; solo se decide sobre las pendientes.`);
    if (s.solicitante_id === req.u.id) return fail('No puedes decidir sobre tu propia solicitud.');
    if (dec === 'Rechazada' && com.length < 5) return fail('Escribe el motivo del rechazo (mínimo 5 caracteres).', 400);
    db.transaction(() => {
      db.prepare('UPDATE solicitudes SET estado=?, decision_comentario=?, decidido_por=?, actualizado=? WHERE id=?').run(dec, com || 'Aprobada.', req.u.id, now(), s.id);
      bit(req, 'solicitud', s.codigo, `Decisión: ${dec}`, 'Exitoso', { estado: 'Pendiente' }, { estado: dec }, com);
      notif(s.solicitante_id, 'Solicitud', `Tu solicitud ${s.codigo} fue ${dec.toLowerCase()}${com ? ': ' + com : '.'}`);
    })();
    res.json({ ok: true, estado: dec });
  });
  app.post('/api/solicitudes/:codigo/cancelar', need('solicitudes', 'r'), (req, res) => {
    const s = getSol(req.params.codigo);
    if (!s) return bad(res, 'Solicitud no encontrada.', 404);
    const motivo = txt(req.body.motivo, 300), fail = (m, code = 409) => rechazar(req, res, 'solicitud', s.codigo, 'Cancelar solicitud', m, code);
    const own = s.solicitante_id === req.u.id, gestiona = !!req.u.perms.solicitudes.u;
    if (!gestiona && !(own && ['Pendiente', 'Aprobada'].includes(s.estado))) return fail('Solo quien la creó (si aún no está planificada) o la coordinación puede cancelarla.', 403);
    if (!['Pendiente', 'Aprobada', 'Planificada'].includes(s.estado)) return fail(`No se puede cancelar una solicitud "${s.estado}".`);
    if (db.prepare("SELECT 1 FROM asignaciones_recurso WHERE solicitud_id=? AND estado='Entregada'").get(s.id)) return fail('Ya tiene entregas registradas.');
    if (motivo.length < 5) return fail('Escribe el motivo de la cancelación (mínimo 5 caracteres).', 400);
    db.transaction(() => {
      db.prepare("UPDATE asignaciones_recurso SET estado='Cancelada', actualizado=? WHERE solicitud_id=? AND estado='Reservada'").run(now(), s.id);
      db.prepare("UPDATE solicitudes SET estado='Cancelada', actualizado=? WHERE id=?").run(now(), s.id);
      bit(req, 'solicitud', s.codigo, 'Solicitud cancelada', 'Exitoso', { estado: s.estado }, { estado: 'Cancelada' }, motivo);
    })();
    res.json({ ok: true });
  });
  app.post('/api/solicitudes/:codigo/comentarios', need('solicitudes', 'r'), (req, res) => {
    const s = getSol(req.params.codigo), texto = txt(req.body.texto, 500);
    if (!s) return bad(res, 'Solicitud no encontrada.', 404);
    if (!ve(req.u, s)) return bad(res, 'Solo puedes comentar tus propias solicitudes.', 403);
    if (texto.length < 3) return bad(res, 'Escribe el comentario (mínimo 3 caracteres).');
    db.prepare('INSERT INTO solicitud_comentarios(solicitud_id,usuario,texto,fecha) VALUES(?,?,?,?)').run(s.id, req.u.nombre, texto, now());
    bit(req, 'solicitud', s.codigo, 'Comentario agregado', 'Exitoso', null, null, texto);
    if (s.solicitante_id !== req.u.id) notif(s.solicitante_id, 'Solicitud', `Nuevo comentario en tu solicitud ${s.codigo}.`);
    res.status(201).json({ ok: true });
  });
  app.post('/api/solicitudes/:codigo/cerrar', need('entregas', 'u'), (req, res) => {
    const s = getSol(req.params.codigo);
    if (!s) return bad(res, 'Solicitud no encontrada.', 404);
    const fail = (m, code = 409) => rechazar(req, res, 'solicitud', s.codigo, 'Cerrar solicitud', m, code);
    if (s.estado !== 'Entregada') return fail(`Solo se cierran solicitudes "Entregada" (esta está "${s.estado}").`);
    const faltan = [], ent = db.prepare("SELECT * FROM entregas_hitos WHERE solicitud_id=? AND tipo='Entrega'").all(s.id);
    if (!ent.length) faltan.push('la confirmación de entrega');
    else if (!ent.every((h) => h.recibido_por && h.fecha)) faltan.push('quién recibió y la fecha de entrega');
    if (cfg('evidenciaObligatoria') === '1' && !ent.some((h) => h.evidencia)) faltan.push('la evidencia de entrega');
    if (db.prepare("SELECT 1 FROM asignaciones_recurso WHERE solicitud_id=? AND estado='Reservada'").get(s.id)) faltan.push('entregar o cancelar las reservas pendientes');
    if (faltan.length) return fail('No se puede cerrar sin los datos mínimos: falta ' + faltan.join(', ') + '.');
    db.prepare("UPDATE solicitudes SET estado='Cerrada', actualizado=? WHERE id=?").run(now(), s.id);
    bit(req, 'solicitud', s.codigo, 'Solicitud cerrada', 'Exitoso', { estado: 'Entregada' }, { estado: 'Cerrada' }, '');
    notif(s.solicitante_id, 'Solicitud', `Tu solicitud ${s.codigo} se cerró.`);
    res.json({ ok: true });
  });

  // ---------- planificación y asignación ----------
  const responsableValido = (id) => {
    const r = db.prepare("SELECT u.id, u.nombre, u.rol_id FROM usuarios u JOIN roles r ON r.id=u.rol_id WHERE u.id=? AND u.estado='Activo' AND r.activo=1").get(+id);
    return r && permsOf(r.rol_id).entregas.c ? r : null;
  };
  const dia = (t) => new Date(t).toISOString().slice(0, 10);
  function evaluar(rec, aid, cant, fecha, excluir) { // bloqueos: no se puede; advertencias: se puede con confirmación
    const bloqueos = [], advertencias = [], alm = db.prepare('SELECT * FROM almacenes WHERE id=?').get(+aid);
    if (!rec.activo) bloqueos.push('El recurso está inactivo.');
    if (rec.estado === 'Fuera de servicio') bloqueos.push('El recurso está fuera de servicio y no se puede asignar.');
    if (!alm) bloqueos.push('Elige el almacén de origen.'); else if (!alm.activo) bloqueos.push('El almacén de origen está inactivo.');
    let existencias = 0, reservado = 0, disponible = 0;
    if (alm) {
      existencias = existAlm(rec.id, alm.id); reservado = reservAlm(rec.id, alm.id, excluir); disponible = r2(existencias - reservado);
      if (cant > disponible) advertencias.push(`En ${alm.nombre} solo hay ${disponible} ${rec.unidad} disponibles (existencias ${existencias}, reservado ${reservado}) y se asignarían ${cant}.`);
    }
    if (rec.estado === 'Mantenimiento') advertencias.push('El recurso está en mantenimiento.');
    if (rec.tipo !== 'Material' && fecha) {
      const otra = db.prepare("SELECT a.fecha_programada FROM asignaciones_recurso a WHERE a.recurso_id=? AND a.estado='Reservada' AND a.id!=?").all(rec.id, excluir || 0).some((x) => dia(x.fecha_programada) === dia(fecha));
      if (otra) advertencias.push('El recurso ya está reservado para esa misma fecha.');
    }
    return { bloqueos, advertencias, existencias, reservado, disponible };
  }
  app.get('/api/planificacion/pendientes', need('planificacion', 'r'), (req, res) => {
    const rows = db.prepare(SQL_SOL + " WHERE s.estado IN ('Aprobada','Planificada','En ejecución') ORDER BY s.fecha_requerida").all()
      .map((s) => ({ ...SOL(s), asignado: asignado(s.id), servicio: !s.recurso_id })).map((s) => ({ ...s, pendiente: s.servicio ? 0 : r2(s.cantidad - s.asignado) }))
      .filter((s) => s.servicio ? s.estado === 'Aprobada' : s.pendiente > 0);
    res.json({ items: rows, almacenes: db.prepare('SELECT id, codigo, nombre FROM almacenes WHERE activo=1 ORDER BY codigo').all() });
  });
  app.get('/api/logistica/responsables', need('planificacion', 'r'), (req, res) =>
    res.json({ items: db.prepare("SELECT u.id, u.nombre, r.nombre rol, r.id rol_id FROM usuarios u JOIN roles r ON r.id=u.rol_id WHERE u.estado='Activo' AND r.activo=1 ORDER BY u.nombre").all().filter((u) => permsOf(u.rol_id).entregas.c).map((u) => ({ id: u.id, nombre: u.nombre, rol: u.rol })) }));
  app.get('/api/planificacion/conflictos', need('planificacion', 'r'), (req, res) => {
    const rec = getRec(req.query.recurso);
    if (!rec) return bad(res, 'Recurso no encontrado.', 404);
    res.json(evaluar(rec, req.query.almacen, Number(req.query.cantidad) || 0, fechaOk(req.query.fecha), +req.query.excluir || 0));
  });
  app.get('/api/asignaciones-recurso', need('planificacion', 'r'), (req, res) => {
    const w = [], a = [];
    if (['Reservada', 'Entregada', 'Cancelada'].includes(req.query.estado)) { w.push('a.estado=?'); a.push(req.query.estado); }
    if (+req.query.responsable) { w.push('a.responsable_id=?'); a.push(+req.query.responsable); }
    res.json({ items: db.prepare(`SELECT a.id, s.codigo solicitud, r.codigo recurso, r.nombre rnombre, r.unidad, al.nombre almacen, a.cantidad, a.estado, a.fecha_programada, a.ubicacion, a.con_conflicto, u.nombre responsable
      FROM asignaciones_recurso a JOIN solicitudes s ON s.id=a.solicitud_id JOIN recursos r ON r.id=a.recurso_id JOIN almacenes al ON al.id=a.almacen_id LEFT JOIN usuarios u ON u.id=a.responsable_id ${w.length ? 'WHERE ' + w.join(' AND ') : ''} ORDER BY a.id DESC`).all(...a) });
  });
  app.post('/api/solicitudes/:codigo/asignar', need('planificacion', 'c'), (req, res) => {
    const s = getSol(req.params.codigo);
    if (!s) return bad(res, 'Solicitud no encontrada.', 404);
    const b = req.body, fail = (m, code = 409) => rechazar(req, res, 'solicitud', s.codigo, 'Asignar recurso', m, code);
    if (!s.recurso_id) return fail('Esta solicitud es de un servicio: se atiende con una orden de servicio, no con recursos.');
    if (!['Aprobada', 'Planificada', 'En ejecución'].includes(s.estado)) return fail(`Solo se asignan solicitudes aprobadas (esta está "${s.estado}").`);
    const cant = Number(b.cantidad), pend = r2(s.cantidad - asignado(s.id));
    if (!(cant > 0) || !Number.isFinite(cant)) return fail('La cantidad debe ser mayor que 0.', 400);
    if (!entero(s.runidad, cant)) return fail(`La cantidad de ${s.runidad} debe ser un número entero.`, 400);
    if (cant > pend) return fail(`Solo quedan ${pend} ${s.runidad} por asignar de esta solicitud.`);
    const resp = responsableValido(b.responsable_id);
    if (!resp) return fail('Elige un responsable activo con permiso para gestionar entregas.', 400);
    const fp = fechaOk(b.fecha_programada), ub = txt(b.ubicacion, 150) || s.ubicacion;
    if (fp === null) return fail('Indica la fecha programada.', 400);
    if (fp < now() - 24 * HORA) return fail('La fecha programada no puede estar en el pasado.', 400);
    const rec = getRec(s.rcodigo), ev = evaluar(rec, b.almacen_id, cant, fp, 0);
    if (ev.bloqueos.length) return fail(ev.bloqueos.join(' '));
    if (ev.advertencias.length && !b.forzar) {
      bit(req, 'solicitud', s.codigo, 'Asignar recurso', 'Rechazado', null, null, 'Conflictos de disponibilidad: ' + ev.advertencias.join(' '));
      return res.status(409).json({ error: 'Hay conflictos de disponibilidad. Confirma si quieres asignar de todos modos.', advertencias: ev.advertencias, requiereConfirmacion: true });
    }
    const t = now();
    const id = db.transaction(() => {
      const id = db.prepare('INSERT INTO asignaciones_recurso(solicitud_id,recurso_id,almacen_id,cantidad,responsable_id,fecha_programada,ubicacion,con_conflicto,creado_por,creado,actualizado) VALUES(?,?,?,?,?,?,?,?,?,?,?)')
        .run(s.id, rec.id, +b.almacen_id, cant, resp.id, fp, ub, ev.advertencias.length ? 1 : 0, req.u.id, t, t).lastInsertRowid;
      if (s.estado === 'Aprobada') db.prepare("UPDATE solicitudes SET estado='Planificada', actualizado=? WHERE id=?").run(t, s.id);
      bit(req, 'solicitud', s.codigo, 'Recurso asignado', 'Exitoso', null, { recurso: rec.codigo, cantidad: cant, responsable: resp.nombre, fecha: new Date(fp).toISOString().slice(0, 10) }, ev.advertencias.length ? 'Con conflicto confirmado: ' + ev.advertencias.join(' ') : '');
      notif(resp.id, 'Asignación logística', `Se te asignó la entrega de la solicitud ${s.codigo}.`);
      notif(s.solicitante_id, 'Solicitud', `Tu solicitud ${s.codigo} ya tiene recursos asignados.`);
      return id;
    })();
    res.status(201).json({ ok: true, id, conflicto: ev.advertencias.length > 0 });
  });
  const getAsg = (id) => db.prepare('SELECT a.*, s.codigo scodigo, s.estado sestado, s.solicitante_id, r.codigo rcodigo, r.tipo rtipo, r.nombre rnombre, r.unidad runidad, r.estado restado FROM asignaciones_recurso a JOIN solicitudes s ON s.id=a.solicitud_id JOIN recursos r ON r.id=a.recurso_id WHERE a.id=?').get(+id);
  app.put('/api/asignaciones-recurso/:id', need('planificacion', 'u'), (req, res) => {
    const a = getAsg(req.params.id);
    if (!a) return bad(res, 'Asignación no encontrada.', 404);
    const b = req.body, fail = (m, code = 409) => rechazar(req, res, 'solicitud', a.scodigo, 'Modificar asignación', m, code);
    if (a.estado !== 'Reservada') return fail(`Solo se modifican asignaciones reservadas (esta está "${a.estado}").`);
    let resp = a.responsable_id; if (b.responsable_id !== undefined) { const r = responsableValido(b.responsable_id); if (!r) return fail('Elige un responsable activo con permiso para gestionar entregas.', 400); resp = r.id; }
    let fp = a.fecha_programada; if (b.fecha_programada !== undefined) { fp = fechaOk(b.fecha_programada); if (fp === null) return fail('La fecha no es válida.', 400); if (fp < now() - 24 * HORA) return fail('La fecha programada no puede estar en el pasado.', 400); }
    const ub = b.ubicacion === undefined ? a.ubicacion : txt(b.ubicacion, 150);
    if (ub.length < 3) return fail('Indica la ubicación (mínimo 3 caracteres).', 400);
    const rec = getRec(a.rcodigo), ev = evaluar(rec, a.almacen_id, a.cantidad, fp, a.id);
    if (ev.bloqueos.length) return fail(ev.bloqueos.join(' '));
    if (ev.advertencias.length && !b.forzar && fp !== a.fecha_programada) return res.status(409).json({ error: 'Hay conflictos de disponibilidad con el cambio.', advertencias: ev.advertencias, requiereConfirmacion: true });
    const antes = { responsable_id: a.responsable_id, fecha: dia(a.fecha_programada), ubicacion: a.ubicacion }, despues = { responsable_id: resp, fecha: dia(fp), ubicacion: ub };
    if (JSON.stringify(antes) === JSON.stringify(despues)) return fail('No hay cambios que guardar.', 400);
    db.transaction(() => {
      db.prepare('UPDATE asignaciones_recurso SET responsable_id=?, fecha_programada=?, ubicacion=?, actualizado=? WHERE id=?').run(resp, fp, ub, now(), a.id);
      bit(req, 'solicitud', a.scodigo, 'Asignación modificada', 'Exitoso', antes, despues, txt(b.motivo, 200));
      if (resp !== a.responsable_id) notif(resp, 'Asignación logística', `Se te asignó la entrega de la solicitud ${a.scodigo}.`);
    })();
    res.json({ ok: true });
  });
  app.post('/api/asignaciones-recurso/:id/cancelar', need('planificacion', 'u'), (req, res) => {
    const a = getAsg(req.params.id), motivo = txt(req.body.motivo, 200);
    if (!a) return bad(res, 'Asignación no encontrada.', 404);
    const fail = (m, code = 409) => rechazar(req, res, 'solicitud', a.scodigo, 'Cancelar asignación', m, code);
    if (a.estado !== 'Reservada') return fail(`Solo se cancelan asignaciones reservadas (esta está "${a.estado}").`);
    if (motivo.length < 5) return fail('Escribe el motivo (mínimo 5 caracteres).', 400);
    db.transaction(() => {
      db.prepare("UPDATE asignaciones_recurso SET estado='Cancelada', actualizado=? WHERE id=?").run(now(), a.id);
      const quedan = db.prepare("SELECT 1 FROM asignaciones_recurso WHERE solicitud_id=? AND estado!='Cancelada'").get(a.solicitud_id);
      if (!quedan && a.sestado === 'Planificada') db.prepare("UPDATE solicitudes SET estado='Aprobada', actualizado=? WHERE id=?").run(now(), a.solicitud_id);
      bit(req, 'solicitud', a.scodigo, 'Asignación cancelada', 'Exitoso', { estado: 'Reservada' }, { estado: 'Cancelada' }, motivo);
    })();
    res.json({ ok: true });
  });

  // ---------- inventario ----------
  function filasExistencias(q) {
    const w = [], a = [];
    if (q.q) { const l = '%' + txt(q.q, 60) + '%'; w.push('(r.codigo LIKE ? OR r.nombre LIKE ?)'); a.push(l, l); }
    if (+q.categoria) { w.push('r.categoria_id=?'); a.push(+q.categoria); }
    if (+q.almacen) { w.push('al.id=?'); a.push(+q.almacen); }
    const rows = db.prepare(`SELECT r.codigo, r.nombre, r.unidad, r.tipo, r.estado, r.activo, r.stock_minimo, c.nombre categoria, al.id almacen_id, al.nombre almacen, SUM(m.cantidad) existencias,
      COALESCE((SELECT SUM(a2.cantidad) FROM asignaciones_recurso a2 WHERE a2.recurso_id=r.id AND a2.almacen_id=al.id AND a2.estado='Reservada'),0) reservado
      FROM movimientos m JOIN recursos r ON r.id=m.recurso_id JOIN almacenes al ON al.id=m.almacen_id JOIN categorias_recurso c ON c.id=r.categoria_id
      ${w.length ? 'WHERE ' + w.join(' AND ') : ''} GROUP BY r.id, al.id ORDER BY r.codigo, al.codigo`).all(...a)
      .map((x) => ({ ...x, existencias: r2(x.existencias), reservado: r2(x.reservado), disponible: r2(x.existencias - x.reservado), bajo_minimo: x.tipo === 'Material' && x.stock_minimo > 0 && x.existencias - x.reservado < x.stock_minimo }));
    return q.bajo === '1' ? rows.filter((x) => x.bajo_minimo) : rows;
  }
  function filasMovimientos(q) {
    const w = [], a = [];
    if (q.recurso) { w.push('r.codigo=?'); a.push(txt(q.recurso, 20).toUpperCase()); }
    if (+q.almacen) { w.push('m.almacen_id=?'); a.push(+q.almacen); }
    if (['Entrada', 'Salida', 'Devolución', 'Ajuste'].includes(q.tipo)) { w.push('m.tipo=?'); a.push(q.tipo); }
    if (q.usuario) { w.push('m.usuario LIKE ?'); a.push('%' + txt(q.usuario, 60) + '%'); }
    if (+q.categoria) { w.push('r.categoria_id=?'); a.push(+q.categoria); }
    const d = ms(q.desde), h = ms(q.hasta, true);
    if (d) { w.push('m.fecha>=?'); a.push(d); } if (h) { w.push('m.fecha<=?'); a.push(h); }
    return db.prepare(`SELECT m.id, m.fecha, m.tipo, m.cantidad, m.saldo_despues, m.motivo, m.referencia, m.usuario, r.codigo recurso, r.nombre rnombre, r.unidad, al.nombre almacen
      FROM movimientos m JOIN recursos r ON r.id=m.recurso_id JOIN almacenes al ON al.id=m.almacen_id ${w.length ? 'WHERE ' + w.join(' AND ') : ''} ORDER BY m.id DESC LIMIT 1000`).all(...a);
  }
  app.get('/api/inventario/existencias', need('inventario', 'r'), (req, res) => { res.json({ items: filasExistencias(req.query) }); });
  app.get('/api/inventario/movimientos', need('inventario', 'r'), (req, res) => res.json({ items: filasMovimientos(req.query).slice(0, 500) }));
  app.post('/api/inventario/movimientos', need('inventario', 'c'), (req, res) => {
    const b = req.body, tipo = txt(b.tipo, 20), motivo = txt(b.motivo, 200), rec = getRec(b.recurso_codigo), alm = db.prepare('SELECT * FROM almacenes WHERE id=?').get(+b.almacen_id);
    const fail = (m, code = 409) => rechazar(req, res, 'movimiento', rec ? rec.codigo : 'nuevo', `Registrar ${tipo || 'movimiento'}`, m, code);
    if (!['Entrada', 'Salida', 'Ajuste'].includes(tipo)) return fail('Elige el tipo de movimiento: Entrada, Salida o Ajuste.', 400);
    if (tipo === 'Ajuste' && !req.u.perms.inventario.u) { bit(req, 'movimiento', rec ? rec.codigo : 'nuevo', 'Registrar Ajuste', 'Rechazado', null, null, 'Sin permiso de ajustes'); return bad(res, 'Solo una persona autorizada puede registrar ajustes de inventario.', 403); }
    if (!rec || !rec.activo) return fail('El recurso no existe o está inactivo.', 400);
    if (!alm || !alm.activo) return fail('Elige un almacén activo.', 400);
    if (motivo.length < 5) return fail('Escribe el motivo (mínimo 5 caracteres).', 400);
    const q = Number(b.cantidad);
    if (!Number.isFinite(q) || q === 0 || Math.abs(q) > 1e6) return fail('La cantidad debe ser un número distinto de 0.', 400);
    if (tipo !== 'Ajuste' && q < 0) return fail('Escribe la cantidad en positivo; el tipo define si entra o sale.', 400);
    if (!entero(rec.unidad, q)) return fail(`La cantidad de ${rec.unidad} debe ser un número entero.`, 400);
    const delta = tipo === 'Salida' ? -Math.abs(q) : q, ex = existAlm(rec.id, alm.id), rs = reservAlm(rec.id, alm.id);
    if (delta > 0 && rec.tipo !== 'Material' && r2(rec.existencias + delta) > 1) return fail('Los equipos y vehículos se registran de uno en uno: ya existe la unidad en inventario.');
    if (tipo === 'Salida' && r2(ex + delta) < 0) return fail(`No hay existencias suficientes: en ${alm.nombre} hay ${ex} ${rec.unidad} y no se permiten saldos negativos.`);
    if (tipo === 'Salida' && r2(ex - rs + delta) < 0) return fail(`Solo hay ${r2(ex - rs)} ${rec.unidad} disponibles en ${alm.nombre}; el resto está reservado para solicitudes.`);
    if (tipo === 'Ajuste' && delta < 0 && r2(ex + delta) < rs) return fail(r2(ex + delta) < 0 ? `El ajuste dejaría el saldo en negativo (hay ${ex} ${rec.unidad}).` : `El ajuste dejaría menos existencias que lo reservado (${rs} ${rec.unidad}).`);
    const saldo = r2(ex + delta);
    db.transaction(() => {
      db.prepare('INSERT INTO movimientos(recurso_id,almacen_id,tipo,cantidad,saldo_despues,motivo,referencia,usuario_id,usuario,fecha) VALUES(?,?,?,?,?,?,?,?,?,?)').run(rec.id, alm.id, tipo, delta, saldo, motivo, null, req.u.id, req.u.nombre, now());
      bit(req, 'movimiento', rec.codigo, `${tipo} de inventario`, 'Exitoso', { saldo: ex }, { saldo, almacen: alm.nombre, cantidad: delta }, motivo);
    })();
    const disp = r2(rec.existencias + delta - rec.reservado);
    res.status(201).json({ ok: true, saldo, advertencia: rec.tipo === 'Material' && rec.stock_minimo > 0 && disp < rec.stock_minimo ? `Queda por debajo del stock mínimo (${rec.stock_minimo} ${rec.unidad}).` : null });
  });

  // ---------- entregas ----------
  app.get('/api/logistica/config', auth, (req, res) => res.json({ cfg: { evidenciaHabilitada: cfg('evidenciaHabilitada') === '1', evidenciaObligatoria: cfg('evidenciaObligatoria') === '1' } }));
  app.put('/api/logistica/config', need('entregas', 'u'), (req, res) => {
    const hab = req.body.evidenciaHabilitada ? '1' : '0', obl = req.body.evidenciaObligatoria ? '1' : '0';
    if (obl === '1' && hab === '0') return rechazar(req, res, 'config', 'evidencia', 'Configurar evidencia', 'La evidencia no puede ser obligatoria si no está habilitada.', 400);
    const antes = { habilitada: cfg('evidenciaHabilitada') === '1', obligatoria: cfg('evidenciaObligatoria') === '1' };
    db.prepare("UPDATE config SET valor=? WHERE clave='evidenciaHabilitada'").run(hab); db.prepare("UPDATE config SET valor=? WHERE clave='evidenciaObligatoria'").run(obl);
    bit(req, 'config', 'evidencia', 'Evidencia de entrega configurada', 'Exitoso', antes, { habilitada: hab === '1', obligatoria: obl === '1' }, '');
    res.json({ ok: true });
  });
  app.get('/api/entregas', need('entregas', 'r'), (req, res) => {
    const est = SOL_ESTADOS.includes(req.query.estado) ? req.query.estado : null;
    const rows = db.prepare(SQL_SOL + ` WHERE ${est ? 's.estado=?' : "s.estado IN ('Planificada','En ejecución','Entregada')"} ORDER BY s.fecha_requerida`).all(...(est ? [est] : []))
      .map((s) => ({ ...SOL(s), asignaciones: db.prepare("SELECT cantidad, estado FROM asignaciones_recurso WHERE solicitud_id=? AND estado!='Cancelada'").all(s.id),
        hitos: db.prepare('SELECT tipo, fecha FROM entregas_hitos WHERE solicitud_id=? ORDER BY fecha DESC, id DESC').all(s.id).slice(0, 3), n_hitos: db.prepare('SELECT COUNT(*) n FROM entregas_hitos WHERE solicitud_id=?').get(s.id).n,
        retrasos: db.prepare("SELECT COUNT(*) n FROM entregas_hitos WHERE solicitud_id=? AND tipo='Retraso'").get(s.id).n }));
    res.json({ items: rows });
  });
  app.post('/api/solicitudes/:codigo/hitos', need('entregas', 'c'), (req, res) => {
    const s = getSol(req.params.codigo);
    if (!s) return bad(res, 'Solicitud no encontrada.', 404);
    const b = req.body, tipo = txt(b.tipo, 20), nota = txt(b.nota, 400), recibido = txt(b.recibido_por, 80), fail = (m, code = 409) => rechazar(req, res, 'solicitud', s.codigo, `Hito "${tipo}"`, m, code);
    if (!HITOS.includes(tipo)) return fail('Tipo de hito inválido.', 400);
    if (!['Planificada', 'En ejecución', 'Entregada'].includes(s.estado)) return fail(`No se registran hitos en una solicitud "${s.estado}".`);
    if (tipo === 'Entrega' && s.estado === 'Entregada') return fail('La entrega de esta solicitud ya está registrada.');
    const f = b.fecha ? fechaOk(b.fecha) : now();
    if (f === null) return fail('La fecha no es válida.', 400);
    if (f > now() + HORA) return fail('La fecha del hito no puede estar en el futuro.', 400);
    if (['Retraso', 'Incidencia'].includes(tipo) && nota.length < 5) return fail(`Describe el ${tipo === 'Retraso' ? 'motivo del retraso' : 'incidente'} (mínimo 5 caracteres).`, 400);
    let evid = null, evNombre = null;
    if (b.evidencia) {
      if (cfg('evidenciaHabilitada') !== '1') return fail('La evidencia de entrega no está habilitada.', 400);
      if (typeof b.evidencia !== 'string' || !/^data:image\/(png|jpe?g|webp|gif);base64,/.test(b.evidencia) || b.evidencia.length > 220000) return fail('La evidencia debe ser una imagen de menos de 150 KB.', 400);
      evid = b.evidencia; evNombre = txt(b.evidencia_nombre, 80) || 'evidencia';
    }
    let asg = null;
    if (tipo === 'Entrega') {
      if (recibido.length < 3) return fail('Escribe quién recibió la entrega (mínimo 3 caracteres).', 400);
      if (cfg('evidenciaObligatoria') === '1' && !evid) return fail('La evidencia de entrega es obligatoria: adjunta una imagen.', 400);
      if (s.recurso_id) {
        asg = db.prepare('SELECT * FROM asignaciones_recurso WHERE id=? AND solicitud_id=?').get(+b.asignacion_id, s.id);
        if (!asg) return fail('Elige la asignación que se entrega.', 400);
        if (asg.estado !== 'Reservada') return fail(`Esa asignación está "${asg.estado}"; solo se entregan las reservadas.`);
        if (existAlm(asg.recurso_id, asg.almacen_id) < asg.cantidad) return fail('No hay existencias suficientes en el almacén para entregar (no se permiten saldos negativos).');
        const rec = db.prepare('SELECT * FROM recursos WHERE id=?').get(asg.recurso_id);
        if (rec.estado === 'Fuera de servicio') return fail('El recurso está fuera de servicio y no se puede entregar.');
      } else if (!db.prepare("SELECT 1 FROM ordenes_servicio WHERE solicitud_id=? AND estado IN ('En ejecución','Completada')").get(s.id)) return fail('Este servicio no tiene una orden de servicio en ejecución o completada.');
    } else if (b.asignacion_id) { asg = db.prepare('SELECT * FROM asignaciones_recurso WHERE id=? AND solicitud_id=?').get(+b.asignacion_id, s.id); if (!asg) return fail('La asignación no pertenece a esta solicitud.', 400); }
    let nuevoEstado = s.estado;
    db.transaction(() => {
      db.prepare('INSERT INTO entregas_hitos(solicitud_id,asignacion_id,tipo,fecha,responsable_id,nota,recibido_por,evidencia_nombre,evidencia,creado) VALUES(?,?,?,?,?,?,?,?,?,?)')
        .run(s.id, asg ? asg.id : null, tipo, f, req.u.id, nota, tipo === 'Entrega' ? recibido : null, evNombre, evid, now());
      if (['Preparación', 'Despacho', 'En tránsito'].includes(tipo) && s.estado === 'Planificada') nuevoEstado = 'En ejecución';
      if (tipo === 'Entrega') {
        if (asg) {
          const ex = existAlm(asg.recurso_id, asg.almacen_id);
          db.prepare('INSERT INTO movimientos(recurso_id,almacen_id,tipo,cantidad,saldo_despues,motivo,referencia,usuario_id,usuario,fecha) VALUES(?,?,?,?,?,?,?,?,?,?)')
            .run(asg.recurso_id, asg.almacen_id, 'Salida', -asg.cantidad, r2(ex - asg.cantidad), `Entrega de la solicitud ${s.codigo}`, s.codigo, req.u.id, req.u.nombre, now());
          db.prepare("UPDATE asignaciones_recurso SET estado='Entregada', actualizado=? WHERE id=?").run(now(), asg.id);
        }
        const pendReserv = db.prepare("SELECT 1 FROM asignaciones_recurso WHERE solicitud_id=? AND estado='Reservada'").get(s.id);
        const entregado = r2(db.prepare("SELECT COALESCE(SUM(cantidad),0) s FROM asignaciones_recurso WHERE solicitud_id=? AND estado='Entregada'").get(s.id).s);
        nuevoEstado = !s.recurso_id || (!pendReserv && entregado >= s.cantidad) ? 'Entregada' : 'En ejecución';
      }
      if (nuevoEstado !== s.estado) db.prepare('UPDATE solicitudes SET estado=?, actualizado=? WHERE id=?').run(nuevoEstado, now(), s.id);
      bit(req, 'solicitud', s.codigo, `Hito de entrega: ${tipo}`, 'Exitoso', nuevoEstado !== s.estado ? { estado: s.estado } : null, nuevoEstado !== s.estado ? { estado: nuevoEstado } : null, tipo === 'Entrega' ? `Recibió ${recibido}. ${nota}` : nota);
      if (['Retraso', 'Incidencia', 'Entrega'].includes(tipo)) notif(s.solicitante_id, 'Solicitud', `Solicitud ${s.codigo}: ${tipo === 'Entrega' ? 'entrega registrada' : tipo.toLowerCase() + ' registrado'}.`);
    })();
    res.status(201).json({ ok: true, estado: nuevoEstado });
  });

  // ---------- devoluciones y mantenimiento ----------
  const crearMant = (rec, tipo, desc, fecha, usuario) => db.prepare('INSERT INTO mantenimientos(recurso_id,tipo,estado,descripcion,fecha_inicio,responsable_id) VALUES(?,?,?,?,?,?)').run(rec.id, tipo, 'En curso', desc, fecha, usuario).lastInsertRowid;
  app.post('/api/asignaciones-recurso/:id/devolucion', need('mantenimiento', 'c'), (req, res) => {
    const a = getAsg(req.params.id);
    if (!a) return bad(res, 'Asignación no encontrada.', 404);
    const b = req.body, cant = Number(b.cantidad), cond = txt(b.condicion, 30), obs = txt(b.observaciones, 300), fail = (m, code = 409) => rechazar(req, res, 'solicitud', a.scodigo, 'Registrar devolución', m, code);
    if (a.estado !== 'Entregada') return fail(`Solo se devuelven asignaciones entregadas (esta está "${a.estado}").`);
    if (!CONDICIONES.includes(cond)) return fail('Elige la condición del recurso devuelto.', 400);
    const maxq = r2(a.cantidad - a.devuelta);
    if (!(cant > 0) || !Number.isFinite(cant)) return fail('La cantidad debe ser mayor que 0.', 400);
    if (!entero(a.runidad, cant)) return fail(`La cantidad de ${a.runidad} debe ser un número entero.`, 400);
    if (cant > maxq) return fail(`Solo se pueden devolver ${maxq} ${a.runidad} (entregado ${a.cantidad}, ya devuelto ${a.devuelta}).`);
    if (cond !== 'Buena' && obs.length < 5) return fail('Describe el estado del recurso devuelto en las observaciones (mínimo 5 caracteres).', 400);
    const f = b.fecha ? fechaOk(b.fecha) : now();
    if (f === null || f > now() + HORA) return fail('La fecha de devolución no es válida.', 400);
    const rec = getRec(a.rcodigo), msgs = [];
    db.transaction(() => {
      db.prepare('INSERT INTO devoluciones(asignacion_id,cantidad,condicion,observaciones,fecha,usuario_id) VALUES(?,?,?,?,?,?)').run(a.id, cant, cond, obs, f, req.u.id);
      db.prepare('UPDATE asignaciones_recurso SET devuelta=devuelta+?, actualizado=? WHERE id=?').run(cant, now(), a.id);
      let ex = existAlm(a.recurso_id, a.almacen_id);
      const mov = (tipo, q, motivo) => { ex = r2(ex + q); db.prepare('INSERT INTO movimientos(recurso_id,almacen_id,tipo,cantidad,saldo_despues,motivo,referencia,usuario_id,usuario,fecha) VALUES(?,?,?,?,?,?,?,?,?,?)').run(a.recurso_id, a.almacen_id, tipo, q, ex, motivo, a.scodigo, req.u.id, req.u.nombre, now()); };
      mov('Devolución', cant, `Devolución de la solicitud ${a.scodigo} (${cond})`);
      if (cond === 'Dañado') {
        mov('Ajuste', -cant, `Baja por daño en la devolución de ${a.scodigo}`);
        if (a.rtipo !== 'Material') { db.prepare("UPDATE recursos SET estado='Fuera de servicio', actualizado=? WHERE id=?").run(now(), a.recurso_id); msgs.push('El recurso quedó fuera de servicio.'); }
      } else if (cond === 'Requiere mantenimiento' && a.rtipo !== 'Material') {
        crearMant(rec, 'Correctivo', `Devolución de ${a.scodigo}: ${obs}`, f, req.u.id);
        db.prepare("UPDATE recursos SET estado='Mantenimiento', actualizado=? WHERE id=?").run(now(), a.recurso_id); msgs.push('Se inició un mantenimiento correctivo.');
      }
      bit(req, 'solicitud', a.scodigo, 'Devolución registrada', 'Exitoso', null, { recurso: a.rcodigo, cantidad: cant, condicion: cond }, obs);
      if (cond !== 'Buena') bit(req, 'recurso', a.rcodigo, 'Devolución con novedad', 'Exitoso', null, { condicion: cond }, obs);
    })();
    res.status(201).json({ ok: true, avisos: msgs });
  });
  const MANT = (m) => ({ id: m.id, recurso: m.rcodigo, rnombre: m.rnombre, tipo: m.tipo, estado: m.estado, descripcion: m.descripcion, fecha_inicio: m.fecha_inicio, fecha_fin: m.fecha_fin, resultado: m.resultado, observaciones: m.observaciones, responsable: m.responsable || '—' });
  const SQL_MANT = 'SELECT m.*, r.codigo rcodigo, r.nombre rnombre, u.nombre responsable FROM mantenimientos m JOIN recursos r ON r.id=m.recurso_id LEFT JOIN usuarios u ON u.id=m.responsable_id';
  app.get('/api/mantenimientos', need('mantenimiento', 'r'), (req, res) => {
    const w = [], a = [];
    if (['En curso', 'Finalizado'].includes(req.query.estado)) { w.push('m.estado=?'); a.push(req.query.estado); }
    if (req.query.recurso) { w.push('r.codigo=?'); a.push(txt(req.query.recurso, 20).toUpperCase()); }
    const devueltas = db.prepare(`SELECT d.id, d.cantidad, d.condicion, d.observaciones, d.fecha, s.codigo solicitud, r.codigo recurso, r.nombre rnombre FROM devoluciones d JOIN asignaciones_recurso a ON a.id=d.asignacion_id
      JOIN solicitudes s ON s.id=a.solicitud_id JOIN recursos r ON r.id=a.recurso_id ORDER BY d.id DESC LIMIT 30`).all();
    const entregadas = db.prepare(`SELECT a.id, s.codigo solicitud, r.codigo recurso, r.nombre rnombre, r.unidad, a.cantidad, a.devuelta FROM asignaciones_recurso a JOIN solicitudes s ON s.id=a.solicitud_id JOIN recursos r ON r.id=a.recurso_id
      WHERE a.estado='Entregada' AND a.cantidad>a.devuelta ORDER BY a.id DESC`).all();
    res.json({ items: db.prepare(SQL_MANT + (w.length ? ' WHERE ' + w.join(' AND ') : '') + ' ORDER BY m.id DESC').all(...a).map(MANT), devoluciones: devueltas, pendientesDevolucion: entregadas });
  });
  app.post('/api/mantenimientos', need('mantenimiento', 'c'), (req, res) => {
    const b = req.body, rec = getRec(b.recurso_codigo), tipo = txt(b.tipo, 20), desc = txt(b.descripcion, 300);
    const fail = (m, code = 409) => rechazar(req, res, 'recurso', rec ? rec.codigo : 'nuevo', 'Iniciar mantenimiento', m, code);
    if (!rec) return fail('Elige el recurso.', 400);
    if (!['Preventivo', 'Correctivo'].includes(tipo)) return fail('Elige el tipo: Preventivo o Correctivo.', 400);
    if (rec.tipo === 'Material') return fail('El mantenimiento aplica a equipos y vehículos, no a materiales.', 400);
    if (desc.length < 5) return fail('Describe el trabajo de mantenimiento (mínimo 5 caracteres).', 400);
    if (rec.estado !== 'Operativo') return fail(`El recurso está "${rec.estado}"; solo se inicia mantenimiento a recursos operativos.`);
    if (rec.reservado > 0) return fail('El recurso tiene reservas activas. Cancélalas o reprográmalas antes.');
    if (rec.en_uso > 0) return fail('El recurso está en uso (entregado y sin devolver).');
    const f = b.fecha_inicio ? fechaOk(b.fecha_inicio) : now();
    if (f === null || f > now() + HORA) return fail('La fecha de inicio no es válida.', 400);
    db.transaction(() => {
      crearMant(rec, tipo, desc, f, req.u.id);
      db.prepare("UPDATE recursos SET estado='Mantenimiento', actualizado=? WHERE id=?").run(now(), rec.id);
      bit(req, 'recurso', rec.codigo, 'Mantenimiento iniciado', 'Exitoso', { estado: 'Operativo' }, { estado: 'Mantenimiento', tipo }, desc);
    })();
    res.status(201).json({ ok: true });
  });
  app.post('/api/mantenimientos/:id/finalizar', need('mantenimiento', 'u'), (req, res) => {
    const m = db.prepare(SQL_MANT + ' WHERE m.id=?').get(+req.params.id);
    if (!m) return bad(res, 'Mantenimiento no encontrado.', 404);
    const resultado = txt(req.body.resultado, 30), obs = txt(req.body.observaciones, 300), fail = (c2, code = 409) => rechazar(req, res, 'recurso', m.rcodigo, 'Finalizar mantenimiento', c2, code);
    if (m.estado !== 'En curso') return fail('Este mantenimiento ya está finalizado.');
    if (!['Operativo', 'Fuera de servicio'].includes(resultado)) return fail('Indica el resultado: Operativo o Fuera de servicio.', 400);
    if (obs.length < 5) return fail('Escribe las observaciones del cierre (mínimo 5 caracteres).', 400);
    const ff = req.body.fecha_fin ? fechaOk(req.body.fecha_fin) : now();
    if (ff === null || ff > now() + HORA) return fail('La fecha de fin no es válida.', 400);
    if (ff < m.fecha_inicio) return fail('La fecha de fin no puede ser anterior al inicio.', 400);
    db.transaction(() => {
      db.prepare("UPDATE mantenimientos SET estado='Finalizado', fecha_fin=?, resultado=?, observaciones=? WHERE id=?").run(ff, resultado, obs, m.id);
      db.prepare('UPDATE recursos SET estado=?, actualizado=? WHERE id=?').run(resultado, now(), m.recurso_id);
      bit(req, 'recurso', m.rcodigo, 'Mantenimiento finalizado', 'Exitoso', { estado: 'Mantenimiento' }, { estado: resultado }, obs);
    })();
    res.json({ ok: true });
  });
  app.post('/api/recursos/:codigo/fuera-de-servicio', need('mantenimiento', 'u'), (req, res) => {
    const rec = getRec(req.params.codigo), motivo = txt(req.body.motivo, 200);
    if (!rec) return bad(res, 'Recurso no encontrado.', 404);
    const fail = (m, code = 409) => rechazar(req, res, 'recurso', rec.codigo, 'Declarar fuera de servicio', m, code);
    if (rec.estado === 'Fuera de servicio') return fail('El recurso ya está fuera de servicio.');
    if (motivo.length < 5) return fail('Escribe el motivo (mínimo 5 caracteres).', 400);
    if (rec.reservado > 0) return fail('El recurso tiene reservas activas. Cancélalas antes de declararlo fuera de servicio.');
    db.transaction(() => {
      db.prepare("UPDATE mantenimientos SET estado='Finalizado', fecha_fin=?, resultado='Fuera de servicio', observaciones=? WHERE recurso_id=? AND estado='En curso'").run(now(), motivo, rec.id);
      db.prepare("UPDATE recursos SET estado='Fuera de servicio', actualizado=? WHERE id=?").run(now(), rec.id);
      bit(req, 'recurso', rec.codigo, 'Recurso fuera de servicio', 'Exitoso', { estado: rec.estado }, { estado: 'Fuera de servicio' }, motivo);
    })();
    res.json({ ok: true });
  });
  app.post('/api/recursos/:codigo/reactivar', need('mantenimiento', 'u'), (req, res) => {
    const rec = getRec(req.params.codigo), motivo = txt(req.body.motivo, 200);
    if (!rec) return bad(res, 'Recurso no encontrado.', 404);
    const fail = (m, code = 409) => rechazar(req, res, 'recurso', rec.codigo, 'Reactivar recurso', m, code);
    if (rec.estado !== 'Fuera de servicio') return fail('Solo se reactivan recursos fuera de servicio.');
    if (motivo.length < 5) return fail('Escribe el motivo (mínimo 5 caracteres).', 400);
    db.prepare("UPDATE recursos SET estado='Operativo', actualizado=? WHERE id=?").run(now(), rec.id);
    bit(req, 'recurso', rec.codigo, 'Recurso reactivado', 'Exitoso', { estado: 'Fuera de servicio' }, { estado: 'Operativo' }, motivo);
    res.json({ ok: true });
  });

  // ---------- proveedores y órdenes de servicio (información comercial restringida por rol) ----------
  const PRV = (p) => ({ codigo: p.codigo, nombre: p.nombre, contacto: p.contacto, telefono: p.telefono, correo: p.correo, estado: p.estado, notas: p.notas });
  app.get('/api/proveedores', need('proveedores', 'r'), (req, res) => res.json({ items: db.prepare('SELECT * FROM proveedores ORDER BY codigo').all().map(PRV) }));
  function validarPrv(b, fail) {
    const nombre = txt(b.nombre, 100), correo = txt(b.correo, 120), tel = txt(b.telefono, 30);
    if (nombre.length < 3) return fail('El nombre necesita al menos 3 caracteres.');
    if (correo && !/^\S+@\S+\.\S+$/.test(correo)) return fail('El correo no es válido.');
    if (tel && !/^[0-9+()\- ]{7,30}$/.test(tel)) return fail('El teléfono no es válido.');
    return { nombre, correo, tel, contacto: txt(b.contacto, 80), notas: txt(b.notas, 300) };
  }
  app.post('/api/proveedores', need('proveedores', 'c'), (req, res) => {
    const fail = (m, code = 400) => { rechazar(req, res, 'proveedor', 'nuevo', 'Crear proveedor', m, code); return null; };
    const v = validarPrv(req.body, fail); if (!v) return;
    if (db.prepare('SELECT 1 FROM proveedores WHERE nombre=?').get(v.nombre)) { rechazar(req, res, 'proveedor', 'nuevo', 'Crear proveedor', 'Ya existe un proveedor con ese nombre.', 409); return; }
    const codigo = siguiente('proveedores', 'PRV-'), t = now();
    db.prepare('INSERT INTO proveedores(codigo,nombre,contacto,telefono,correo,notas,creado,actualizado) VALUES(?,?,?,?,?,?,?,?)').run(codigo, v.nombre, v.contacto, v.tel, v.correo, v.notas, t, t);
    bit(req, 'proveedor', codigo, 'Proveedor creado', 'Exitoso', null, { nombre: v.nombre }, '');
    res.status(201).json({ ok: true, codigo });
  });
  app.put('/api/proveedores/:codigo', need('proveedores', 'u'), (req, res) => {
    const p = db.prepare('SELECT * FROM proveedores WHERE codigo=?').get(txt(req.params.codigo, 20).toUpperCase());
    if (!p) return bad(res, 'Proveedor no encontrado.', 404);
    const fail = (m, code = 400) => { rechazar(req, res, 'proveedor', p.codigo, 'Modificar proveedor', m, code); return null; };
    const v = validarPrv({ ...p, ...req.body }, fail); if (!v) return;
    const estado = req.body.estado === undefined ? p.estado : req.body.estado;
    if (!['Activo', 'Inactivo'].includes(estado)) { fail('Estado inválido.'); return; }
    if (db.prepare('SELECT 1 FROM proveedores WHERE nombre=? AND id!=?').get(v.nombre, p.id)) { fail('Ya existe un proveedor con ese nombre.', 409); return; }
    if (estado === 'Inactivo' && p.estado === 'Activo' && db.prepare("SELECT 1 FROM ordenes_servicio WHERE proveedor_id=? AND estado IN ('Emitida','En ejecución')").get(p.id)) { fail('No se puede desactivar: tiene órdenes de servicio abiertas.', 409); return; }
    db.prepare('UPDATE proveedores SET nombre=?, contacto=?, telefono=?, correo=?, notas=?, estado=?, actualizado=? WHERE id=?').run(v.nombre, v.contacto, v.tel, v.correo, v.notas, estado, now(), p.id);
    bit(req, 'proveedor', p.codigo, 'Proveedor modificado', 'Exitoso', { nombre: p.nombre, estado: p.estado }, { nombre: v.nombre, estado }, '');
    res.json({ ok: true });
  });
  const ORD = (o) => ({ codigo: o.codigo, proveedor: o.pnombre, proveedor_codigo: o.pcodigo, solicitud: o.scodigo, alcance: o.alcance, fecha_inicio: o.fecha_inicio, fecha_fin: o.fecha_fin, costo: o.costo, estado: o.estado });
  const SQL_ORD = 'SELECT o.*, p.nombre pnombre, p.codigo pcodigo, s.codigo scodigo FROM ordenes_servicio o JOIN proveedores p ON p.id=o.proveedor_id JOIN solicitudes s ON s.id=o.solicitud_id';
  app.get('/api/ordenes-servicio', need('proveedores', 'r'), (req, res) => res.json({ items: db.prepare(SQL_ORD + ' ORDER BY o.id DESC').all().map(ORD) }));
  app.post('/api/ordenes-servicio', need('proveedores', 'c'), (req, res) => {
    const b = req.body, p = db.prepare('SELECT * FROM proveedores WHERE codigo=?').get(txt(b.proveedor_codigo, 20).toUpperCase()), s = getSol(b.solicitud_codigo), alcance = txt(b.alcance, 400);
    const fail = (m, code = 400) => rechazar(req, res, 'orden', 'nueva', 'Crear orden de servicio', m, code);
    if (!p) return fail('Elige el proveedor.');
    if (p.estado !== 'Activo') return fail('El proveedor está inactivo.', 409);
    if (!s) return fail('Elige la solicitud a la que se vincula la orden.');
    if (!['Aprobada', 'Planificada', 'En ejecución'].includes(s.estado)) return fail(`Solo se emiten órdenes para solicitudes aprobadas (esta está "${s.estado}").`, 409);
    if (alcance.length < 10) return fail('Describe el alcance (mínimo 10 caracteres).');
    const fi = b.fecha_inicio ? fechaOk(b.fecha_inicio) : null, ff = b.fecha_fin ? fechaOk(b.fecha_fin) : null;
    if ((b.fecha_inicio && fi === null) || (b.fecha_fin && ff === null)) return fail('Las fechas no son válidas.');
    if (fi && ff && ff < fi) return fail('La fecha de fin no puede ser anterior a la de inicio.');
    let costo = null; if (b.costo !== undefined && b.costo !== '' && b.costo !== null) { costo = Number(b.costo); if (!(costo >= 0) || !Number.isFinite(costo)) return fail('El costo debe ser un número igual o mayor que 0.'); }
    const codigo = siguiente('ordenes_servicio', 'ORD-'), t = now();
    db.transaction(() => {
      db.prepare('INSERT INTO ordenes_servicio(codigo,proveedor_id,solicitud_id,alcance,fecha_inicio,fecha_fin,costo,creado_por,creado,actualizado) VALUES(?,?,?,?,?,?,?,?,?,?)').run(codigo, p.id, s.id, alcance, fi, ff, costo, req.u.id, t, t);
      if (s.estado === 'Aprobada') db.prepare("UPDATE solicitudes SET estado='Planificada', actualizado=? WHERE id=?").run(t, s.id);
      bit(req, 'orden', codigo, 'Orden creada', 'Exitoso', null, { estado: 'Emitida', proveedor: p.nombre, solicitud: s.codigo }, alcance);
      bit(req, 'solicitud', s.codigo, 'Orden de servicio vinculada', 'Exitoso', null, { orden: codigo }, p.nombre);
    })();
    res.status(201).json({ ok: true, codigo });
  });
  app.post('/api/ordenes-servicio/:codigo/estado', need('proveedores', 'u'), (req, res) => {
    const o = db.prepare(SQL_ORD + ' WHERE o.codigo=?').get(txt(req.params.codigo, 20).toUpperCase()), nuevo = txt(req.body.estado, 20), motivo = txt(req.body.motivo, 200);
    if (!o) return bad(res, 'Orden no encontrada.', 404);
    const fail = (m, code = 409) => rechazar(req, res, 'orden', o.codigo, `Orden → ${nuevo}`, m, code);
    if (!(ORD_TRANS[o.estado] || []).includes(nuevo)) return fail(`Transición no permitida: ${o.estado} → ${nuevo}.`);
    if (nuevo === 'Cancelada' && motivo.length < 5) return fail('Escribe el motivo de la cancelación (mínimo 5 caracteres).', 400);
    db.prepare('UPDATE ordenes_servicio SET estado=?, actualizado=? WHERE id=?').run(nuevo, now(), o.id);
    bit(req, 'orden', o.codigo, 'Cambio de estado de la orden', 'Exitoso', { estado: o.estado }, { estado: nuevo }, motivo);
    res.json({ ok: true });
  });

  // ---------- indicadores y reportes ----------
  const pct = (a, b) => (b ? Math.round((a / b) * 1000) / 10 : null);
  const DEFINICIONES = {
    cumplimiento_fechas: { formula: 'Entregas realizadas en o antes de la fecha requerida ÷ solicitudes entregadas, en porcentaje.', fuente: 'solicitudes.fecha_requerida y la fecha del hito "Entrega" en entregas_hitos.' },
    solicitudes_atendidas: { formula: 'Solicitudes en estado Entregada o Cerrada ÷ solicitudes aprobadas o en etapas posteriores (se excluyen Pendiente, Rechazada y Cancelada), en porcentaje.', fuente: 'solicitudes.estado.' },
    utilizacion_activos: { formula: 'Equipos y vehículos operativos reservados o en uso ÷ equipos y vehículos operativos, en porcentaje, al momento de generar el reporte.', fuente: 'recursos, asignaciones_recurso (Reservada, o Entregada sin devolver).' },
    consumo_materiales: { formula: 'Suma de las salidas de inventario de materiales dentro del periodo.', fuente: 'movimientos con tipo Salida.' },
    retrasos_incidencias: { formula: 'Número de hitos "Retraso" e "Incidencia" registrados en las solicitudes del periodo.', fuente: 'entregas_hitos.' },
    stock_bajo: { formula: 'Materiales cuya cantidad disponible (existencias menos reservado) es menor que su stock mínimo, al momento de generar el reporte.', fuente: 'movimientos, asignaciones_recurso y recursos.stock_minimo.' } };
  function construirIndicadores(q) {
    const d = ms(q.desde), h = ms(q.hasta, true), cat = +q.categoria || 0, alm = +q.almacen || 0, resp = +q.responsable || 0;
    let sols = db.prepare(SQL_SOL).all().filter((s) => (!d || s.creado >= d) && (!h || s.creado <= h) && (!cat || s.rcat === cat));
    const asgs = db.prepare("SELECT * FROM asignaciones_recurso WHERE estado!='Cancelada'").all();
    if (alm) sols = sols.filter((s) => asgs.some((a) => a.solicitud_id === s.id && a.almacen_id === alm));
    if (resp) sols = sols.filter((s) => asgs.some((a) => a.solicitud_id === s.id && a.responsable_id === resp));
    const ids = new Set(sols.map((s) => s.id)), post = ['Aprobada', 'Planificada', 'En ejecución', 'Entregada', 'Cerrada'], atend = sols.filter((s) => ['Entregada', 'Cerrada'].includes(s.estado));
    const hitos = db.prepare('SELECT * FROM entregas_hitos').all().filter((x) => ids.has(x.solicitud_id));
    const fent = {}; hitos.filter((x) => x.tipo === 'Entrega').forEach((x) => (fent[x.solicitud_id] = Math.max(fent[x.solicitud_id] || 0, x.fecha)));
    const entregadas = atend.filter((s) => fent[s.id]), aTiempo = entregadas.filter((s) => fent[s.id] <= s.fecha_requerida);
    let activos = db.prepare(SQL_REC + " WHERE r.tipo!='Material' AND r.activo=1" + (cat ? ' AND r.categoria_id=' + cat : '')).all();
    if (alm) activos = activos.filter((r) => db.prepare('SELECT 1 FROM movimientos WHERE recurso_id=? AND almacen_id=?').get(r.id, alm));
    const operativos = activos.filter((r) => r.estado === 'Operativo'), usados = operativos.filter((r) => r.reservado > 0 || r.en_uso > 0);
    const mw = ["m.tipo='Salida'", "r.tipo='Material'"], ma = [];
    if (d) { mw.push('m.fecha>=?'); ma.push(d); } if (h) { mw.push('m.fecha<=?'); ma.push(h); } if (cat) { mw.push('r.categoria_id=?'); ma.push(cat); } if (alm) { mw.push('m.almacen_id=?'); ma.push(alm); }
    const consumo = db.prepare(`SELECT r.codigo, r.nombre, r.unidad, -SUM(m.cantidad) total FROM movimientos m JOIN recursos r ON r.id=m.recurso_id WHERE ${mw.join(' AND ')} GROUP BY r.id ORDER BY total DESC LIMIT 10`).all(...ma).map((x) => ({ ...x, total: r2(x.total) }));
    const materiales = db.prepare(SQL_REC + " WHERE r.tipo='Material' AND r.activo=1" + (cat ? ' AND r.categoria_id=' + cat : '')).all().map(REC);
    return {
      metricas: { solicitudes: sols.length, aprobadas_o_posteriores: sols.filter((s) => post.includes(s.estado)).length, atendidas: atend.length, solicitudes_atendidas_pct: pct(atend.length, sols.filter((s) => post.includes(s.estado)).length),
        entregas: entregadas.length, a_tiempo: aTiempo.length, cumplimiento_fechas_pct: pct(aTiempo.length, entregadas.length), retrasos: hitos.filter((x) => x.tipo === 'Retraso').length, incidencias: hitos.filter((x) => x.tipo === 'Incidencia').length,
        activos_operativos: operativos.length, activos_en_uso: usados.length, utilizacion_activos_pct: pct(usados.length, operativos.length), consumo_total: r2(consumo.reduce((a, x) => a + x.total, 0)), materiales_stock_bajo: materiales.filter((m) => m.bajo_minimo).length },
      por_estado: SOL_ESTADOS.map((e) => ({ nombre: e, total: sols.filter((s) => s.estado === e).length })).filter((x) => x.total),
      activos: activos.map((r) => ({ codigo: r.codigo, nombre: r.nombre, condicion: condicion(r) })), consumo, stock_bajo: materiales.filter((m) => m.bajo_minimo).map((m) => ({ codigo: m.codigo, nombre: m.nombre, unidad: m.unidad, disponible: m.disponible, minimo: m.stock_minimo })) };
  }
  const filtrosTxt = (q) => {
    const cat = +q.categoria ? (db.prepare('SELECT nombre FROM categorias_recurso WHERE id=?').get(+q.categoria) || {}).nombre : null, alm = +q.almacen ? (db.prepare('SELECT nombre FROM almacenes WHERE id=?').get(+q.almacen) || {}).nombre : null;
    const resp = +q.responsable ? (db.prepare('SELECT nombre FROM usuarios WHERE id=?').get(+q.responsable) || {}).nombre : null;
    return { periodo: `${ms(q.desde) ? q.desde : 'inicio'} a ${ms(q.hasta, true) ? q.hasta : 'hoy'}`, categoria: cat || 'Todas', ubicacion: alm || 'Todas', responsable: resp || 'Todos' };
  };
  app.get('/api/logistica/indicadores', need('indicadores', 'r'), (req, res) => {
    const r = construirIndicadores(req.query), f = filtrosTxt(req.query);
    bit(req, 'informe', 'logistica', 'Indicadores logísticos generados', 'Exitoso', null, f, `${r.metricas.solicitudes} solicitudes`);
    res.json({ ...r, filtros: f, definiciones: DEFINICIONES, generado: now(), generado_por: req.u.nombre,
      categorias: db.prepare('SELECT id, nombre FROM categorias_recurso WHERE activo=1 ORDER BY nombre').all(), almacenes: db.prepare('SELECT id, codigo, nombre FROM almacenes WHERE activo=1 ORDER BY codigo').all() });
  });
  const csv = (v) => { let s = String(v == null ? '' : v); if (/^[=+\-@]/.test(s)) s = "'" + s; return /[",\n;]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s; };
  const enviarCsv = (req, res, nombre, titulo, f, cab, filas) => {
    const t = new Date(), L = [titulo, `Generado,${csv(t.toISOString())}`, `Generado por,${csv(req.u.correo)}`, `Filtros,${csv(f)}`, '', cab.join(',')];
    filas.forEach((x) => L.push(x.map(csv).join(',')));
    bit(req, 'informe', 'logistica', `Reporte exportado (CSV): ${nombre}`, 'Exitoso', null, null, `${filas.length} filas`);
    res.set({ 'Content-Type': 'text/csv; charset=utf-8', 'Content-Disposition': `attachment; filename="${nombre}-${t.toISOString().slice(0, 10)}.csv"` }).send('\uFEFF' + L.join('\r\n'));
  };
  const iso = (t) => new Date(t).toISOString();
  app.get('/api/logistica/reportes/existencias', need('indicadores', 'r'), (req, res) => res.json({ items: filasExistencias(req.query), generado: now(), generado_por: req.u.nombre, filtros: filtrosTxt(req.query) }));
  app.get('/api/logistica/reportes/existencias/exportar', need('indicadores', 'c'), (req, res) => {
    const f = filtrosTxt(req.query), rows = filasExistencias(req.query);
    enviarCsv(req, res, 'existencias', 'Reporte de existencias - Agua Clara RD', `Categoria: ${f.categoria} | Almacen: ${f.ubicacion}`, ['Codigo', 'Recurso', 'Categoria', 'Almacen', 'Unidad', 'Existencias', 'Reservado', 'Disponible', 'Stock minimo', 'Bajo minimo'],
      rows.map((x) => [x.codigo, x.nombre, x.categoria, x.almacen, x.unidad, x.existencias, x.reservado, x.disponible, x.stock_minimo, x.bajo_minimo ? 'Sí' : 'No']));
  });
  app.get('/api/logistica/reportes/movimientos', need('indicadores', 'r'), (req, res) => res.json({ items: filasMovimientos(req.query).slice(0, 500), generado: now(), generado_por: req.u.nombre, filtros: filtrosTxt(req.query) }));
  app.get('/api/logistica/reportes/movimientos/exportar', need('indicadores', 'c'), (req, res) => {
    const f = filtrosTxt(req.query), rows = filasMovimientos(req.query);
    enviarCsv(req, res, 'movimientos', 'Reporte de movimientos de inventario - Agua Clara RD', `Periodo: ${f.periodo} | Categoria: ${f.categoria} | Tipo: ${req.query.tipo || 'Todos'}`, ['Fecha', 'Tipo', 'Recurso', 'Almacen', 'Cantidad', 'Saldo despues', 'Motivo', 'Referencia', 'Usuario'],
      rows.map((x) => [iso(x.fecha), x.tipo, `${x.recurso} ${x.rnombre}`, x.almacen, x.cantidad, x.saldo_despues, x.motivo, x.referencia, x.usuario]));
  });
};
