// Documentación Swagger/OpenAPI de la API de Agua Clara RD.
// La especificación se arma leyendo las rutas reales del código (método, ruta y permiso exigido), así nunca queda desactualizada.
const fs = require('fs'), path = require('path'), swaggerUi = require('swagger-ui-express');

const TAGS = { login: 'Sesión', logout: 'Sesión', me: 'Sesión', registro: 'Sesión', recuperar: 'Sesión', acceso: 'Sesión', perfil: 'Perfil', usuarios: 'Usuarios', roles: 'Roles y permisos', permisos: 'Roles y permisos',
  auditoria: 'Auditoría', config: 'Configuración', probar: 'Auditoría', reportes: 'Reportes ciudadanos', operaciones: 'Operaciones (Épica 2)', aprobaciones: 'Operaciones (Épica 2)', incidencias: 'Operaciones (Épica 2)', informes: 'Operaciones (Épica 2)',
  tipos: 'Operaciones (Épica 2)', alertas: 'Operaciones (Épica 2)', bitacora: 'Operaciones (Épica 2)', notificaciones: 'Operaciones (Épica 2)', responsables: 'Operaciones (Épica 2)',
  recursos: 'Catálogo (Épica 3)', 'categorias-recurso': 'Catálogo (Épica 3)', almacenes: 'Catálogo (Épica 3)', solicitudes: 'Solicitudes (Épica 3)', planificacion: 'Planificación (Épica 3)', 'asignaciones-recurso': 'Planificación (Épica 3)',
  inventario: 'Inventario (Épica 3)', entregas: 'Entregas (Épica 3)', mantenimientos: 'Mantenimiento (Épica 3)', proveedores: 'Proveedores (Épica 3)', 'ordenes-servicio': 'Proveedores (Épica 3)', logistica: 'Indicadores y reportes (Épica 3)', sistema: 'Sistema' };
const ACC = { c: 'crear', r: 'consultar', u: 'modificar', d: 'eliminar' };
const VERBO = { get: 'Consultar', post: 'Crear / ejecutar', put: 'Modificar', delete: 'Eliminar' };
// Ejemplos de cuerpo para las operaciones más usadas en la demostración
const EJ = {
  'post /api/login': { correo: 'super@aguaclara.do', clave: 'Demo123*' },
  'post /api/registro': { nombre: 'María Pérez', correo: 'maria@ejemplo.do', telefono: '809-555-1111', clave: 'MiClave123*' },
  'post /api/reportes': { tipo: 'Avería', municipio: 'Santo Domingo Este', sector: 'Los Mina', descripcion: 'Fuga de agua en la calle principal', contacto: '809-555-2222' },
  'post /api/categorias-recurso': { nombre: 'Equipos de bombeo' }, 'put /api/categorias-recurso/{id}': { nombre: 'Bombas y motores' },
  'post /api/recursos': { nombre: 'Tubería PVC 8 pulgadas', categoria_id: 3, tipo: 'Material', unidad: 'metro', stock_minimo: 20 },
  'put /api/recursos/{codigo}': { nombre: 'Tubería PVC 8 pulgadas', categoria_id: 3, stock_minimo: 30, descripcion: 'Para redes principales' },
  'post /api/solicitudes': { actividad: 'Reparación de fuga', requerimiento: 'Tubería para reparar', recurso_codigo: 'REC-0001', cantidad: 40, fecha_requerida: '2026-12-01', ubicacion: 'Los Mina', justificacion: 'Fuga grande que afecta a varios sectores', prioridad: 'Alta' },
  'post /api/solicitudes/{codigo}/decision': { decision: 'Aprobada', comentario: 'Aprobada para ejecución' },
  'post /api/solicitudes/{codigo}/asignar': { cantidad: 40, almacen_id: 1, responsable_id: 10, fecha_programada: '2026-12-02', forzar: false },
  'post /api/inventario/movimientos': { tipo: 'Entrada', recurso_codigo: 'REC-0001', almacen_id: 1, cantidad: 50, motivo: 'Compra de reposición' },
  'post /api/solicitudes/{codigo}/hitos': { tipo: 'Entrega', asignacion_id: 1, recibido_por: 'Juan Pérez' },
  'post /api/operaciones': { tipo_id: 1, titulo: 'Restablecer suministro en Los Mina', descripcion: 'Falta de agua desde hace dos días', prioridad: 'Alta' } };

function construir(db) {
  const dir = __dirname, paths = {};
  for (const f of fs.readdirSync(dir).filter((x) => x.endsWith('.js') && x !== 'openapi.js')) {
    const src = fs.readFileSync(path.join(dir, f), 'utf8');
    const re = /app\.(get|post|put|delete)\(\s*'(\/api[^']*)'\s*,\s*([^\n]*)/g; let m;
    while ((m = re.exec(src))) {
      const [, met, ruta, resto] = m, oa = ruta.replace(/:([A-Za-z_]+)/g, '{$1}'), seg = ruta.split('/')[2], need = /need\('(\w+)',\s*'(\w)'\)/.exec(resto), auth = /\bauth\b/.test(resto.split('(req')[0]);
      const params = [...oa.matchAll(/\{(\w+)\}/g)].map((x) => ({ name: x[1], in: 'path', required: true, schema: { type: x[1] === 'id' ? 'integer' : 'string' } }));
      const cuerpo = EJ[`${met} ${oa}`], protegido = !!need || auth;
      const op = { tags: [TAGS[seg] || 'Otros'], summary: `${VERBO[met]} ${oa.replace('/api/', '')}`,
        description: need ? `Requiere sesión y permiso **${need[1]}: ${ACC[need[2]]}**. Se valida en el servidor.` : auth ? 'Requiere sesión iniciada.' : 'Público: no requiere sesión.',
        parameters: params, responses: { 200: { description: 'Operación correcta' }, 400: { description: 'Datos inválidos o regla de negocio incumplida' }, ...(protegido ? { 401: { description: 'Sin sesión' }, 403: { description: 'Sin permiso para esta acción' } } : {}), 404: { description: 'No encontrado' }, 409: { description: 'Conflicto con el estado actual' } } };
      if (protegido) op.security = [{ cookieAuth: [] }];
      if (met !== 'get' && met !== 'delete') op.requestBody = { required: true, content: { 'application/json': { schema: { type: 'object' }, ...(cuerpo ? { example: cuerpo } : {}) } } };
      (paths[oa] = paths[oa] || {})[met] = op;
    }
  }
  return { openapi: '3.0.3',
    info: { title: 'API de Agua Clara RD', version: '4.1.0', description: 'API REST (Node.js + Express) conectada a una base de datos SQLite. **Cómo probar:** 1) en *Sesión → POST /api/login* pulsa «Try it out» con `super@aguaclara.do` / `Demo123*`; el navegador guarda la cookie de sesión `ac_sid`. 2) Prueba cualquier endpoint protegido. Cada operación indica el permiso que exige; sin sesión responde 401 y sin permiso 403. Todo cambio queda en la bitácora o la auditoría.' },
    servers: [{ url: '/' }], tags: [...new Set(Object.values(paths).flatMap((p) => Object.values(p).map((o) => o.tags[0])))].sort().map((name) => ({ name })),
    components: { securitySchemes: { cookieAuth: { type: 'apiKey', in: 'cookie', name: 'ac_sid' } } }, paths };
}

module.exports = function registrar(app, { db, need }) {
  const spec = construir(db);
  app.get('/api-docs.json', (req, res) => res.json(spec));
  app.use('/api-docs', swaggerUi.serve, swaggerUi.setup(spec, { customSiteTitle: 'API Agua Clara RD', swaggerOptions: { persistAuthorization: true } }));
  // Estado de la integración API ↔ base de datos (para comprobar en vivo que los datos salen de SQLite)
  app.get('/api/sistema/estado', need('auditoria', 'r'), (req, res) => {
    const tablas = db.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name").all().map((t) => ({ nombre: t.name, filas: db.prepare(`SELECT COUNT(*) n FROM "${t.name}"`).get().n }));
    res.json({ api: 'operativa', baseDatos: { motor: 'SQLite', archivo: path.basename(db.name || 'aguas-claras.db'), tablas, total_filas: tablas.reduce((a, t) => a + t.filas, 0) }, endpoints: Object.values(spec.paths).reduce((a, p) => a + Object.keys(p).length, 0), hora: Date.now() });
  });
};
