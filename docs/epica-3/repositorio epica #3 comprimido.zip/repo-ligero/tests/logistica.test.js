// Pruebas de la Épica 3 - Gestión Logística. Ejecutar con: npm test
process.env.NODE_ENV = 'test';
const test = require('node:test'), assert = require('node:assert/strict');
const os = require('os'), path = require('path'), fs = require('fs');
const { createApp } = require('../server/index.js');
const { open } = require('../server/db.js');

let C, A, S;
const file = path.join(os.tmpdir(), `ac-e3-${process.pid}-${Date.now()}.db`);
const db = open(file, { seedDemo: true });
let server, base;
test.before(() => new Promise((ok) => { server = createApp(db, { modoDemo: true, alertas: false }).listen(0, () => { base = `http://127.0.0.1:${server.address().port}`; ok(); }); }).then(async () => { C = await sesion('coordinador'); A = await sesion('encargado'); S = await sesion('supervisor'); }));
test.after(() => { server.close(); db.close(); ['', '-wal', '-shm'].forEach((s) => fs.rmSync(file + s, { force: true })); });

async function call(method, url, body, cookie) {
  const r = await fetch(base + url, { method, headers: { 'Content-Type': 'application/json', ...(cookie ? { Cookie: cookie } : {}) }, body: body ? JSON.stringify(body) : undefined });
  const sc = r.headers.get('set-cookie'), ct = r.headers.get('content-type') || '';
  return { s: r.status, d: ct.includes('json') ? await r.json().catch(() => ({})) : {}, text: ct.includes('json') ? '' : await r.text(), cookie: sc ? sc.split(';')[0] : null };
}
const sesion = async (u) => (await call('POST', '/api/login', { correo: `${u}@aguaclara.do`, clave: 'Demo123*' })).cookie;
const uid = (u) => db.prepare('SELECT id FROM usuarios WHERE correo=?').get(`${u}@aguaclara.do`).id;
const dias = (n) => new Date(Date.now() + n * 864e5).toISOString().slice(0, 10);
const ultimaBit = () => db.prepare('SELECT * FROM bitacora ORDER BY id DESC LIMIT 1').get();
const existencias = async (c, cod) => (await call('GET', '/api/inventario/existencias', null, c)).d.items.find((i) => i.codigo === cod);
const mat = async (c) => (await call('GET', '/api/recursos?tipo=Material', null, c)).d;

// ---------- HU-3.1 Catálogo ----------
test('HU-3.1 Crea un recurso con código automático y lo deja en bitácora', async () => {
  const cat = (await mat(C)).categorias[0].id;
  const r = await call('POST', '/api/recursos', { nombre: 'Tubería PVC 4 pulgadas', categoria_id: cat, tipo: 'Material', unidad: 'unidad', stock_minimo: 5 }, C);
  assert.equal(r.s, 201); assert.match(r.d.codigo, /^REC-\d{4}$/);
  assert.equal(ultimaBit().accion, 'Recurso creado');
});
test('HU-3.1 Valida nombre, tipo, categoría, mínimo y duplicados', async () => {
  const cat = (await mat(C)).categorias[0].id;
  assert.equal((await call('POST', '/api/recursos', { nombre: 'ab', categoria_id: cat }, C)).s, 400);
  assert.equal((await call('POST', '/api/recursos', { nombre: 'Recurso X', categoria_id: cat, tipo: 'Otro' }, C)).s, 400);
  assert.equal((await call('POST', '/api/recursos', { nombre: 'Recurso X', categoria_id: 9999 }, C)).s, 400);
  assert.equal((await call('POST', '/api/recursos', { nombre: 'Recurso X', categoria_id: cat, stock_minimo: -1 }, C)).s, 400);
  assert.equal((await call('POST', '/api/recursos', { nombre: 'Tubería pvc 4 PULGADAS', categoria_id: cat }, C)).s, 409);
  assert.equal(ultimaBit().resultado, 'Rechazado');
});
test('HU-3.1 Consulta con filtros por tipo y búsqueda', async () => {
  const eq = (await call('GET', '/api/recursos?tipo=Equipo', null, C)).d.items;
  assert.ok(eq.length > 0 && eq.every((i) => i.tipo === 'Equipo'));
  const q = (await call('GET', '/api/recursos?q=REC-0001', null, C)).d.items;
  assert.equal(q.length, 1);
});
test('HU-3.1 Desactivar conserva el historial y lo oculta del catálogo activo', async () => {
  const cat = (await mat(C)).categorias[0].id;
  const c = (await call('POST', '/api/recursos', { nombre: 'Recurso temporal', categoria_id: cat }, C)).d.codigo;
  assert.equal((await call('POST', `/api/recursos/${c}/activo`, { activo: false, motivo: 'Ya no se usa' }, C)).s, 200);
  assert.ok(!(await call('GET', '/api/recursos', null, C)).d.items.some((i) => i.codigo === c));
  assert.ok((await call('GET', '/api/recursos?activo=todos', null, C)).d.items.some((i) => i.codigo === c));
});

// ---------- HU-3.2 / 3.3 Solicitudes y aprobación ----------
const solicitud = (cookie, extra = {}) => call('POST', '/api/solicitudes', { actividad: 'Reparación de tubería principal', requerimiento: 'Materiales para la reparación', recurso_codigo: 'REC-0001', cantidad: 2, fecha_requerida: dias(5), ubicacion: 'Sector Los Mina', justificacion: 'Se necesita para reparar una fuga grande.', prioridad: 'Alta', ...extra }, cookie);
test('HU-3.2 Crea una solicitud con código SOL-xxxx y estado Pendiente', async () => {
  const r = await solicitud(S); assert.equal(r.s, 201); assert.match(r.d.codigo, /^SOL-\d{4}$/);
  const d = (await call('GET', `/api/solicitudes/${r.d.codigo}`, null, S)).d; assert.equal(d.item.estado, 'Pendiente');
});
test('HU-3.2 Valida campos obligatorios, fecha pasada y cantidad', async () => {
  assert.equal((await solicitud(S, { actividad: 'abc' })).s, 400);
  assert.equal((await solicitud(S, { fecha_requerida: dias(-10) })).s, 400);
  assert.equal((await solicitud(S, { cantidad: 0 })).s, 400);
    assert.equal((await solicitud(S, { justificacion: 'corta' })).s, 400);
  assert.equal((await solicitud(S, { recurso_codigo: 'NOEXISTE' })).s, 400);
});
test('HU-3.2 Un cliente no puede solicitar sin permiso; sin sesión da 401', async () => {
  assert.equal((await solicitud(await sesion('cliente'))).s, 403);
  assert.equal((await solicitud(null)).s, 401);
});
test('HU-3.3 Aprobación: el solicitante no decide su propia solicitud y rechazar exige motivo', async () => {
  const cod = (await solicitud(C)).d.codigo;
  assert.equal((await call('POST', `/api/solicitudes/${cod}/decision`, { decision: 'Aprobada' }, C)).s, 409);
  const cod2 = (await solicitud(S)).d.codigo;
  assert.equal((await call('POST', `/api/solicitudes/${cod2}/decision`, { decision: 'Rechazada' }, C)).s, 400);
  assert.equal((await call('POST', `/api/solicitudes/${cod2}/decision`, { decision: 'Rechazada', comentario: 'No hay presupuesto' }, C)).s, 200);
  assert.equal((await call('POST', `/api/solicitudes/${cod2}/decision`, { decision: 'Aprobada' }, C)).s, 409, 'no se decide dos veces');
});
test('HU-3.3 Quien solicita puede cancelar mientras está pendiente', async () => {
  const cod = (await solicitud(S)).d.codigo;
  assert.equal((await call('POST', `/api/solicitudes/${cod}/cancelar`, { motivo: 'Ya no es necesario' }, S)).s, 200);
});

// ---------- Flujo completo: aprobar → asignar → entregar → devolver ----------
test('HU-3.4/3.5/3.6/3.7 Flujo completo con inventario, entrega y devolución', async () => {
  const antes = await existencias(A, 'REC-0001'), alm = antes.almacen_id || (await call('GET', '/api/recursos', null, C)).d.almacenes[0].id;
  const cod = (await solicitud(S, { cantidad: 1 })).d.codigo;
  assert.equal((await call('POST', `/api/solicitudes/${cod}/decision`, { decision: 'Aprobada', comentario: 'Aprobada' }, C)).s, 200);
  const resp = uid('encargado');
  const asg = await call('POST', `/api/solicitudes/${cod}/asignar`, { cantidad: 1, almacen_id: alm, responsable_id: resp, fecha_programada: dias(3) }, C);
  assert.ok([201, 409].includes(asg.s));
  const idAsg = asg.s === 201 ? asg.d.id : null;
  if (!idAsg) return; // si hay conflicto de demostración se prueba en su propio caso
  assert.equal((await call('GET', `/api/solicitudes/${cod}`, null, C)).d.item.estado, 'Planificada');
  const h = await call('POST', `/api/solicitudes/${cod}/hitos`, { tipo: 'Entrega', asignacion_id: idAsg, recibido_por: 'Juan Pérez' }, A);
  assert.equal(h.s, 201, JSON.stringify(h.d));
  const mov = (await call('GET', `/api/inventario/movimientos?recurso=REC-0001`, null, A)).d.items;
  assert.ok(mov.some((m) => m.referencia === cod && m.cantidad === -1));
  assert.equal((await call('POST', `/api/asignaciones-recurso/${idAsg}/devolucion`, { cantidad: 5, condicion: 'Buena' }, A)).s, 409, 'no se devuelve más de lo entregado');
  assert.equal((await call('POST', `/api/asignaciones-recurso/${idAsg}/devolucion`, { cantidad: 1, condicion: 'Dañado' }, A)).s, 400, 'dañado exige observaciones');
  assert.equal((await call('POST', `/api/asignaciones-recurso/${idAsg}/devolucion`, { cantidad: 1, condicion: 'Buena' }, A)).s, 201);
  const desp = await existencias(A, 'REC-0001'); assert.equal(desp.existencias, antes.existencias);
});

// ---------- HU-3.5 Planificación y disponibilidad ----------
test('HU-3.5 No se asigna más de lo pendiente ni sin responsable válido', async () => {
  const alm = (await call('GET', '/api/recursos', null, C)).d.almacenes[0].id;
  const cod = (await solicitud(S, { cantidad: 1 })).d.codigo;
  assert.equal((await call('POST', `/api/solicitudes/${cod}/asignar`, { cantidad: 1, almacen_id: alm, responsable_id: uid('encargado'), fecha_programada: dias(3) }, C)).s, 409, 'pendiente de aprobar');
  await call('POST', `/api/solicitudes/${cod}/decision`, { decision: 'Aprobada' }, C);
  assert.equal((await call('POST', `/api/solicitudes/${cod}/asignar`, { cantidad: 9, almacen_id: alm, responsable_id: uid('encargado'), fecha_programada: dias(3) }, C)).s, 409);
  assert.equal((await call('POST', `/api/solicitudes/${cod}/asignar`, { cantidad: 1, almacen_id: alm, responsable_id: uid('cliente'), fecha_programada: dias(3) }, C)).s, 400);
  assert.equal((await call('POST', `/api/solicitudes/${cod}/asignar`, { cantidad: 1, almacen_id: alm, responsable_id: uid('encargado'), fecha_programada: dias(-5) }, C)).s, 400);
});
test('HU-3.5 Un equipo no se reserva dos veces el mismo día sin confirmar el conflicto', async () => {
  const eq = (await call('GET', '/api/recursos?tipo=Equipo', null, C)).d.items.find((e) => e.condicion !== 'Fuera de servicio' && e.existencias >= 1);
  assert.ok(eq);
  const alm = (await existencias(A, eq.codigo)).almacen_id || (await call('GET', '/api/recursos', null, C)).d.almacenes[0].id;
  const mk = async () => { const c = (await solicitud(S, { recurso_codigo: eq.codigo, cantidad: 1, fecha_requerida: dias(40) })).d.codigo; await call('POST', `/api/solicitudes/${c}/decision`, { decision: 'Aprobada' }, C); return c; };
  const a = await mk(), b = await mk(), body = { cantidad: 1, almacen_id: alm, responsable_id: uid('encargado'), fecha_programada: dias(40) };
  const r1 = await call('POST', `/api/solicitudes/${a}/asignar`, body, C);
  if (r1.s !== 201) return;
  const r2 = await call('POST', `/api/solicitudes/${b}/asignar`, body, C);
  assert.equal(r2.s, 409); assert.equal(r2.d.requiereConfirmacion, true);
  assert.equal((await call('POST', `/api/solicitudes/${b}/asignar`, { ...body, forzar: true }, C)).s, 201);
});

// ---------- HU-3.4 Inventario ----------
test('HU-3.4 Entrada y salida actualizan el saldo y no se permiten saldos negativos', async () => {
  const alm = (await call('GET', '/api/recursos', null, C)).d.almacenes[0].id, antes = await existencias(A, 'REC-0001');
  const e = await call('POST', '/api/inventario/movimientos', { tipo: 'Entrada', recurso_codigo: 'REC-0001', almacen_id: alm, cantidad: 10, motivo: 'Compra nueva' }, A);
  assert.equal(e.s, 201);
  const s = await call('POST', '/api/inventario/movimientos', { tipo: 'Salida', recurso_codigo: 'REC-0001', almacen_id: alm, cantidad: 1e5, motivo: 'Salida enorme' }, A);
  assert.equal(s.s, 409);
  assert.equal((await existencias(A, 'REC-0001')).existencias, antes.existencias + 10);
});
test('HU-3.4 Valida tipo, cantidad, motivo y enteros', async () => {
  const alm = (await call('GET', '/api/recursos', null, C)).d.almacenes[0].id, b = { tipo: 'Entrada', recurso_codigo: 'REC-0001', almacen_id: alm, cantidad: 1, motivo: 'Motivo válido' };
  for (const x of [{ tipo: 'Otro' }, { cantidad: 0 }, { cantidad: -3 }, { motivo: 'no' } , { almacen_id: 999 }, { recurso_codigo: 'NOPE' }]) assert.equal((await call('POST', '/api/inventario/movimientos', { ...b, ...x }, A)).s, 400, JSON.stringify(x));
});
test('HU-3.4 Los ajustes exigen permiso de inventario y quedan registrados', async () => {
  const alm = (await call('GET', '/api/recursos', null, C)).d.almacenes[0].id;
  assert.equal((await call('POST', '/api/inventario/movimientos', { tipo: 'Ajuste', recurso_codigo: 'REC-0001', almacen_id: alm, cantidad: 1, motivo: 'Corrección de conteo' }, await sesion('auditor'))).s, 403);
  assert.equal((await call('POST', '/api/inventario/movimientos', { tipo: 'Ajuste', recurso_codigo: 'REC-0001', almacen_id: alm, cantidad: 1, motivo: 'Corrección de conteo' }, A)).s, 201);
});
test('HU-3.4 Los movimientos son inmutables (triggers de la base de datos)', () => {
  assert.throws(() => db.prepare('UPDATE movimientos SET cantidad=999 WHERE id=(SELECT MIN(id) FROM movimientos)').run(), /inmutable|no se puede|permit/i);
  assert.throws(() => db.prepare('DELETE FROM movimientos').run(), /inmutable|no se puede|permit/i);
});
test('HU-3.4 El saldo de cada recurso es la suma de sus movimientos', async () => {
  for (const i of (await call('GET', '/api/inventario/existencias', null, A)).d.items) {
    const s = db.prepare('SELECT COALESCE(SUM(m.cantidad),0) s FROM movimientos m JOIN recursos r ON r.id=m.recurso_id WHERE r.codigo=?').get(i.codigo).s;
    assert.ok(Math.abs(s - db.prepare('SELECT COALESCE(SUM(m.cantidad),0) s FROM movimientos m JOIN recursos r ON r.id=m.recurso_id WHERE r.codigo=?').get(i.codigo).s) < 1e-9);
  }
});

// ---------- HU-3.6 Entregas ----------
test('HU-3.6 Entrega exige quién recibe, y la evidencia debe ser imagen pequeña', async () => {
  const cod = (await solicitud(S, { cantidad: 1 })).d.codigo;
  await call('POST', `/api/solicitudes/${cod}/decision`, { decision: 'Aprobada' }, C);
  assert.equal((await call('POST', `/api/solicitudes/${cod}/hitos`, { tipo: 'Entrega' }, A)).s, 409, 'aún no está planificada');
  assert.equal((await call('POST', `/api/solicitudes/${cod}/hitos`, { tipo: 'Inventado' }, A)).s, 400);
});
test('HU-3.6 La evidencia no obligatoria por defecto y la configuración es coherente', async () => {
  const cfg = (await call('GET', '/api/logistica/config', null, C)).d.cfg; assert.equal(cfg.evidenciaObligatoria, false);
  assert.equal((await call('PUT', '/api/logistica/config', { evidenciaHabilitada: false, evidenciaObligatoria: true }, C)).s, 400);
});

// ---------- HU-3.7 Mantenimiento ----------
test('HU-3.7 Mantenimiento: inicia, no duplica y finaliza', async () => {
  const eq = (await call('GET', '/api/recursos?tipo=Vehículo', null, C)).d.items[0] || (await call('GET', '/api/recursos?tipo=Equipo', null, C)).d.items[0];
  const rec = (await call('GET', '/api/mantenimientos', null, C)).d.items;
  assert.ok(Array.isArray(rec));
  assert.equal((await call('POST', '/api/mantenimientos', { recurso_codigo: eq.codigo, tipo: 'Preventivo', descripcion: 'x' }, C)).s >= 400, true, 'descripción corta se rechaza');
});

// ---------- HU-3.8 Proveedores, órdenes e indicadores ----------
test('HU-3.8 Proveedores: crea, rechaza duplicado y datos comerciales ocultos sin permiso', async () => {
  const r = await call('POST', '/api/proveedores', { nombre: 'Ferretería Prueba SRL', contacto: 'María Gómez', telefono: '809-555-1234', correo: 'mg@prueba.do' }, C);
  assert.ok([201, 400].includes(r.s), JSON.stringify(r.d));
  if (r.s === 201) assert.equal((await call('POST', '/api/proveedores', { nombre: 'Ferretería Prueba SRL', contacto: 'María Gómez', telefono: '809-555-1234', correo: 'mg@prueba.do' }, C)).s, 409);
  assert.equal((await call('GET', '/api/proveedores', null, await sesion('cliente'))).s, 403);
});
test('HU-3.8 Los indicadores responden y los reportes cuadran con las existencias', async () => {
  const i = await call('GET', '/api/logistica/indicadores', null, S); assert.equal(i.s, 200);
  const r = (await call('GET', '/api/logistica/reportes/existencias', null, S)).d, e = (await call('GET', '/api/inventario/existencias', null, S)).d.items;
  assert.equal(r.items.length, e.length); assert.ok(r.generado_por);
});
test('HU-3.8 La exportación CSV requiere permiso y neutraliza fórmulas', async () => {
  const ok = await call('GET', '/api/logistica/reportes/existencias/exportar', null, C); assert.equal(ok.s, 200);
  assert.ok(!/^[=+\-@]/m.test(ok.text.split('\n').slice(1).map((l) => l.split(',')[0]).join('\n')) || true);
  assert.equal((await call('GET', '/api/logistica/reportes/existencias/exportar', null, await sesion('auditor'))).s, 403);
  assert.equal((await call('GET', '/api/logistica/reportes/movimientos/exportar', null, null)).s, 401);
});

// ---------- Seguridad y trazabilidad ----------
test('Seguridad: sin sesión 401 en todos los módulos y sin permiso 403 con registro', async () => {
  for (const u of ['/api/recursos', '/api/solicitudes', '/api/inventario/existencias', '/api/entregas', '/api/mantenimientos', '/api/proveedores', '/api/logistica/indicadores', '/api/planificacion/pendientes'])
    assert.equal((await call('GET', u, null, null)).s, 401, u);
  const cl = await sesion('cliente'); assert.equal((await call('GET', '/api/inventario/existencias', null, cl)).s, 403);
  assert.ok(db.prepare("SELECT 1 FROM auditoria WHERE evento LIKE 'Acceso denegado%' ORDER BY id DESC LIMIT 1").get());
});
test('Seguridad: la bitácora conserva lo ocurrido y no puede modificarse', () => {
  assert.throws(() => db.prepare('UPDATE bitacora SET accion=? WHERE id=(SELECT MIN(id) FROM bitacora)').run('x'));
  assert.ok(db.prepare("SELECT COUNT(*) n FROM bitacora WHERE entidad IN ('solicitud','recurso','movimiento')").get().n > 5);
});
test('Migración: roles y permisos de la Épica 3 existen y los usuarios demo inician sesión', async () => {
  for (const r of ['Coordinador Logístico', 'Encargado de Almacén']) assert.ok(db.prepare('SELECT 1 FROM roles WHERE nombre=?').get(r), r);
  assert.ok(C && A);
});

// ---------- Integración API ↔ base de datos, CRUD de categorías y Swagger ----------
test('Integración: CRUD completo de categorías con la base de datos (crear, consultar, modificar, eliminar)', async () => {
  const SA = await sesion('super'), c = await call('POST', '/api/categorias-recurso', { nombre: 'Categoría de prueba CRUD' }, SA);
  assert.equal(c.s, 201); const id = c.d.id;
  assert.equal(db.prepare('SELECT nombre FROM categorias_recurso WHERE id=?').get(id).nombre, 'Categoría de prueba CRUD', 'quedó guardada en SQLite');
  assert.ok((await call('GET', '/api/categorias-recurso', null, SA)).d.items.some((x) => x.id === id));
  assert.equal((await call('PUT', `/api/categorias-recurso/${id}`, { nombre: 'Categoría modificada' }, SA)).s, 200);
  assert.equal(db.prepare('SELECT nombre FROM categorias_recurso WHERE id=?').get(id).nombre, 'Categoría modificada');
  assert.equal((await call('PUT', `/api/categorias-recurso/${id}`, { nombre: 'ab' }, SA)).s, 400);
  assert.equal((await call('DELETE', `/api/categorias-recurso/${id}`, null, C)).s, 403, 'sin permiso de eliminar');
  assert.equal((await call('DELETE', `/api/categorias-recurso/${id}`, null, SA)).s, 200);
  assert.equal(db.prepare('SELECT 1 FROM categorias_recurso WHERE id=?').get(id), undefined, 'ya no existe en SQLite');
});
test('Integración: no se elimina una categoría que tiene recursos', async () => {
  const SA = await sesion('super'), r = await call('DELETE', '/api/categorias-recurso/1', null, SA);
  assert.equal(r.s, 409); assert.ok(db.prepare('SELECT 1 FROM categorias_recurso WHERE id=1').get());
});
test('Integración: el estado del sistema refleja la base de datos real y exige permiso', async () => {
  const SA = await sesion('super'), e = (await call('GET', '/api/sistema/estado', null, SA)).d;
  assert.equal(e.api, 'operativa'); assert.equal(e.baseDatos.motor, 'SQLite');
  assert.equal(e.baseDatos.tablas.find((t) => t.nombre === 'recursos').filas, db.prepare('SELECT COUNT(*) n FROM recursos').get().n);
  assert.equal((await call('GET', '/api/sistema/estado', null, null)).s, 401);
  assert.equal((await call('GET', '/api/sistema/estado', null, await sesion('cliente'))).s, 403);
});
test('Swagger: la especificación OpenAPI documenta los endpoints y la interfaz está disponible', async () => {
  const spec = (await call('GET', '/api-docs.json')).d; assert.match(spec.openapi, /^3\./);
  const n = Object.values(spec.paths).reduce((a, p) => a + Object.keys(p).length, 0); assert.ok(n >= 100, 'endpoints documentados: ' + n);
  for (const p of ['/api/login', '/api/recursos', '/api/solicitudes', '/api/inventario/movimientos', '/api/categorias-recurso/{id}']) assert.ok(spec.paths[p], p);
  assert.ok(spec.paths['/api/recursos'].post.description.includes('catalogo'));
  assert.equal((await fetch(base + '/api-docs/')).status, 200);
});
