# Cambios

## Rediseño UX/UI · rama mejora-diseno-ux-ui
- Nuevo sistema visual (tokens, componentes, temas claro/oscuro/automático).
- Portal ciudadano: inicio con consulta rápida, pasos y tipos de problema; pie de página con enlaces.
- Panel: navegación lateral semántica, tablas con encabezado fijo en estilo, estados con color.
- Confirmación accesible antes de eliminar, cancelar, anular o desactivar; estados de carga y prevención de doble envío.
- Accesibilidad: enlace «Saltar al contenido», foco visible, errores asociados a su campo, reducir movimiento, objetivos táctiles de 46 px en móvil.
- Pruebas: corregida una comparación de fecha en la prueba HU-2.8 (usaba UTC); añadida `tests/ui-smoke.js` (opcional).
- Sin cambios en `server/`, `database/` ni en las reglas de permisos.

## v4.2-observaciones
Swagger en /api-docs, panel de integración API–BD con CRUD, interfaz sin íconos decorativos y alcance definido.

## v4.0-epica3
Gestión logística: HU-3.1 a HU-3.8.

## Acerca de Agua Clara RD (rediseño)
- Nuevo video explicativo (71 s, narración en español, subtítulos WebVTT, sin autoplay) en `public/media/`.
- Reproductor con póster, botón central, controles nativos, pantalla completa, subtítulos y transcripción.
- Tarjetas existentes con íconos y hover (contenido intacto) y sección «Desarrollado por el Grupo 6» con espacio para integrantes (`INTEGRANTES` en `public/js/app.js`).

## v4.5 · Configuraciones, header/logo, botones y Consejos
- Nueva página **Configuraciones** (menú superior, ícono de engranaje): tema claro/oscuro/automático, tamaño de texto (3 niveles), alto contraste, foco reforzado, subrayado de enlaces, animaciones normales/reducidas/desactivadas, perfil y cuenta según rol, restablecer. Se guardan en localStorage y funcionan con o sin sesión (`public/js/accesibilidad.js`, `window.ACC`).
- Selector flotante de tema reducido a un botón circular de 44 px con enlace a «Más opciones».
- Header: subrayado animado en la navegación, estado activo, «Reportar una avería» como acción principal con degradado; logo con elevación, brillo turquesa y gota animada solo al pasar el cursor.
- Botones: elevación, escala, brillo que recorre solo los botones primarios, desplazamiento de íconos, estado de pulsación (también táctil), carga y foco; sin hover en pantallas táctiles; respeta prefers-reduced-motion.
- Consejos: 8 tarjetas con ilustración y zoom al pasar el cursor; espacio para fotos reales en `public/media/consejos/` (lista `FOTOS` en app.js).
- Acerca: título «Conoce Agua Clara RD», texto actualizado del Grupo 6 y crédito en el pie de página.
- Panel: indicador activo turquesa, hover en el menú lateral y filas de tablas, pista visual de desplazamiento.
