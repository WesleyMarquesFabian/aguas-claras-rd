# Cómo ejecutar Agua Clara RD en tu PC

## 1. Instalar Node.js (una sola vez)
Descarga la versión **LTS** desde https://nodejs.org (necesitas 18 o superior). Instala con "Siguiente" a todo.
Para comprobar: abre una terminal (Windows: CMD o PowerShell) y escribe `node -v`.

## 2. Descomprimir
Extrae el ZIP, por ejemplo en `C:\aguas-claras` (o el Escritorio).

## 3. Abrir la terminal en esa carpeta
Windows: abre la carpeta, haz clic en la barra de direcciones, escribe `cmd` y Enter.

## 4. Instalar y arrancar
```
npm install
copy .env.example .env
npm start
```
(en Mac/Linux: `cp .env.example .env`)
La primera vez `npm install` tarda 1-2 minutos y necesita internet.

## 5. Abrir la página
En el navegador: **http://localhost:3000**
- Documentación de la API: http://localhost:3000/api-docs
- Para detener el servidor: `Ctrl + C` en la terminal.
- La próxima vez solo necesitas `npm start` dentro de la carpeta.

## Cuentas de demostración
Contraseña de todas: `Demo123*`, correo con el dominio `@aguaclara.do`:
`super@`, `admin@`, `supervisor@`, `ingeniero@`, `arquitecto@`, `agente@`, `gerente@`, `auditor@`, `cliente@`
Ejemplo: `admin@aguaclara.do`

## Probar
`npm test` ejecuta las 93 pruebas automáticas.

## Problemas frecuentes
- **"npm no se reconoce"**: reinicia la terminal tras instalar Node.js.
- **Puerto 3000 ocupado**: usa `set PORT=3001 && npm start` (Windows CMD) o `PORT=3001 npm start` (Mac/Linux) y abre http://localhost:3001.
- **Error con better-sqlite3**: usa Node.js LTS (20 o 22) y repite `npm install`.
- El video de "Acerca de" está en `public/media/` y se reproduce desde la propia página.
- Es un proyecto académico con datos de ejemplo; no es un sitio oficial del Gobierno dominicano.
