/* Agua Clara RD · Capa de interacción (no contiene reglas de negocio).
   - Confirmación antes de acciones destructivas
   - Estado de carga y prevención de envíos duplicados en botones
   - Mejoras de accesibilidad aplicadas después de cada render
   - Menú móvil
   Los módulos siguen funcionando igual si este archivo no se carga. */
(function () {
  'use strict';

  /* ---------- Confirmación accesible (<dialog>) ---------- */
  window.uiConfirm = function (titulo, texto, okTxt) {
    return new Promise(function (res) {
      var d = document.createElement('dialog'); d.className = 'cf'; d.setAttribute('aria-labelledby', 'cf-t');
      var f = document.createElement('form'); f.method = 'dialog';
      var h = document.createElement('h3'); h.id = 'cf-t'; h.textContent = titulo;
      var p = document.createElement('p'); p.className = 'mu'; p.textContent = texto;
      var r = document.createElement('div'); r.className = 'row';
      var no = document.createElement('button'); no.type = 'submit'; no.value = 'no'; no.className = 'btn s'; no.textContent = 'Volver';
      var si = document.createElement('button'); si.type = 'submit'; si.value = 'si'; si.className = 'btn r'; si.textContent = okTxt || 'Confirmar';
      r.appendChild(no); r.appendChild(si); f.appendChild(h); f.appendChild(p); f.appendChild(r); d.appendChild(f);
      var prev = document.activeElement;
      d.addEventListener('close', function () { var ok = d.returnValue === 'si'; d.remove(); try { if (prev && prev.focus && document.contains(prev)) prev.focus(); } catch (e) {} res(ok); });
      document.body.appendChild(d); d.showModal(); no.focus();
    });
  };

  /* Textos de los botones que requieren confirmación (acciones irreversibles) */
  var DESTRUCTIVO = /^(Eliminar|Cancelar (solicitud|entrega|operaci|asignaci|orden)|Anular|Desactivar)/i;

  document.addEventListener('click', function (e) {
    var b = e.target.closest && e.target.closest('button.btn');
    if (!b || b.disabled || b.closest('dialog.cf')) return;
    var txt = (b.textContent || '').trim();
    /* 1) Confirmación previa */
    if (b.classList.contains('r') && DESTRUCTIVO.test(txt) && !b._ok) {
      e.preventDefault(); e.stopImmediatePropagation();
      var cual = /^Eliminar/i.test(txt) ? 'Se eliminará este registro y la acción quedará registrada en la auditoría. No se puede deshacer.' : 'Esta acción cambiará el estado del registro y quedará registrada en la auditoría.';
      uiConfirm('¿Confirmas esta acción?', cual, txt).then(function (ok) { if (ok) { b._ok = true; b.click(); b._ok = false; } });
      return;
    }
    /* 2) Evita envíos duplicados mientras se procesa */
    if (b._busy) { e.preventDefault(); e.stopImmediatePropagation(); return; }
    b._busy = true; b.classList.add('is-loading'); b.setAttribute('aria-busy', 'true');
    setTimeout(function () { b._busy = false; b.classList.remove('is-loading'); b.removeAttribute('aria-busy'); }, 700);
  }, true);

  /* ---------- Menú móvil ---------- */
  window.toggleMenu = function () {
    var n = document.getElementById('mn'), b = document.getElementById('menu-b'); if (!n || !b) return;
    var o = n.classList.toggle('open'); b.setAttribute('aria-expanded', String(o)); b.textContent = o ? 'Cerrar' : 'Menú';
  };

  /* ---------- Colores de estado (solo por coincidencia exacta del texto) ---------- */
  var OK = /^(Aprobada|Aprobado|Completada|Completado|Entregada|Cerrada|Atendido|Resuelta|Activo|Activa|Disponible|Buena|Exitoso|Permitido|Recibido en almacén)$/i,
    ER = /^(Rechazada|Rechazado|Bloqueado|Cancelada|Cancelado|Dañado|Dañada|Crítica|Vencida|Vencido|Denegado|Desactivado|Inactivo)$/i,
    WA = /^(Pendiente|Recibido|En revisión|En proceso|En aprobación|En ejecución|Planificada|Abierta|En atención|Media|Alta|Requiere mantenimiento|Por vencer)$/i;

  /* ---------- Mejoras de accesibilidad tras cada render ---------- */
  window.uiPost = function () {
    var app = document.getElementById('app'); if (!app) return;
    app.querySelectorAll('th:not([scope])').forEach(function (t) { t.setAttribute('scope', 'col'); });
    app.querySelectorAll('.tw').forEach(function (w) { if (w.scrollWidth > w.clientWidth + 2) { w.tabIndex = 0; w.setAttribute('role', 'region'); if (!w.getAttribute('aria-label')) w.setAttribute('aria-label', 'Tabla desplazable'); } });
    app.querySelectorAll('.tag').forEach(function (t) {
      if (t.classList.contains('er') || t.classList.contains('warn') || t.classList.contains('ok')) return;
      var x = (t.textContent || '').trim();
      if (OK.test(x)) t.classList.add('ok'); else if (ER.test(x)) t.classList.add('er'); else if (WA.test(x)) t.classList.add('warn');
    });
    app.querySelectorAll('.err').forEach(function (w, i) {
      var c = w.querySelector('input,select,textarea'), m = w.querySelector('.em');
      if (c) c.setAttribute('aria-invalid', 'true');
      if (c && m) { if (!m.id) m.id = 'er-' + i; c.setAttribute('aria-describedby', m.id); }
    });
    app.querySelectorAll('.nl.on').forEach(function (n) { n.setAttribute('aria-current', 'page'); });
    if ('IntersectionObserver' in window) {
      document.documentElement.classList.add('js');
      var io = new IntersectionObserver(function (es) { es.forEach(function (e) { if (e.isIntersecting) { e.target.classList.add('in'); io.unobserve(e.target); } }); }, { threshold: 0.12 });
      app.querySelectorAll('.rv').forEach(function (n) { io.observe(n); });
    }
    app.querySelectorAll('a[target=_blank]:not([rel])').forEach(function (a) { a.rel = 'noopener'; });
  };

  /* Mensaje de estado emergente (success / error) */
  window.uiToast = function (m, tipo) {
    var t = document.getElementById('t'); if (!t) return;
    t.textContent = m; t.className = 'show ' + (tipo || 'ok');
    clearTimeout(uiToast.h); uiToast.h = setTimeout(function () { t.className = ''; }, tipo === 'er' ? 5200 : 3200);
  };
})();
