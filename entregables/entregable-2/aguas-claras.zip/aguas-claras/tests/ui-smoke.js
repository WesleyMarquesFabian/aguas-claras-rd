/* Prueba visual de humo (opcional): requiere `npm i -D playwright` y el servidor en BASE_URL.
   Uso: BASE_URL=http://localhost:3111 node tests/ui-smoke.js */
const { chromium } = require('playwright');
(async () => {
  const b = await chromium.launch(); const errs = [];
  const mk = async (opts) => { const c = await b.newContext({ ...opts, locale: 'es-DO' }); const p = await c.newPage();
    p.on('console', m => { if (m.type() === 'error') errs.push(m.text()); }); p.on('pageerror', e => errs.push('PAGEERROR ' + e.message)); return p; };
  const U = process.env.BASE_URL || 'http://localhost:3111';
  // Portal escritorio claro y oscuro
  let p = await mk({ viewport: { width: 1280, height: 800 }, deviceScaleFactor: 1 });
  await p.goto(U); await p.waitForSelector('.hero-band'); await p.screenshot({ path: (process.env.SHOTS||'/tmp')+'/portal-claro.png', fullPage: true });
  await p.evaluate(() => { localStorage.setItem('ac_tema', 'dark'); document.documentElement.setAttribute('data-theme', 'dark'); });
  await p.screenshot({ path: (process.env.SHOTS||'/tmp')+'/portal-oscuro.png', fullPage: true });
  await p.evaluate(() => { localStorage.setItem('ac_tema', 'light'); document.documentElement.setAttribute('data-theme', 'light'); });
  // reportar con error de validación y flujo completo
  await p.click('text=Reportar una avería >> nth=0'); await p.click('button:has-text("Enviar reporte")'); await p.waitForSelector('.em');
  await p.screenshot({ path: (process.env.SHOTS||'/tmp')+'/reportar-error.png', fullPage: true });
  console.log('aria-invalid:', await p.locator('[aria-invalid=true]').count());
  await p.fill('#sec', 'Alma Rosa'); await p.fill('#dsc', 'Fuga grande frente a la escuela del sector'); await p.click('button:has-text("Enviar reporte")');
  await p.waitForSelector('.code'); const code = await p.textContent('.code'); console.log('codigo', code);
  await p.screenshot({ path: (process.env.SHOTS||'/tmp')+'/confirmacion.png' });
  await p.click('button:has-text("Ver seguimiento")'); await p.waitForSelector('.tl'); await p.screenshot({ path: (process.env.SHOTS||'/tmp')+'/seguimiento.png', fullPage: true });
  // consulta rápida desde inicio
  await p.click('.brand'); await p.fill('#qc', 'DEMO-001'); await p.keyboard.press('Enter'); await p.waitForSelector('.tl'); console.log('consulta rapida ok');
  await p.click('nav >> text=Acerca de'); await p.waitForSelector('h1'); await p.click('nav >> text=Consejos'); await p.waitForSelector('h1');
  console.log('titulo:', await p.title());
  // login panel
  await p.click('nav >> text=Acceso del equipo'); await p.fill('#e', 'super@aguaclara.do'); await p.fill('#p', 'Demo123*'); await p.click('button:has-text("Entrar")');
  await p.waitForSelector('.side'); await p.waitForTimeout(500);
  const tabs = await p.$$eval('.side .nl', n => n.map(x => x.textContent.trim()).filter(t => t !== 'Cerrar sesión'));
  console.log('modulos', tabs.length);
  let n = 0;
  for (const t of tabs) { await p.click(`.side .nl:text-is("${t}")`); await p.waitForTimeout(350); n++;
    const bad = await p.$$eval('main', m => /undefined|\[object|NaN/.test(m[0].innerText)); if (bad) console.log('POSIBLE ERROR EN', t);
    if (['Operaciones','Catálogo','Inventario','Solicitudes','Entregas','Usuarios','Indicadores y reportes','Integración API y datos','Auditoría'].includes(t)) await p.screenshot({ path: `'+(process.env.SHOTS||'/tmp')+'/panel-${t.replace(/[^a-z]/gi,'')}.png`, fullPage: true }); }
  console.log('modulos recorridos', n);
  // confirmación de eliminar
  await p.click('.side .nl:text-is("Usuarios")'); await p.waitForTimeout(300);
  const del = p.locator('button.btn.r:has-text("Eliminar")').first();
  if (await del.count()) { await del.click(); await p.waitForSelector('dialog.cf[open]'); await p.screenshot({ path: (process.env.SHOTS||'/tmp')+'/confirmar.png' }); await p.click('dialog.cf button:has-text("Volver")'); await p.waitForTimeout(300); console.log('dialogo cerrado:', await p.locator('dialog.cf').count() === 0); }
  // tema desde accesibilidad
  await p.click('#acc-b'); await p.click('#acc input[value=dark]'); await p.waitForTimeout(300); console.log('tema:', await p.getAttribute('html', 'data-theme'));
  await p.screenshot({ path: (process.env.SHOTS||'/tmp')+'/panel-oscuro.png' });
  // móvil
  const m = await mk({ viewport: { width: 390, height: 844 }, deviceScaleFactor: 2, isMobile: true, hasTouch: true });
  await m.goto(U); await m.waitForSelector('.hero-band'); await m.screenshot({ path: (process.env.SHOTS||'/tmp')+'/movil-inicio.png', fullPage: true });
  await m.click('#menu-b'); await m.screenshot({ path: (process.env.SHOTS||'/tmp')+'/movil-menu.png' });
  const ov = await m.evaluate(() => document.documentElement.scrollWidth - innerWidth); console.log('desborde horizontal movil px:', ov);
  await m.click('#mn >> text=Reportar una avería'); await m.screenshot({ path: (process.env.SHOTS||'/tmp')+'/movil-reportar.png', fullPage: true });
  console.log('desborde reportar:', await m.evaluate(() => document.documentElement.scrollWidth - innerWidth));
  await m.click('#menu-b'); await m.click('#mn >> text=Acceso del equipo'); await m.fill('#e', 'super@aguaclara.do'); await m.fill('#p', 'Demo123*'); await m.click('button:has-text("Entrar")'); await m.waitForSelector('.side'); await m.waitForTimeout(500);
  await m.screenshot({ path: (process.env.SHOTS||'/tmp')+'/movil-panel.png' }); console.log('desborde panel:', await m.evaluate(() => document.documentElement.scrollWidth - innerWidth));
  console.log('ERRORES CONSOLA:', errs.length, errs.slice(0, 5)); await b.close();
})().catch(e => { console.error('FALLO', e.message); process.exit(1); });
