# Agua Clara RD — Épica 1: Gestión de Usuarios y Accesos

Página web de reportes de averías y falta de agua (proyecto académico, República Dominicana) con el módulo de usuarios, roles, permisos y auditoría.

Entrega: 29 de octubre de 2026, 20:00.

## Cómo ejecutarlo

No necesita servidor ni instalación.

```bash
git clone <URL-del-repositorio>
cd aguas-claras
```

Abre `index.html` en Chrome, Edge o Firefox y entra por **Acceso**.

Cuentas de demostración (contraseña `Demo123*`): `super@`, `admin@`, `agente@`, `arquitecto@`, `ingeniero@`, `cliente@` y `supervisor@` con el dominio `aguaclara.do`.

## Pruebas

En el navegador: **Mi panel → Pruebas → Ejecutar pruebas**.

Desde la terminal (requiere Node.js):

```bash
node tests/run-tests.js
```

Resultado esperado: `13 de 13 casos pasaron`.

## Historias incluidas

| ID | Historia |
|---|---|
| HU-1.1 | Autenticación, inicio y cierre de sesión |
| HU-1.2 | Registro de usuarios (administrador y autorregistro) |
| HU-1.3 | Gestión de roles |
| HU-1.4 | Gestión de permisos por módulo |
| HU-1.5 | Recuperación de contraseña |
| HU-1.6 | Bloqueo de usuarios |
| HU-1.7 | Administración de perfil |
| HU-1.8 | Auditoría de accesos |

## Estructura

```
index.html          Página y punto de entrada
css/styles.css      Estilos (escritorio y móvil, modo claro y oscuro)
js/app.js           Lógica, pantallas públicas y módulo de la Épica 1
tests/run-tests.js  Pruebas de acceso autorizado y no autorizado
docs/               Documentación actualizada
evidencia/          Video de la demostración
```

## Limitaciones

Es una maqueta funcional sin servidor: los datos viven en el navegador, las contraseñas no están cifradas, y la IP, la localización y el correo de recuperación son simulados.
