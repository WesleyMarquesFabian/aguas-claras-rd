// Ejecuta los casos de prueba de la Épica 1 fuera del navegador: node tests/run-tests.js
const fs = require('fs'), path = require('path');
const store = {};
global.localStorage = { getItem: k => store[k] || null, setItem: (k, v) => (store[k] = v) };
const el = () => ({ innerHTML: '', style: {}, value: '', textContent: '' });
global.document = { querySelector: el };
global.scrollTo = () => {};
const code = fs.readFileSync(path.join(__dirname, '..', 'js', 'app.js'), 'utf8')
  .replace('load();R();', 'load();');
const results = new Function(code + '\nreturn runTests();')();
results.forEach(([name, ok]) => console.log(ok ? 'OK   ' : 'FALLÓ', name));
const passed = results.filter(r => r[1]).length;
console.log(`\n${passed} de ${results.length} casos pasaron`);
process.exit(passed === results.length ? 0 : 1);
