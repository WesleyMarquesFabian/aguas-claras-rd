#!/bin/bash
# Uso: ./subir-a-git.sh https://github.com/TU-USUARIO/aguas-claras.git
# Ejecútalo DENTRO de la carpeta aguas-claras (la que contiene index.html y .git)
set -e
URL="$1"
[ -z "$URL" ] && { echo "Falta la URL del repositorio. Ejemplo: ./subir-a-git.sh https://github.com/usuario/aguas-claras.git"; exit 1; }
git remote remove origin 2>/dev/null || true
git remote add origin "$URL"
git push -u origin main --tags
git push origin feature/epica-1-usuarios-accesos
echo "Listo: repositorio subido."
